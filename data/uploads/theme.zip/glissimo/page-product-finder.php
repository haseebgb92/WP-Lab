<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$s = glissimo_phase2_settings()['quiz'] ?? array();
if ( ! glissimo_phase2_enabled( 'quiz' ) ) { wp_safe_redirect( wc_get_page_permalink( 'shop' ) ); exit; }
$questions = glissimo_quiz_questions();
get_header();
?>
<main id="main-content" class="gl-phase2 gl-quiz" data-gl-quiz>
	<header class="gl-phase2__hero"><div class="gl-container"><p class="gl-eyebrow"><?php esc_html_e( 'Product finder', 'glissimo' ); ?></p><h1 class="gl-heading-display"><?php echo esc_html( $s['title'] ); ?></h1><?php if ( $s['intro'] ) : ?><p class="gl-prose"><?php echo esc_html( $s['intro'] ); ?></p><?php endif; ?></div></header>
	<div class="gl-container gl-quiz__body">
		<form class="gl-quiz__form" data-gl-quiz-form>
			<div class="gl-quiz__progress" aria-hidden="true"><span data-gl-quiz-progress></span></div>
			<?php foreach ( $questions as $index => $question ) : ?>
				<fieldset data-gl-quiz-step="<?php echo esc_attr( $index ); ?>"><legend><span><?php echo esc_html( sprintf( __( 'Question %1$d of %2$d', 'glissimo' ), $index + 1, count( $questions ) ) ); ?></span><?php echo esc_html( $question['question'] ); ?></legend><div class="gl-quiz__answers"><?php foreach ( $question['answers'] as $answer ) : ?><label><input type="radio" name="<?php echo esc_attr( $question['key'] ); ?>" value="<?php echo esc_attr( $answer['value'] ); ?>" required><span><?php echo esc_html( $answer['label'] ); ?></span></label><?php endforeach; ?></div></fieldset>
			<?php endforeach; ?>
			<div class="gl-quiz__actions"><button type="button" class="gl-button gl-button--secondary" data-gl-quiz-back><?php esc_html_e( 'Previous', 'glissimo' ); ?></button><button type="button" class="gl-button" data-gl-quiz-next><?php esc_html_e( 'Continue', 'glissimo' ); ?></button><button type="submit" class="gl-button" data-gl-quiz-submit><?php esc_html_e( 'Show my match', 'glissimo' ); ?></button></div>
		</form>
		<section class="gl-quiz__result" data-gl-quiz-result hidden aria-live="polite"></section>
		<?php if ( ! empty( $s['email_capture'] ) ) : ?>
			<section class="gl-quiz__email" data-gl-quiz-email hidden><div class="gl-quiz__email-copy"><p class="gl-eyebrow"><?php esc_html_e( 'Save your result', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Keep your recommendation close', 'glissimo' ); ?></h2><p><?php esc_html_e( 'Opt in if you would like product guidance and Glissimo updates by email.', 'glissimo' ); ?></p></div><div class="gl-newsletter"><?php glissimo_newsletter_form( 'product_finder' ); ?></div></section>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
