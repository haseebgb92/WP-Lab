<?php
/**
 * Theme bootstrap for Glissimo.
 *
 * @package Glissimo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_theme_file_path( '/inc/commerce-config.php' );
require_once get_theme_file_path( '/inc/cart.php' );
require_once get_theme_file_path( '/inc/promotions.php' );
require_once get_theme_file_path( '/inc/checkout.php' );
require_once get_theme_file_path( '/inc/analytics.php' );
require_once get_theme_file_path( '/inc/newsletter.php' );
require_once get_theme_file_path( '/inc/localization.php' );
require_once get_theme_file_path( '/inc/seo.php' );
require_once get_theme_file_path( '/inc/phase2.php' );
require_once get_theme_file_path( '/inc/bundle-builder.php' );
require_once get_theme_file_path( '/inc/wishlist.php' );
require_once get_theme_file_path( '/inc/back-in-stock.php' );
require_once get_theme_file_path( '/inc/account-access.php' );
require_once get_theme_file_path( '/inc/discovery.php' );
require_once get_theme_file_path( '/inc/phase2-search.php' );
require_once get_theme_file_path( '/inc/post-purchase.php' );
require_once get_theme_file_path( '/inc/phase2-analytics.php' );
require_once get_theme_file_path( '/inc/retention-growth.php' );
require_once get_theme_file_path( '/inc/editorial.php' );
require_once get_theme_file_path( '/inc/pdp-editorial.php' );

function glissimo_setup(): void {
	load_theme_textdomain( 'glissimo', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'advertpreneur-core-glissimo' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);

	register_nav_menus(
		array(
			'primary'        => __( 'Primary navigation', 'glissimo' ),
			'footer_shop'    => __( 'Footer shop navigation', 'glissimo' ),
			'footer_support' => __( 'Footer support navigation', 'glissimo' ),
		)
	);
}
add_action( 'after_setup_theme', 'glissimo_setup' );

function glissimo_asset_version( string $relative_path ): string {
	$path = get_theme_file_path( $relative_path );
	return file_exists( $path ) ? (string) filemtime( $path ) : wp_get_theme()->get( 'Version' );
}

/** Render the small, dependency-free icon family used by theme controls. */
function glissimo_icon( string $name, string $class = '' ): string {
	$paths = array(
		'search'  => '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.25 4.25"/>',
		'account' => '<circle cx="12" cy="8" r="3.5"/><path d="M5.5 20c.65-4 2.8-6 6.5-6s5.85 2 6.5 6"/>',
		'cart'    => '<path d="M3.5 5h2l1.45 9.1a2 2 0 0 0 2 1.7h7.7a2 2 0 0 0 1.9-1.35L21 8H6.05"/><circle cx="9" cy="19" r="1.25"/><circle cx="17" cy="19" r="1.25"/>',
		'menu'    => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'close'   => '<path d="m6 6 12 12M18 6 6 18"/>',
		'globe'   => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.3 2.45 3.45 5.45 3.45 9S14.3 18.55 12 21M12 3C9.7 5.45 8.55 8.45 8.55 12S9.7 18.55 12 21"/>',
		'chevron' => '<path d="m9 5 7 7-7 7"/>',
		'check'   => '<path d="m5 12 4.25 4.25L19 6.5"/>',
		'plus'    => '<path d="M12 5v14M5 12h14"/>',
		'heart'   => '<path d="M20.8 5.8a5 5 0 0 0-7.1 0L12 7.5l-1.7-1.7a5 5 0 1 0-7.1 7.1L12 21l8.8-8.1a5 5 0 0 0 0-7.1Z"/>',
		'dashboard' => '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
		'orders'  => '<path d="m4 7 8-4 8 4-8 4-8-4Z"/><path d="M4 7v10l8 4 8-4V7M12 11v10"/>',
		'pin'     => '<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
		'bell'    => '<path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 7h18s-3 0-3-7ZM10 20h4"/>',
		'star'    => '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
		'referral'=> '<circle cx="8" cy="8" r="3"/><circle cx="17" cy="10" r="2.5"/><path d="M2.5 20c.5-4 2.4-6 5.5-6s5 2 5.5 6M14 15c3.6-.7 6.1 1 7 5"/>',
		'logout'  => '<path d="M10 4H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5M15 8l4 4-4 4M8 12h11"/>',
		'payment' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h3"/>',
		'whatsapp' => '<path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) { return ''; }
	$is_brand_icon = 'whatsapp' === $name;
	return '<svg class="gl-icon ' . esc_attr( $class ) . '" viewBox="' . ( $is_brand_icon ? '0 0 448 512' : '0 0 24 24' ) . '" fill="' . ( $is_brand_icon ? 'currentColor' : 'none' ) . '" stroke="' . ( $is_brand_icon ? 'none' : 'currentColor' ) . '" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
}

/** Keep engineering fixture metadata out of customer-facing rendering. */
function glissimo_is_internal_content( string $value ): bool {
	return 1 === preg_match( '/(?:\bQA\s+status\b|\blocal\s+QA\b|\bproduct\s+source\b|\bdevelopment(?:-only)?\b|\bfixture\b|\btemporary\b|\blocal\s+checkout\b|used\s+(?:only\s+)?to\s+verify|awaiting\s+(?:client\s+)?approval|not\s+approved\s+for\s+production)/i', $value );
}

function glissimo_customer_content_tree( $value ) {
	if ( is_array( $value ) ) {
		return array_map( 'glissimo_customer_content_tree', $value );
	}
	if ( is_string( $value ) && glissimo_is_internal_content( $value ) ) {
		return '';
	}
	return $value;
}

function glissimo_is_customer_spec_line( $line ): bool {
	return is_string( $line ) && '' !== trim( $line ) && ! glissimo_is_internal_content( $line );
}

/** Return category/editorial copy only when it is suitable for shoppers. */
function glissimo_collection_customer_copy( string $value ): string {
	$value = trim( $value );
	return '' === $value || glissimo_is_internal_content( $value ) ? '' : $value;
}

function glissimo_enqueue_foundation_assets(): void {
	wp_enqueue_style(
		'glissimo-tokens',
		get_theme_file_uri( '/assets/css/tokens.css' ),
		array(),
		glissimo_asset_version( '/assets/css/tokens.css' )
	);
	wp_enqueue_style(
		'glissimo-theme',
		get_stylesheet_uri(),
		array( 'glissimo-tokens' ),
		glissimo_asset_version( '/style.css' )
	);
	wp_enqueue_style(
		'glissimo-commerce',
		get_theme_file_uri( '/assets/css/commerce.css' ),
		array( 'glissimo-theme' ),
		glissimo_asset_version( '/assets/css/commerce.css' )
	);
	wp_enqueue_style(
		'glissimo-sprint3',
		get_theme_file_uri( '/assets/css/sprint3.css' ),
		array( 'glissimo-commerce' ),
		glissimo_asset_version( '/assets/css/sprint3.css' )
	);
	wp_enqueue_script(
		'glissimo-navigation',
		get_theme_file_uri( '/assets/js/navigation.js' ),
		array(),
		glissimo_asset_version( '/assets/js/navigation.js' ),
		true
	);

	$settings = glissimo_core_settings();
	wp_enqueue_style(
		'glissimo-integrations',
		get_theme_file_uri( '/assets/css/integrations.css' ),
		array( 'glissimo-sprint3' ),
		glissimo_asset_version( '/assets/css/integrations.css' )
	);
	wp_enqueue_style( 'glissimo-visual-completion', get_theme_file_uri( '/assets/css/visual-completion.css' ), array( 'glissimo-integrations' ), glissimo_asset_version( '/assets/css/visual-completion.css' ) );
	wp_enqueue_style( 'glissimo-final-owner-polish', get_theme_file_uri( '/assets/css/final-owner-polish.css' ), array( 'glissimo-visual-completion' ), glissimo_asset_version( '/assets/css/final-owner-polish.css' ) );
	wp_enqueue_style( 'glissimo-commerce-ui-refinement', get_theme_file_uri( '/assets/css/commerce-ui-refinement.css' ), array( 'glissimo-final-owner-polish' ), glissimo_asset_version( '/assets/css/commerce-ui-refinement.css' ) );
	if ( is_post_type_archive( array( 'glissimo_recipe', 'glissimo_guide' ) ) || is_tax( array( 'gl_recipe_course', 'gl_guide_topic' ) ) || is_singular( array( 'glissimo_recipe', 'glissimo_guide', 'glissimo_scene' ) ) || is_page( array( 'glissimo-kitchen', 'shop-the-kitchen' ) ) || ( is_search() && isset( $_GET['gl_kitchen_search'] ) ) ) {
		wp_enqueue_style( 'glissimo-phase3a', get_theme_file_uri( '/assets/css/phase3a.css' ), array( 'glissimo-commerce-ui-refinement' ), glissimo_asset_version( '/assets/css/phase3a.css' ) );
	}
	wp_localize_script(
		'glissimo-navigation',
		'GlissimoSearch',
		array(
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'nonce'        => wp_create_nonce( 'glissimo_search' ),
			'action'       => 'glissimo_live_product_search',
			'searching'    => __( 'Searching…', 'glissimo' ),
			'singular'     => __( 'product', 'glissimo' ),
			'plural'       => __( 'products', 'glissimo' ),
			'unavailable'  => __( 'Unavailable', 'glissimo' ),
			'emptyMessage' => __( 'No matching products were found. Try another search.', 'glissimo' ),
			'errorMessage' => __( 'Search is temporarily unavailable. View the full collection instead.', 'glissimo' ),
			'fallbackMessage' => __( 'No exact match. These products may help.', 'glissimo' ),
			'advanced'     => function_exists( 'glissimo_phase2_enabled' ) && glissimo_phase2_enabled( 'search' ),
		)
	);
	$navigation_items = array();
	$navigation_locations = get_nav_menu_locations();
	$navigation_menu_items = ! empty( $navigation_locations['primary'] ) ? wp_get_nav_menu_items( $navigation_locations['primary'] ) : array();
	foreach ( $navigation_menu_items ?: array() as $navigation_item ) {
		if ( 0 === (int) $navigation_item->menu_item_parent ) {
			$navigation_items[] = array( 'url' => esc_url_raw( $navigation_item->url ) );
		}
	}
	wp_localize_script( 'glissimo-navigation', 'GlissimoNavigation', array( 'topLevel' => $navigation_items ) );
	wp_enqueue_script( 'glissimo-consent', get_theme_file_uri( '/assets/js/consent.js' ), array(), glissimo_asset_version( '/assets/js/consent.js' ), true );
	wp_localize_script(
		'glissimo-consent',
		'GlissimoPrivacy',
		array(
			'provider'=> (string) ( $settings['consent']['provider'] ?? 'complianz' ),
			'localBridge' => ! empty( $settings['consent']['enabled'] ),
			'enabled' => ! empty( $settings['analytics']['enabled'] ),
			'dryRun'  => ! empty( $settings['analytics']['dry_run'] ) || 'production' !== wp_get_environment_type(),
			'gtm'     => (string) ( $settings['analytics']['gtm_container_id'] ?? '' ),
			'ga4'     => (string) ( $settings['analytics']['ga4_measurement_id'] ?? '' ),
			'meta'    => (string) ( $settings['analytics']['meta_pixel_id'] ?? '' ),
			'clarity' => strtolower( (string) ( $settings['analytics']['clarity_project_id'] ?? '' ) ),
		)
	);
	wp_enqueue_script( 'glissimo-analytics', get_theme_file_uri( '/assets/js/analytics.js' ), array( 'glissimo-consent' ), glissimo_asset_version( '/assets/js/analytics.js' ), true );
	wp_localize_script(
		'glissimo-analytics',
		'GlissimoAnalytics',
		array(
			'enabled'       => ! empty( $settings['analytics']['enabled'] ),
			'dryRun'        => ! empty( $settings['analytics']['dry_run'] ) || 'production' !== wp_get_environment_type(),
			'gtm'           => (string) ( $settings['analytics']['gtm_container_id'] ?? '' ),
			'ga4'           => (string) ( $settings['analytics']['ga4_measurement_id'] ?? '' ),
			'meta'          => (string) ( $settings['analytics']['meta_pixel_id'] ?? '' ),
			'initialEvents' => glissimo_initial_analytics_events(),
		)
	);
	$campaign_newsletter = is_singular( 'glissimo_landing' ) && ! empty( ( (array) get_post_meta( get_queried_object_id(), '_glissimo_landing', true ) )['newsletter_enabled'] );
	$quiz_newsletter = is_page( 'product-finder' ) && ! empty( glissimo_phase2_settings()['quiz']['email_capture'] );
	if ( ( is_front_page() && ! empty( $settings['retention']['newsletter_enabled'] ) ) || $campaign_newsletter || $quiz_newsletter ) {
		wp_enqueue_script( 'glissimo-newsletter', get_theme_file_uri( '/assets/js/newsletter.js' ), array( 'glissimo-analytics' ), glissimo_asset_version( '/assets/js/newsletter.js' ), true );
		wp_localize_script( 'glissimo-newsletter', 'GlissimoNewsletter', array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'glissimo_newsletter' ), 'errorMessage' => __( 'Signup could not be completed. Please try again.', 'glissimo' ) ) );
	}
	if ( is_front_page() ) {
		wp_enqueue_script( 'glissimo-scratch-campaign', get_theme_file_uri( '/assets/js/scratch-campaign.js' ), array( 'glissimo-analytics' ), glissimo_asset_version( '/assets/js/scratch-campaign.js' ), true );
	}
	if ( ! isset( $settings['cart']['enabled'] ) || ! empty( $settings['cart']['enabled'] ) ) {
		wp_enqueue_script( 'wc-add-to-cart' );
		wp_enqueue_script( 'wc-cart-fragments' );
		wp_enqueue_script(
			'glissimo-cart-drawer',
			get_theme_file_uri( '/assets/js/cart-drawer.js' ),
			array( 'jquery', 'wc-add-to-cart', 'wc-cart-fragments' ),
			glissimo_asset_version( '/assets/js/cart-drawer.js' ),
			true
		);
		wp_localize_script(
			'glissimo-cart-drawer',
			'GlissimoCart',
			array(
				'ajaxUrl'              => admin_url( 'admin-ajax.php' ),
				'nonce'                => wp_create_nonce( 'glissimo_cart' ),
				'errorMessage'         => __( 'The cart could not be updated. Please try again.', 'glissimo' ),
				'chooseOptionsMessage' => __( 'Choose product options before adding this item.', 'glissimo' ),
			)
		);
	}

	if ( is_shop() || is_product_taxonomy() ) {
		wp_enqueue_script(
			'glissimo-collection',
			get_theme_file_uri( '/assets/js/collection.js' ),
			array(),
			glissimo_asset_version( '/assets/js/collection.js' ),
			true
		);
	}

	if ( is_product() ) {
		$cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' );
		wp_enqueue_script(
			'glissimo-product',
			get_theme_file_uri( '/assets/js/product.js' ),
			array(),
			glissimo_asset_version( '/assets/js/product.js' ),
			true
		);
		wp_localize_script(
			'glissimo-product',
			'GlissimoProduct',
			array(
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'nonce'          => wp_create_nonce( 'glissimo_fbt' ),
				'action'         => 'glissimo_fbt_add_to_cart',
				'cartUrl'        => $cart_url,
				'singular'       => __( 'product', 'glissimo' ),
				'plural'         => __( 'products', 'glissimo' ),
				'currencyCode'   => get_woocommerce_currency(),
				'priceDecimals'  => wc_get_price_decimals(),
				'decimalMark'    => wc_get_price_decimal_separator(),
				'thousandMark'   => wc_get_price_thousand_separator(),
				'selectedTotal'  => __( 'Selected total', 'glissimo' ),
				'offerTotal'     => __( 'Offer total', 'glissimo' ),
				'optionLabel'    => __( 'Option', 'glissimo' ),
				'clearSelection' => __( 'Clear selection', 'glissimo' ),
				'available'      => __( 'Available', 'glissimo' ),
				'unavailable'    => __( 'Currently unavailable', 'glissimo' ),
				'variationReady' => __( 'Your selection is ready to add.', 'glissimo' ),
				'variationPrompt' => __( 'Choose the options that suit your kitchen.', 'glissimo' ),
				'chooseOptions'  => __( 'Choose options', 'glissimo' ),
				'addToCart'      => __( 'Add to cart', 'glissimo' ),
			)
		);
	}

	if ( is_checkout() && ! is_order_received_page() ) {
		wp_enqueue_script(
			'glissimo-checkout',
			get_theme_file_uri( '/assets/js/checkout.js' ),
			array( 'jquery', 'wc-checkout' ),
			glissimo_asset_version( '/assets/js/checkout.js' ),
			true
		);
		wp_localize_script(
			'glissimo-checkout',
			'GlissimoCheckout',
			array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'glissimo_cart' ) )
		);
	}
}
add_action( 'wp_enqueue_scripts', 'glissimo_enqueue_foundation_assets' );

/** Load the owner-approved symmetry pass after every route-specific stylesheet. */
function glissimo_enqueue_symmetry_polish(): void {
	wp_enqueue_style(
		'glissimo-symmetry-polish',
		get_theme_file_uri( '/assets/css/symmetry-polish.css' ),
		array( 'glissimo-commerce-ui-refinement' ),
		glissimo_asset_version( '/assets/css/symmetry-polish.css' )
	);
}
add_action( 'wp_enqueue_scripts', 'glissimo_enqueue_symmetry_polish', 100 );

/** Keep the product-detail recomposition isolated from approved non-product surfaces. */
function glissimo_enqueue_pdp_refinement(): void {
	if ( ! is_product() ) {
		return;
	}
	wp_enqueue_style(
		'glissimo-pdp-refinement',
		get_theme_file_uri( '/assets/css/pdp-refinement.css' ),
		array( 'glissimo-symmetry-polish' ),
		glissimo_asset_version( '/assets/css/pdp-refinement.css' )
	);
}
add_action( 'wp_enqueue_scripts', 'glissimo_enqueue_pdp_refinement', 110 );

/** Load the bounded PDP education and rail layer only where it is used. */
function glissimo_enqueue_pdp_editorial(): void {
	if ( ! is_product() ) {
		return;
	}
	wp_enqueue_style(
		'glissimo-pdp-editorial',
		get_theme_file_uri( '/assets/css/pdp-editorial.css' ),
		array( 'glissimo-pdp-refinement' ),
		glissimo_asset_version( '/assets/css/pdp-editorial.css' )
	);
	wp_enqueue_script(
		'glissimo-pdp-editorial',
		get_theme_file_uri( '/assets/js/pdp-editorial.js' ),
		array(),
		glissimo_asset_version( '/assets/js/pdp-editorial.js' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'glissimo_enqueue_pdp_editorial', 120 );

/** Load account refinements after Phase 2 wishlist styles on account routes only. */
function glissimo_phase3b_enqueue(): void {
	if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return;
	}
	wp_enqueue_style( 'glissimo-phase3b', get_theme_file_uri( '/assets/css/phase3b.css' ), array( 'glissimo-commerce-ui-refinement' ), glissimo_asset_version( '/assets/css/phase3b.css' ) );
}
add_action( 'wp_enqueue_scripts', 'glissimo_phase3b_enqueue', 40 );

/** Lightweight Phase 1 product suggestions. WooCommerce remains catalogue and price truth. */
function glissimo_live_product_search(): void {
	check_ajax_referer( 'glissimo_search', 'nonce' );
	$term = sanitize_text_field( wp_unslash( $_GET['term'] ?? '' ) );
	if ( strlen( trim( $term ) ) < 2 ) {
		wp_send_json_success( array( 'results' => array(), 'viewAll' => '' ) );
	}

	$search_term = function_exists( 'glissimo_phase2_search_term' ) ? glissimo_phase2_search_term( $term ) : $term;
	$query = new WP_Query(
		array(
			'post_type'              => 'product',
			'post_status'            => 'publish',
			's'                      => $search_term,
			'posts_per_page'         => 6,
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => true,
		)
	);
	if ( function_exists( 'glissimo_phase2_promote_search_results' ) ) {
		$query->posts = glissimo_phase2_promote_search_results( $term, $query->posts );
	}
	$fallback = false;
	if ( ! $query->posts && function_exists( 'glissimo_phase2_search_fallback_posts' ) ) {
		$query->posts = glissimo_phase2_search_fallback_posts();
		$fallback = (bool) $query->posts;
	}
	$results = array();
	foreach ( $query->posts as $product_post ) {
		$product = wc_get_product( $product_post->ID );
		if ( ! $product || ! $product->is_visible() ) { continue; }
		$image = $product->get_image_id() ? wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' ) : wc_placeholder_img_src( 'woocommerce_thumbnail' );
		$categories = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
		$price_html = preg_replace( '/<span[^>]*class=["\']screen-reader-text["\'][^>]*>.*?<\/span>/si', '', $product->get_price_html() );
		$results[] = array(
			'id'       => $product->get_id(),
			'name'     => $product->get_name(),
			'url'      => $product->get_permalink(),
			'image'    => $image ?: '',
			'price'    => html_entity_decode( wp_strip_all_tags( (string) $price_html ), ENT_QUOTES, get_bloginfo( 'charset' ) ),
			'category' => is_wp_error( $categories ) ? '' : implode( ', ', array_slice( $categories, 0, 2 ) ),
			'inStock'  => $product->is_in_stock(),
		);
	}
	wp_reset_postdata();
	wp_send_json_success(
		array(
			'results' => $results,
			'viewAll' => add_query_arg( array( 's' => $term, 'post_type' => 'product' ), home_url( '/' ) ),
			'fallback' => $fallback,
		)
	);
}
add_action( 'wp_ajax_glissimo_live_product_search', 'glissimo_live_product_search' );
add_action( 'wp_ajax_nopriv_glissimo_live_product_search', 'glissimo_live_product_search' );

/** Return true only while a configured announcement is eligible to render. */
function glissimo_announcement_is_active( array $announcement ): bool {
	if ( empty( $announcement['enabled'] ) || '' === trim( (string) ( $announcement['text'] ?? '' ) ) ) { return false; }
	$timezone = wp_timezone();
	$now = new DateTimeImmutable( 'now', $timezone );
	foreach ( array( 'starts_at' => 'before', 'ends_at' => 'after' ) as $key => $comparison ) {
		if ( empty( $announcement[ $key ] ) ) { continue; }
		$date = DateTimeImmutable::createFromFormat( 'Y-m-d\\TH:i', (string) $announcement[ $key ], $timezone );
		if ( ! $date || ( 'before' === $comparison && $now < $date ) || ( 'after' === $comparison && $now > $date ) ) { return false; }
	}
	if ( ! empty( $announcement['dismissible'] ) ) {
		$key = substr( hash( 'sha256', wp_json_encode( $announcement ) ), 0, 16 );
		if ( isset( $_COOKIE['glissimo_announcement_dismissed'] ) && hash_equals( $key, sanitize_text_field( wp_unslash( $_COOKIE['glissimo_announcement_dismissed'] ) ) ) ) { return false; }
	}
	return true;
}

/** Render a configured editorial image or video without loading a media library. */
function glissimo_editorial_media( int $attachment_id, string $size = 'large' ): string {
	if ( $attachment_id < 1 ) { return ''; }
	if ( 0 === strpos( (string) get_post_mime_type( $attachment_id ), 'video/' ) ) {
		$url = wp_get_attachment_url( $attachment_id );
		return $url ? '<video controls playsinline preload="metadata"><source src="' . esc_url( $url ) . '"></video>' : '';
	}
	return wp_get_attachment_image( $attachment_id, $size, false, array( 'loading' => 'lazy' ) );
}

function glissimo_hero_image_loading_attributes( array $attr, WP_Post $attachment, $size ): array {
	if ( is_front_page() && 'full' === $size ) {
		$settings = glissimo_core_settings();
		if ( (int) ( $settings['homepage']['hero_image_id'] ?? 0 ) === (int) $attachment->ID ) {
			$attr['loading'] = 'eager';
			$attr['fetchpriority'] = 'high';
			$attr['decoding'] = 'async';
		}
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'glissimo_hero_image_loading_attributes', 10, 3 );

function glissimo_discover_catalog_query( WP_Query $query ): void {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( ! ( is_shop() || is_product_taxonomy() ) ) {
		return;
	}

	$discover_view = isset( $_GET['gl_view'] ) ? sanitize_key( wp_unslash( (string) $_GET['gl_view'] ) ) : '';
	if ( 'bestsellers' === $discover_view ) {
		$query->set( 'meta_key', 'total_sales' );
		$query->set( 'orderby', 'meta_value_num' );
		$query->set( 'order', 'DESC' );
	} elseif ( 'new' === $discover_view ) {
		$query->set( 'orderby', 'date' );
		$query->set( 'order', 'DESC' );
	} elseif ( 'deals' === $discover_view ) {
		$sale_ids = wc_get_product_ids_on_sale();
		$query->set( 'post__in', $sale_ids ? $sale_ids : array( 0 ) );
	}

	$sale_filter = isset( $_GET['filter_sale'] ) ? sanitize_key( wp_unslash( (string) $_GET['filter_sale'] ) ) : '';
	if ( 'onsale' === $sale_filter ) {
		$sale_ids    = array_map( 'absint', wc_get_product_ids_on_sale() );
		$current_ids = array_map( 'absint', (array) $query->get( 'post__in' ) );
		$eligible    = $current_ids ? array_values( array_intersect( $current_ids, $sale_ids ) ) : $sale_ids;
		$query->set( 'post__in', $eligible ? $eligible : array( 0 ) );
	}

	$meta_query = (array) $query->get( 'meta_query' );
	if ( isset( $_GET['filter_stock'] ) ) {
		$filter_stock = sanitize_key( $_GET['filter_stock'] );
		if ( in_array( $filter_stock, array( 'instock', 'outofstock' ), true ) ) {
			$meta_query[] = array(
				'key'     => '_stock_status',
				'value'   => 'instock' === $filter_stock ? 'instock' : 'outofstock',
				'compare' => '=',
			);
		}
	}
	$minimum_price = isset( $_GET['min_price'] ) ? wc_format_decimal( wp_unslash( (string) $_GET['min_price'] ) ) : '';
	$maximum_price = isset( $_GET['max_price'] ) ? wc_format_decimal( wp_unslash( (string) $_GET['max_price'] ) ) : '';
	if ( '' !== $minimum_price && is_numeric( $minimum_price ) ) {
		$meta_query[] = array(
			'key'     => '_price',
			'value'   => max( 0, (float) $minimum_price ),
			'compare' => '>=',
			'type'    => 'DECIMAL(18,6)',
		);
	}
	if ( '' !== $maximum_price && is_numeric( $maximum_price ) ) {
		$meta_query[] = array(
			'key'     => '_price',
			'value'   => max( 0, (float) $maximum_price ),
			'compare' => '<=',
			'type'    => 'DECIMAL(18,6)',
		);
	}
	if ( $meta_query ) {
		$query->set( 'meta_query', $meta_query );
	}

	$tax_query = (array) $query->get( 'tax_query' );
	foreach ( wc_get_attribute_taxonomies() as $attribute ) {
		$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );
		$key      = 'filter_' . $taxonomy;
		if ( empty( $_GET[ $key ] ) || ! taxonomy_exists( $taxonomy ) ) {
			continue;
		}
		$terms = array_values( array_filter( array_map( 'sanitize_title', explode( ',', wp_unslash( (string) $_GET[ $key ] ) ) ) ) );
		if ( $terms ) {
			$tax_query[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $terms,
				'operator' => 'IN',
			);
		}
	}
	if ( $tax_query ) {
		$query->set( 'tax_query', $tax_query );
	}

	$orderby = isset( $_GET['orderby'] ) ? sanitize_key( $_GET['orderby'] ) : ( $discover_view ? '' : 'menu_order' );
	switch ( $orderby ) {
		case 'price':
			$query->set( 'orderby', 'meta_value_num' );
			$query->set( 'order', 'ASC' );
			$query->set( 'meta_key', '_price' );
			break;
		case 'price-desc':
			$query->set( 'orderby', 'meta_value_num' );
			$query->set( 'order', 'DESC' );
			$query->set( 'meta_key', '_price' );
			break;
		case 'popularity':
			$query->set( 'meta_key', 'total_sales' );
			$query->set( 'orderby', 'meta_value_num' );
			$query->set( 'order', 'DESC' );
			break;
		case 'rating':
			$query->set( 'orderby', 'meta_value_num' );
			$query->set( 'meta_key', '_wc_average_rating' );
			$query->set( 'order', 'DESC' );
			break;
		case 'date':
			$query->set( 'orderby', 'date' );
			$query->set( 'order', 'DESC' );
			break;
		case '':
			break;
		case 'menu_order':
		default:
			$query->set( 'orderby', 'menu_order' );
			$query->set( 'order', 'ASC' );
			break;
	}

	$posts_per_page = isset( $_GET['per_page'] ) ? absint( $_GET['per_page'] ) : 0;
	if ( $posts_per_page > 12 && $posts_per_page <= 48 ) {
		$query->set( 'posts_per_page', $posts_per_page );
	}
}
add_action( 'pre_get_posts', 'glissimo_discover_catalog_query' );

/** Return the published product IDs represented by the current collection. */
function glissimo_collection_product_ids(): array {
	$category_id = is_product_category() ? absint( get_queried_object_id() ) : 0;
	$cache_key   = 'gl_collection_products_' . $category_id . '_' . wp_cache_get_last_changed( 'posts' );
	$cached      = wp_cache_get( $cache_key, 'glissimo' );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$args = array(
		'post_type'              => 'product',
		'post_status'            => 'publish',
		'fields'                 => 'ids',
		'posts_per_page'         => 200,
		'no_found_rows'          => true,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
	);
	if ( $category_id ) {
		$args['tax_query'] = array(
			array(
				'taxonomy'         => 'product_cat',
				'field'            => 'term_id',
				'terms'            => array( $category_id ),
				'include_children' => true,
			),
		);
	}

	$product_ids = array_map( 'absint', get_posts( $args ) );
	wp_cache_set( $cache_key, $product_ids, 'glissimo', HOUR_IN_SECONDS );
	return $product_ids;
}

/** Return truthful range and sale facets for the current collection. */
function glissimo_collection_commerce_facets(): array {
	$product_ids = glissimo_collection_product_ids();
	$prices      = array();
	foreach ( $product_ids as $product_id ) {
		$product = wc_get_product( $product_id );
		if ( $product instanceof WC_Product && '' !== $product->get_price( 'edit' ) ) {
			$prices[] = (float) $product->get_price( 'edit' );
		}
	}

	$sale_ids = array_map( 'absint', wc_get_product_ids_on_sale() );
	return array(
		'has_sale' => (bool) array_intersect( $product_ids, $sale_ids ),
		'min_price' => $prices ? min( $prices ) : null,
		'max_price' => $prices ? max( $prices ) : null,
	);
}

/** Return a compact, locale-safe result range without WooCommerce sentence copy. */
function glissimo_collection_result_summary(): string {
	$total        = max( 0, (int) wc_get_loop_prop( 'total', 0 ) );
	$per_page     = max( 1, (int) wc_get_loop_prop( 'per_page', $total ?: 1 ) );
	$current_page = max( 1, (int) wc_get_loop_prop( 'current_page', 1 ) );
	if ( 0 === $total ) {
		return '0 / 0';
	}

	$first = min( $total, ( ( $current_page - 1 ) * $per_page ) + 1 );
	$last  = min( $total, $current_page * $per_page );
	return $first === $last
		? sprintf( '%1$s / %2$s', number_format_i18n( $first ), number_format_i18n( $total ) )
		: sprintf( '%1$s–%2$s / %3$s', number_format_i18n( $first ), number_format_i18n( $last ), number_format_i18n( $total ) );
}

/**
 * Return only product attributes that have terms in the current collection.
 *
 * @return array<int, array{taxonomy:string,label:string,terms:array<int,WP_Term>}>
 */
function glissimo_collection_attribute_filters(): array {
	$category_id = is_product_category() ? absint( get_queried_object_id() ) : 0;
	$cache_key   = 'gl_collection_filters_' . $category_id . '_' . wp_cache_get_last_changed( 'posts' );
	$cached      = wp_cache_get( $cache_key, 'glissimo' );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$product_ids = glissimo_collection_product_ids();
	$filters     = array();
	if ( $product_ids ) {
		foreach ( array_slice( wc_get_attribute_taxonomies(), 0, 6 ) as $attribute ) {
			$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'object_ids' => $product_ids,
					'hide_empty' => true,
					'number'     => 12,
				)
			);
			if ( ! is_wp_error( $terms ) && $terms ) {
				$filters[] = array(
					'taxonomy' => $taxonomy,
					'label'    => wc_attribute_label( $taxonomy ),
					'terms'    => $terms,
				);
			}
		}
	}

	wp_cache_set( $cache_key, $filters, 'glissimo', HOUR_IN_SECONDS );
	return $filters;
}

function glissimo_collection_filters_url( array $overrides = array() ): string {
	$current = array();
	foreach ( wp_unslash( (array) $_GET ) as $key => $value ) {
		if ( is_scalar( $value ) ) {
			$current[ sanitize_key( (string) $key ) ] = sanitize_text_field( (string) $value );
		}
	}
	$overrides = array_filter(
		array_map(
			'sanitize_text_field',
			$overrides
		)
	);
	$query_vars = array_merge( $current, $overrides );
	foreach ( $query_vars as $key => $value ) {
		if ( '' === (string) $value ) {
			unset( $query_vars[ $key ] );
		}
	}
	return esc_url( add_query_arg( $query_vars, '' ) );
}

function glissimo_rating_badge( WC_Product $product ): void {
	$rating = $product->get_average_rating();
	if ( $rating <= 0 ) {
		return;
	}
	$count = (int) $product->get_rating_count();
	?>
	<p class="gl-product-card__rating" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %1$s out of 5', 'glissimo' ), number_format( $rating, 1 ) ) ); ?>">
		<?php echo wp_kses_post( wc_get_rating_html( $rating, $count ) ); ?>
		<span><?php echo esc_html( sprintf( _n( '1 review', '%d reviews', $count, 'glissimo' ), $count ) ); ?></span>
	</p>
	<?php
}

function glissimo_product_savings( WC_Product $product ): string {
	$regular = (float) $product->get_regular_price( 'edit' );
	$sale    = (float) $product->get_sale_price( 'edit' );
	if ( ! $sale || ! $regular || $sale >= $regular ) {
		return '';
	}
	$percentage = (int) round( ( ( $regular - $sale ) / $regular ) * 100 );
	return sprintf( __( 'Save %d%%', 'glissimo' ), $percentage );
}

function glissimo_product_savings_value( WC_Product $product ): string {
	$regular = (float) $product->get_regular_price( 'edit' );
	$sale    = (float) $product->get_sale_price( 'edit' );
	if ( ! $sale || ! $regular || $sale >= $regular ) {
		return '';
	}
	$value = $regular - $sale;
	return wp_strip_all_tags( wc_price( $value ) );
}

function glissimo_product_stock_note( WC_Product $product ): string {
	if ( $product->is_on_backorder( 1 ) ) {
		return __( 'Available on backorder', 'glissimo' );
	}
	if ( $product->is_in_stock() ) {
		return '';
	}
	return __( 'Out of stock', 'glissimo' );
}

function glissimo_product_card( WC_Product $product ): void {
	$permalink = get_permalink( $product->get_id() );
	$savings   = glissimo_product_savings( $product );
	$stock     = glissimo_product_stock_note( $product );
	$bundle    = function_exists( 'glissimo_bundle_definition' ) ? glissimo_bundle_definition( $product->get_id() ) : array();
	$categories = wc_get_product_category_list( $product->get_id(), ', ', '', '' );
	?>
	<article class="gl-product-card <?php echo $product->is_in_stock() ? '' : 'is-out-of-stock'; ?>">
		<a class="gl-product-card__media" href="<?php echo esc_url( $permalink ); ?>">
			<?php
			if ( $product->get_image_id() ) {
				echo wp_get_attachment_image( $product->get_image_id(), 'woocommerce_thumbnail', false, array( 'loading' => 'lazy', 'alt' => $product->get_name() ) );
			} else {
				?>
				<span><?php esc_html_e( 'Product image pending', 'glissimo' ); ?></span>
				<?php
			}
			?>
			<?php if ( $savings ) : ?>
				<b class="gl-badge gl-badge--accent"><?php echo esc_html( $savings ); ?></b>
			<?php endif; ?>
			<?php if ( ! $product->is_in_stock() ) : ?>
				<span class="gl-badge gl-badge--danger"><?php echo esc_html( $stock ); ?></span>
			<?php endif; ?>
		</a>
		<div class="gl-product-card__body">
			<?php if ( $categories ) : ?><p class="gl-product-card__category"><?php echo wp_kses_post( $categories ); ?></p><?php endif; ?>
			<h3><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h3>
			<?php glissimo_rating_badge( $product ); ?>
			<div class="gl-product-card__price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
			<div class="gl-product-card__actions">
			<?php
			if ( $product->is_in_stock() && $bundle ) :
				?>
				<form method="post" class="gl-bundle-fallback"><input type="hidden" name="glissimo_bundle_offer" value="<?php echo esc_attr( $product->get_id() ); ?>"><input type="hidden" name="glissimo_bundle_nonce" value="<?php echo esc_attr( wp_create_nonce( 'glissimo_bundle_' . $product->get_id() ) ); ?>"><button class="gl-product-card__quick-add gl-product-card__bundle-add gl-button gl-button--compact" type="submit" data-gl-bundle-add data-offer-id="<?php echo esc_attr( $product->get_id() ); ?>"><?php esc_html_e( 'Add bundle', 'glissimo' ); ?></button></form>
			<?php elseif ( $product->is_in_stock() && $product->is_type( 'simple' ) ) :
				?>
				<a class="gl-product-card__quick-add button add_to_cart_button ajax_add_to_cart" href="<?php echo esc_url( $product->add_to_cart_url() ); ?>" data-quantity="1" data-product_id="<?php echo esc_attr( $product->get_id() ); ?>" data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>"><?php esc_html_e( 'Quick add', 'glissimo' ); ?></a>
			<?php elseif ( ! $product->is_in_stock() ) : ?>
				<span class="gl-product-card__status"><?php esc_html_e( 'Currently unavailable', 'glissimo' ); ?></span>
			<?php else : ?>
				<a class="gl-product-card__quick-add gl-button gl-button--secondary gl-button--compact" href="<?php echo esc_url( $permalink ); ?>"><?php esc_html_e( 'Choose options', 'glissimo' ); ?></a>
			<?php endif; ?>
			<?php if ( glissimo_phase2_enabled( 'wishlist' ) ) : ?><button type="button" class="gl-product-card__save gl-button gl-button--tertiary" data-gl-wishlist-toggle data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" aria-pressed="false" aria-label="<?php esc_attr_e( 'Save for later', 'glissimo' ); ?>"><?php echo glissimo_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button><?php endif; ?>
			</div>
		</div>
	</article>
	<?php
}

function glissimo_render_product_card( WC_Product $product ): void { glissimo_product_card( $product ); }

/** Return the supported editorial routes owned by the shared branded page template. */
function glissimo_editorial_page_slugs(): array {
	return array( 'about-glissimo', 'faq', 'contact', 'customer-service', 'shipping-returns', 'warranty', 'product-care', 'bundles', 'privacy-policy', 'terms-conditions', 'cookie-policy' );
}

function glissimo_editorial_page_template( string $template ): string {
	if ( is_page( glissimo_editorial_page_slugs() ) ) {
		$candidate = get_theme_file_path( '/page-brand.php' );
		if ( is_file( $candidate ) ) {
			return $candidate;
		}
	}
	return $template;
}
add_filter( 'template_include', 'glissimo_editorial_page_template', 40 );

/** Contact form: local-safe WordPress mail handoff with no customer data persisted by the theme. */
function glissimo_handle_contact_form(): void {
	$redirect = wp_get_referer() ?: home_url( '/contact/' );
	if ( ! isset( $_POST['glissimo_contact_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['glissimo_contact_nonce'] ) ), 'glissimo_contact' ) ) {
		wp_safe_redirect( add_query_arg( 'contact_status', 'invalid', $redirect ) );
		exit;
	}
	if ( ! empty( $_POST['company'] ) ) {
		wp_safe_redirect( add_query_arg( 'contact_status', 'sent', $redirect ) );
		exit;
	}
	$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$order   = sanitize_text_field( wp_unslash( $_POST['order_number'] ?? '' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );
	if ( '' === $name || ! is_email( $email ) || '' === $message ) {
		wp_safe_redirect( add_query_arg( 'contact_status', 'invalid', $redirect ) );
		exit;
	}
	$subject = sprintf( __( 'Glissimo support request from %s', 'glissimo' ), $name );
	$body    = $message . ( $order ? "\n\n" . sprintf( __( 'Order reference: %s', 'glissimo' ), $order ) : '' );
	$sent    = wp_mail( get_option( 'admin_email' ), $subject, $body, array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );
	wp_safe_redirect( add_query_arg( 'contact_status', $sent ? 'sent' : 'error', $redirect ) );
	exit;
}
add_action( 'admin_post_glissimo_contact', 'glissimo_handle_contact_form' );
add_action( 'admin_post_nopriv_glissimo_contact', 'glissimo_handle_contact_form' );

function glissimo_product_story_meta( int $product_id ): array {
	if ( class_exists( '\\Advertpreneur\\Core\\Sites\\Glissimo\\ProductStory' ) ) {
		return \Advertpreneur\Core\Sites\Glissimo\ProductStory::get( $product_id );
	}

	return array();
}

function glissimo_add_to_cart_from_fbt(): void {
	check_ajax_referer( 'glissimo_fbt', 'nonce' );

	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'WooCommerce is not available.', 'glissimo' ),
			)
		);
	}

	$anchor_id = absint( $_POST['anchor_product_id'] ?? 0 );
	$story     = $anchor_id ? glissimo_product_story_meta( $anchor_id ) : array();
	$allowed_ids = array_values( array_unique( array_map( 'absint', (array) ( $story['fbt_product_ids'] ?? array() ) ) ) );
	$ids_raw = $_POST['product_ids'] ?? '';
	if ( is_string( $ids_raw ) ) {
		$ids_raw = json_decode( wp_unslash( $ids_raw ), true );
	}
	$ids    = is_array( $ids_raw ) ? array_map( 'absint', $ids_raw ) : array();
	$ids    = array_values( array_unique( array_filter( $ids ) ) );
	$result = array();
	$analytics_items = array();
	$analytics_value = 0.0;

	if ( ! $anchor_id || ! $ids || array_diff( $ids, $allowed_ids ) ) {
		wp_send_json_error(
			array(
				'message' => esc_html__( 'The selected product set is not available.', 'glissimo' ),
			)
		);
	}

	$products = array();
	foreach ( $ids as $product_id ) {
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_purchasable() || $product->is_type( 'variable' ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'One or more selected products cannot be purchased.', 'glissimo' ) ) );
		}
		$products[] = $product;
	}

	$added_keys = array();
	foreach ( $products as $product ) {
		$product_id = $product->get_id();
		$qty = 1;
		$added = WC()->cart->add_to_cart( $product_id, $qty );
		if ( $added ) {
			$result[] = $product_id;
			$added_keys[] = $added;
			$analytics_items[] = glissimo_analytics_item( $product, $qty );
			$analytics_value += (float) wc_get_price_to_display( $product ) * $qty;
			continue;
		}
		foreach ( $added_keys as $cart_item_key ) {
			WC()->cart->remove_cart_item( $cart_item_key );
		}
		wp_send_json_error(
			array(
				'message' => esc_html__( 'The selected set could not be added. Your cart was not changed.', 'glissimo' ),
			)
		);
	}

	wp_send_json_success(
		array(
			'count'    => WC()->cart->get_cart_contents_count(),
			'added'    => $result,
			'event'    => array( 'event' => 'fbt_interaction', 'event_id' => 'fbt_' . wp_generate_uuid4(), 'action' => 'add', 'product_ids' => $result ),
			'events'   => array(
				array( 'event' => 'fbt_interaction', 'event_id' => 'fbt_' . wp_generate_uuid4(), 'action' => 'add', 'product_ids' => $result ),
				array( 'event' => 'add_to_cart', 'event_id' => 'fbt_add_' . wp_generate_uuid4(), 'ecommerce' => array( 'currency' => get_woocommerce_currency(), 'value' => $analytics_value, 'items' => $analytics_items ) ),
			),
			'message'  => sprintf(
			// translators: %s number of products
				_n( '%s item added.', '%s items added.', count( $result ), 'glissimo' ),
				count( $result )
			),
		)
	);
}

add_action( 'wp_ajax_glissimo_fbt_add_to_cart', 'glissimo_add_to_cart_from_fbt' );
add_action( 'wp_ajax_nopriv_glissimo_fbt_add_to_cart', 'glissimo_add_to_cart_from_fbt' );


/** Use the supplied Glissimo mark as a fallback site icon when WordPress has no custom icon. */
add_filter( 'get_site_icon_url', static function ( $url ) {
	return $url ?: get_theme_file_uri( '/assets/images/glissimo-logo.jpg' );
}, 10, 1 );
