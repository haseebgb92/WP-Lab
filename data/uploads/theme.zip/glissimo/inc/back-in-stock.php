<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/** @return array{message:string,duplicate:bool,key:string}|WP_Error */
function glissimo_back_in_stock_register( string $email, bool $consent, int $product_id, int $variation_id = 0 ): array|WP_Error {
	$email = sanitize_email( $email ); $product_id = absint( $product_id ); $variation_id = absint( $variation_id ); $product = wc_get_product( $variation_id ?: $product_id );
	$variation_valid = ! $variation_id || ( $product instanceof WC_Product_Variation && $product->get_parent_id() === $product_id );
	if ( ! glissimo_phase2_enabled( 'back_in_stock' ) || ! is_email( $email ) || ! $consent || ! $product || ! $variation_valid || 'publish' !== get_post_status( $product_id ) || $product->is_in_stock() ) { return new WP_Error( 'invalid_subscription', __( 'Check your email and consent, then try again.', 'glissimo' ) ); }
	$subscription_key = 'glissimo_bis_' . hash( 'sha256', strtolower( $email ) . '|' . $product->get_id() );
	if ( get_transient( $subscription_key ) ) { return array( 'message' => __( 'You are already registered for this availability update.', 'glissimo' ), 'duplicate' => true, 'key' => $subscription_key ); }
	$payload = array( 'product_id' => $product->get_id(), 'parent_id' => $variation_id ? $product_id : 0, 'source' => 'glissimo_product' ); $handled = apply_filters( 'glissimo_back_in_stock_subscribe', false, $email, $payload );
	$environment = defined( 'WP_ENVIRONMENT_TYPE' ) ? WP_ENVIRONMENT_TYPE : wp_get_environment_type();
	if ( ! $handled && 'production' === $environment ) { return new WP_Error( 'provider_unavailable', __( 'Notifications are not connected yet.', 'glissimo' ) ); }
	set_transient( $subscription_key, 1, DAY_IN_SECONDS ); do_action( 'glissimo_phase2_event', 'back_in_stock_signup', array( 'product_id' => $product->get_id(), 'variation_id' => $variation_id ) );
	return array( 'message' => __( 'Your request has been recorded.', 'glissimo' ), 'duplicate' => false, 'key' => $subscription_key );
}
function glissimo_back_in_stock_subscribe(): void {
	check_ajax_referer( 'glissimo_phase2', 'nonce' );
	$result = glissimo_back_in_stock_register( (string) wp_unslash( $_POST['email'] ?? '' ), ! empty( $_POST['consent'] ), absint( $_POST['product_id'] ?? 0 ), absint( $_POST['variation_id'] ?? 0 ) );
	if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 'provider_unavailable' === $result->get_error_code() ? 503 : 422 ); }
	wp_send_json_success( array( 'message' => $result['message'], 'duplicate' => $result['duplicate'] ) );
}
add_action( 'wp_ajax_glissimo_back_in_stock', 'glissimo_back_in_stock_subscribe' ); add_action( 'wp_ajax_nopriv_glissimo_back_in_stock', 'glissimo_back_in_stock_subscribe' );
function glissimo_back_in_stock_form(): void { if ( ! glissimo_phase2_enabled( 'back_in_stock' ) ) { return; } global $product; if ( ! $product instanceof WC_Product || ( $product->is_in_stock() && ! $product->is_type( 'variable' ) ) ) { return; } $s = glissimo_phase2_settings()['back_in_stock']; $hidden = $product->is_in_stock(); ?><section class="gl-stock-alert" data-gl-stock-alert <?php echo $hidden ? 'hidden' : ''; ?>><h2><?php echo esc_html( $s['heading'] ); ?></h2><?php if ( $s['copy'] ) : ?><p><?php echo esc_html( $s['copy'] ); ?></p><?php endif; ?><form data-gl-stock-form><input type="hidden" name="product_id" value="<?php echo esc_attr( $product->get_id() ); ?>"><input type="hidden" name="variation_id" value=""><label><span><?php esc_html_e( 'Email address', 'glissimo' ); ?></span><input type="email" name="email" required autocomplete="email"></label><label class="gl-check"><input type="checkbox" name="consent" value="1" required><span><?php echo esc_html( $s['consent_copy'] ?: __( 'Send me this availability notification.', 'glissimo' ) ); ?></span></label><button class="gl-button" type="submit"><?php esc_html_e( 'Notify me', 'glissimo' ); ?></button><p data-gl-form-status aria-live="polite"></p></form></section><?php }
add_action( 'woocommerce_single_product_summary', 'glissimo_back_in_stock_form', 35 );
