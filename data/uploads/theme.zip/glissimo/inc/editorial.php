<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** @return array<string,mixed> */
function glissimo_phase3_settings(): array { return class_exists( '\\Advertpreneur\\Core\\Sites\\Glissimo\\Phase3Settings' ) ? \Advertpreneur\Core\Sites\Glissimo\Phase3Settings::all() : array(); }

/** @return array<string,mixed> */
function glissimo_editorial_meta( int $post_id = 0 ): array { return (array) get_post_meta( $post_id ?: get_the_ID(), '_glissimo_editorial', true ); }

/** @return array<int,string> */
function glissimo_editorial_lines( $value ): array { return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) $value ) ?: array() ) ) ); }

function glissimo_editorial_card( \WP_Post $post, string $size = 'large', string $variant = 'standard' ): void {
	$type = get_post_type( $post ); $terms = get_the_terms( $post, 'glissimo_recipe' === $type ? 'gl_recipe_course' : 'gl_guide_topic' );
	$label = is_array( $terms ) && $terms ? $terms[0]->name : ( 'glissimo_recipe' === $type ? __( 'Recipe', 'glissimo' ) : __( 'Guide', 'glissimo' ) );
	?><article class="gl-editorial-card gl-editorial-card--<?php echo esc_attr( sanitize_html_class( $variant ) ); ?>"><a class="gl-editorial-card__media" href="<?php echo esc_url( get_permalink( $post ) ); ?>" aria-hidden="true" tabindex="-1"><?php if ( has_post_thumbnail( $post ) ) { echo get_the_post_thumbnail( $post, $size, array( 'loading' => 'lazy', 'alt' => '' ) ); } else { ?><span aria-hidden="true"><?php echo glissimo_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><?php } ?></a><div class="gl-editorial-card__body"><p class="gl-editorial-card__type"><?php echo esc_html( $label ); ?></p><h3><a href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a></h3><?php if ( has_excerpt( $post ) ) : ?><p><?php echo esc_html( get_the_excerpt( $post ) ); ?></p><?php endif; ?><a class="gl-editorial-card__cta" href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php esc_html_e( 'Read the story', 'glissimo' ); ?></a></div></article><?php
}

/** @param array<int,int> $ids */
function glissimo_render_editorial_products( array $ids, string $heading ): void {
	$products = array_values( array_filter( array_map( 'wc_get_product', array_unique( array_map( 'absint', $ids ) ) ), static fn( $product ) => $product instanceof WC_Product && $product->is_visible() ) );
	if ( ! $products ) { return; }
	?><section class="gl-editorial-products gl-container"><header class="gl-section-heading"><p><?php esc_html_e( 'Shop the story', 'glissimo' ); ?></p><h2><?php echo esc_html( $heading ); ?></h2></header><div class="gl-product-rail" aria-label="<?php echo esc_attr( $heading ); ?>"><?php foreach ( $products as $product ) { glissimo_product_card( $product ); } ?></div></section><?php
}

function glissimo_render_product_editorial( WC_Product $product ): void {
	static $rendered = array();
	if ( isset( $rendered[ $product->get_id() ] ) ) { return; }
	$query = new WP_Query( array( 'post_type' => array( 'glissimo_recipe', 'glissimo_guide' ), 'post_status' => 'publish', 'posts_per_page' => 4, 'meta_query' => array( array( 'key' => '_glissimo_editorial', 'value' => sprintf( 'i:%d;', $product->get_id() ), 'compare' => 'LIKE' ) ), 'no_found_rows' => true ) );
	if ( ! $query->have_posts() ) { return; }
	$rendered[ $product->get_id() ] = true;
	$posts = $query->posts;
	wp_reset_postdata();
	$featured = array_shift( $posts );
	?><section class="gl-product-editorial gl-container" aria-labelledby="gl-product-editorial-heading"><header class="gl-product-editorial__heading"><p><?php esc_html_e( 'From the Glissimo Kitchen', 'glissimo' ); ?></p><h2 id="gl-product-editorial-heading"><?php esc_html_e( 'Cook, care and get more from every piece', 'glissimo' ); ?></h2></header><?php if ( $featured instanceof WP_Post ) : ?><div class="gl-product-editorial__featured"><?php glissimo_editorial_card( $featured, 'large', 'featured' ); ?></div><?php endif; ?><?php if ( $posts ) : ?><div class="gl-product-editorial__supporting"><div class="gl-editorial-rail" data-gl-rail data-gl-rail-item=".gl-editorial-card" aria-label="<?php esc_attr_e( 'More from the Glissimo Kitchen', 'glissimo' ); ?>"><?php foreach ( $posts as $post ) { glissimo_editorial_card( $post, 'medium_large', 'compact' ); } ?></div></div><?php endif; ?></section><?php
}

/** @param array<int,int> $ids */
function glissimo_render_related_editorial( array $ids ): void {
	$posts = get_posts( array( 'post_type' => array( 'glissimo_recipe', 'glissimo_guide' ), 'post_status' => 'publish', 'post__in' => array_filter( array_map( 'absint', $ids ) ), 'orderby' => 'post__in', 'posts_per_page' => 4 ) );
	if ( ! $posts ) { return; }
	?><section class="gl-editorial-section gl-editorial-section--tint"><div class="gl-container"><header class="gl-editorial-heading"><div><p class="gl-eyebrow"><?php esc_html_e( 'Keep exploring', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Related from the Glissimo Kitchen', 'glissimo' ); ?></h2></div></header><div class="gl-editorial-rail"><?php foreach ( $posts as $post ) { glissimo_editorial_card( $post ); } ?></div></div></section><?php
}

add_action( 'pre_get_posts', static function ( WP_Query $query ): void {
	if ( ! is_admin() && $query->is_main_query() && $query->is_search() && isset( $_GET['gl_kitchen_search'] ) ) {
		$query->set( 'post_type', array( 'glissimo_recipe', 'glissimo_guide' ) );
	}
} );

function glissimo_recipe_schema(): void {
	if ( ! is_singular( 'glissimo_recipe' ) ) { return; } $post = get_queried_object(); if ( ! $post instanceof WP_Post ) { return; }
	$m = glissimo_editorial_meta( $post->ID ); $ingredients = glissimo_editorial_lines( $m['ingredients'] ?? '' ); $instructions = glissimo_editorial_lines( $m['instructions'] ?? '' ); if ( ! $ingredients || ! $instructions ) { return; }
	$schema = array( '@context' => 'https://schema.org', '@type' => 'Recipe', 'name' => get_the_title( $post ), 'description' => get_the_excerpt( $post ), 'recipeIngredient' => $ingredients, 'recipeInstructions' => array_map( static fn( $step ) => array( '@type' => 'HowToStep', 'text' => $step ), $instructions ) );
	if ( has_post_thumbnail( $post ) ) { $schema['image'] = array( wp_get_attachment_image_url( get_post_thumbnail_id( $post ), 'full' ) ); }
	if ( ! empty( $m['prep_minutes'] ) ) { $schema['prepTime'] = 'PT' . absint( $m['prep_minutes'] ) . 'M'; }
	if ( ! empty( $m['cook_minutes'] ) ) { $schema['cookTime'] = 'PT' . absint( $m['cook_minutes'] ) . 'M'; }
	if ( ! empty( $m['servings'] ) ) { $schema['recipeYield'] = (string) $m['servings']; }
	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
}
add_action( 'wp_head', 'glissimo_recipe_schema', 25 );

add_action( 'woocommerce_after_single_product_summary', static function (): void { global $product; if ( $product instanceof WC_Product ) { glissimo_render_product_editorial( $product ); } }, 35 );
