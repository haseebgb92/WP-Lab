<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function glissimo_builder_steps(): array {
	$s = glissimo_phase2_settings()['bundle_builder'] ?? array(); $steps = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $s['steps'] ?? '' ) ) ?: array() as $line ) {
		$p = array_map( 'trim', explode( '|', $line ) ); if ( count( $p ) < 5 ) { continue; }
		$steps[] = array( 'key' => sanitize_key( $p[0] ), 'label' => sanitize_text_field( $p[1] ), 'required' => 'optional' !== sanitize_key( $p[2] ), 'category_ids' => array_values( array_filter( array_map( 'absint', preg_split( '/[\s,]+/', $p[3] ) ) ) ), 'product_ids' => array_values( array_filter( array_map( 'absint', preg_split( '/[\s,]+/', $p[4] ) ) ) ) );
	}
	return $steps;
}

function glissimo_builder_products( array $step ): array {
	$ids = $step['product_ids'];
	if ( ! $ids && $step['category_ids'] ) { $ids = wc_get_products( array( 'status' => 'publish', 'limit' => 24, 'category' => array_map( static fn( $id ) => get_term_field( 'slug', $id, 'product_cat' ), $step['category_ids'] ), 'return' => 'ids' ) ); }
	return array_values( array_filter( array_map( 'wc_get_product', $ids ), static fn( $p ) => $p instanceof WC_Product && $p->is_visible() ) );
}

function glissimo_builder_choices( array $step ): array {
	$choices = array();
	foreach ( glissimo_builder_products( $step ) as $product ) {
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_available_variations() as $data ) {
				$variation = wc_get_product( absint( $data['variation_id'] ?? 0 ) );
				if ( ! $variation || ! $variation->is_purchasable() || ! $variation->is_in_stock() ) { continue; }
				$choices[] = array( 'value' => $product->get_id() . ':' . $variation->get_id(), 'product_id' => $product->get_id(), 'variation_id' => $variation->get_id(), 'product' => $variation, 'name' => $product->get_name() . ' — ' . wc_get_formatted_variation( $variation, true, false, false ) );
			}
		} else {
			$choices[] = array( 'value' => (string) $product->get_id(), 'product_id' => $product->get_id(), 'variation_id' => 0, 'product' => $product, 'name' => $product->get_name() );
		}
	}
	return $choices;
}

/** @return array<int,array<string,mixed>>|WP_Error */
function glissimo_builder_validate_selection( array $submitted ): array|WP_Error {
	$selected = array();
	foreach ( glissimo_builder_steps() as $step ) {
		$value = sanitize_text_field( $submitted[ $step['key'] ] ?? '' );
		if ( ! $value && $step['required'] ) { return new WP_Error( 'required_step', sprintf( __( 'Choose an option for %s.', 'glissimo' ), $step['label'] ) ); }
		if ( ! $value ) { continue; }
		$allowed = array_column( glissimo_builder_choices( $step ), null, 'value' );
		$choice = $allowed[ $value ] ?? null; $product = $choice ? $choice['product'] : false;
		if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) { return new WP_Error( 'invalid_product', __( 'One of the selected products is no longer available.', 'glissimo' ) ); }
		$choice['step_key'] = $step['key'];
		$selected[] = $choice;
	}
	return $selected;
}

function glissimo_builder_add_selection( array $raw ) {
	if ( ! glissimo_phase2_enabled( 'bundle_builder' ) || ! function_exists( 'WC' ) || ! WC()->cart ) { return new WP_Error( 'builder_unavailable', __( 'The bundle builder is not available.', 'glissimo' ) ); }
	$products = glissimo_builder_validate_selection( $raw );
	if ( is_wp_error( $products ) ) { return $products; }
	$settings = glissimo_phase2_settings()['bundle_builder']; $discount = (float) ( $settings['discount_percent'] ?? 0 ); $group = wp_generate_uuid4(); $added = array();
	foreach ( $products as $choice ) {
		$variation = $choice['variation_id'] ? wc_get_product( $choice['variation_id'] ) : null;
		$key = WC()->cart->add_to_cart( $choice['product_id'], 1, $choice['variation_id'], $variation instanceof WC_Product_Variation ? $variation->get_variation_attributes() : array(), array( 'glissimo_builder_group' => $group, 'glissimo_builder_step' => $choice['step_key'], 'glissimo_builder_discount' => $discount, 'glissimo_builder_allow_coupons' => ! empty( $settings['allow_coupons'] ), 'glissimo_builder_title' => (string) $settings['title'] ) );
		if ( ! $key ) { foreach ( $added as $cart_key ) { WC()->cart->remove_cart_item( $cart_key ); } return new WP_Error( 'builder_add_failed', __( 'The configuration could not be added safely.', 'glissimo' ) ); }
		$added[] = $key;
	}
	WC()->cart->calculate_totals();
	do_action( 'glissimo_phase2_event', 'bundle_builder_complete', array( 'group_id' => $group, 'item_count' => count( $added ) ) );
	return $added;
}

function glissimo_builder_add_to_cart(): void {
	check_ajax_referer( 'glissimo_phase2', 'nonce' );
	$raw = is_array( $_POST['selections'] ?? null ) ? wp_unslash( $_POST['selections'] ) : array();
	$added = glissimo_builder_add_selection( $raw );
	if ( is_wp_error( $added ) ) { wp_send_json_error( array( 'message' => $added->get_error_message() ), 'builder_unavailable' === $added->get_error_code() ? 400 : 422 ); }
	wp_send_json_success( array( 'cartUrl' => wc_get_cart_url(), 'count' => WC()->cart->get_cart_contents_count(), 'total' => wp_strip_all_tags( WC()->cart->get_cart_total() ) ) );
}
add_action( 'wp_ajax_glissimo_builder_add', 'glissimo_builder_add_to_cart' ); add_action( 'wp_ajax_nopriv_glissimo_builder_add', 'glissimo_builder_add_to_cart' );

function glissimo_builder_fallback_submit(): void {
	if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || empty( $_POST['glissimo_builder_submit'] ) || ! is_page( 'build-your-kitchen' ) ) { return; }
	$nonce = sanitize_text_field( wp_unslash( $_POST['glissimo_builder_nonce'] ?? '' ) );
	if ( ! wp_verify_nonce( $nonce, 'glissimo_builder_submit' ) ) { wp_die( esc_html__( 'The bundle request could not be verified.', 'glissimo' ), 403 ); }
	$raw = is_array( $_POST['selections'] ?? null ) ? wp_unslash( $_POST['selections'] ) : array();
	$result = glissimo_builder_add_selection( $raw );
	if ( is_wp_error( $result ) ) { wc_add_notice( $result->get_error_message(), 'error' ); wp_safe_redirect( get_permalink() ); exit; }
	wp_safe_redirect( wc_get_cart_url() ); exit;
}
add_action( 'template_redirect', 'glissimo_builder_fallback_submit', 5 );

function glissimo_builder_prices( WC_Cart $cart ): void {
	if ( is_admin() && ! wp_doing_ajax() ) { return; }
	foreach ( $cart->get_cart() as $key => $item ) { if ( empty( $item['glissimo_builder_group'] ) || ! $item['data'] instanceof WC_Product ) { continue; } $cart->cart_contents[ $key ]['quantity'] = 1; $authoritative = wc_get_product( $item['variation_id'] ?: $item['product_id'] ); if ( ! $authoritative ) { continue; } $discount = min( 50, max( 0, (float) ( $item['glissimo_builder_discount'] ?? 0 ) ) ); $item['data']->set_price( (float) $authoritative->get_price( 'edit' ) * ( 1 - $discount / 100 ) ); }
}
add_action( 'woocommerce_before_calculate_totals', 'glissimo_builder_prices', 15 );
function glissimo_remove_builder_group( string $cart_item_key, WC_Cart $cart ): void { static $removing = false; if ( $removing ) { return; } $removed = $cart->removed_cart_contents[ $cart_item_key ] ?? array(); $group = sanitize_text_field( $removed['glissimo_builder_group'] ?? '' ); if ( ! $group ) { return; } $removing = true; foreach ( $cart->get_cart() as $key => $item ) { if ( $key !== $cart_item_key && $group === (string) ( $item['glissimo_builder_group'] ?? '' ) ) { $cart->remove_cart_item( $key ); } } $removing = false; }
add_action( 'woocommerce_cart_item_removed', 'glissimo_remove_builder_group', 20, 2 );
function glissimo_builder_order_meta( WC_Order_Item_Product $item, string $key, array $values ): void { if ( ! empty( $values['glissimo_builder_group'] ) ) { $item->add_meta_data( '_glissimo_builder_group', sanitize_text_field( $values['glissimo_builder_group'] ), true ); $item->add_meta_data( '_glissimo_builder_step', sanitize_key( $values['glissimo_builder_step'] ?? '' ), true ); $item->add_meta_data( __( 'Build Your Kitchen', 'glissimo' ), sanitize_text_field( $values['glissimo_builder_title'] ?? '' ), true ); } }
add_action( 'woocommerce_checkout_create_order_line_item', 'glissimo_builder_order_meta', 10, 3 );
