<?php
/**
 * Small, server-authoritative Sprint 3 promotion services.
 *
 * Precedence: dedicated bundle allocation and gifts are fixed; coupons do not
 * discount bundles, gifts, or order bumps; any coupon suppresses quantity
 * breaks; sale products never receive quantity breaks; FBT products remain
 * ordinary WooCommerce cart lines.
 *
 * @package Glissimo
 */

defined( 'ABSPATH' ) || exit;

function glissimo_bundle_assembly_active( ?bool $set = null ): bool {
	static $active = false;
	if ( null !== $set ) {
		$active = $set;
	}
	return $active;
}

function glissimo_cart_item_base_price( array $cart_item ): float {
	$product = wc_get_product( absint( $cart_item['variation_id'] ?? 0 ) ?: absint( $cart_item['product_id'] ?? 0 ) );
	return $product ? (float) $product->get_price( 'edit' ) : 0.0;
}

function glissimo_reject_direct_bundle_offer( bool $valid, int $product_id ): bool {
	if ( $valid && glissimo_bundle_definition( $product_id ) ) {
		wc_add_notice( __( 'Please use the bundle purchase control so every included product is added safely.', 'glissimo' ), 'error' );
		return false;
	}
	return $valid;
}
add_filter( 'woocommerce_add_to_cart_validation', 'glissimo_reject_direct_bundle_offer', 10, 2 );

/**
 * Keep server-owned promotional lines atomic across classic cart and Store API.
 */
function glissimo_enforce_promotional_cart_integrity( WC_Cart $cart ): void {
	if ( glissimo_bundle_assembly_active() ) {
		return;
	}
	$groups = array();
	foreach ( $cart->get_cart() as $key => $item ) {
		if ( ! empty( $item['glissimo_free_gift'] ) || ! empty( $item['glissimo_bundle_group'] ) || ! empty( $item['glissimo_order_bump'] ) ) {
			$cart->cart_contents[ $key ]['quantity'] = 1;
		}
		if ( ! empty( $item['glissimo_bundle_group'] ) ) {
			$groups[ (string) $item['glissimo_bundle_group'] ][ $key ] = $item;
		}
	}
	foreach ( $groups as $items ) {
		$first = reset( $items );
		$definition = glissimo_bundle_definition( absint( $first['glissimo_bundle_offer_id'] ?? 0 ) );
		$expected = array_map( 'absint', (array) ( $definition['components'] ?? array() ) );
		$actual = array();
		foreach ( $items as $item ) {
			$actual[] = absint( $item['variation_id'] ?? 0 ) ?: absint( $item['product_id'] ?? 0 );
		}
		sort( $expected );
		sort( $actual );
		if ( ! $definition || $expected !== $actual ) {
			foreach ( array_keys( $items ) as $key ) {
				$cart->remove_cart_item( $key );
			}
			continue;
		}

		$component_prices = array();
		$item_keys_by_id = array();
		foreach ( $items as $key => $item ) {
			$item_id = absint( $item['variation_id'] ?? 0 ) ?: absint( $item['product_id'] ?? 0 );
			$item_keys_by_id[ $item_id ] = $key;
		}
		foreach ( $definition['components'] as $component_id ) {
			$component = wc_get_product( $component_id );
			if ( ! $component || ! $component->is_purchasable() || ! $component->is_in_stock() ) {
				$component_prices = array();
				break;
			}
			$component_prices[] = (float) $component->get_price( 'edit' );
		}
		$offer_price = (float) $definition['offer']->get_price( 'edit' );
		if ( ! $component_prices || $offer_price < 0 || $offer_price > array_sum( $component_prices ) ) {
			foreach ( array_keys( $items ) as $key ) {
				$cart->remove_cart_item( $key );
			}
			continue;
		}
		$allocations = glissimo_allocate_bundle_minor_units( $component_prices, $offer_price );
		foreach ( $definition['components'] as $index => $component_id ) {
			$key = $item_keys_by_id[ $component_id ];
			$cart->cart_contents[ $key ]['glissimo_bundle_allocated_price'] = $allocations[ $index ];
		}
	}
}
add_action( 'woocommerce_before_calculate_totals', 'glissimo_enforce_promotional_cart_integrity', 10 );

function glissimo_remove_bundle_group_after_native_removal( string $removed_key, WC_Cart $cart ): void {
	static $removing = false;
	if ( $removing ) {
		return;
	}
	$removed = $cart->removed_cart_contents[ $removed_key ] ?? array();
	$group = (string) ( $removed['glissimo_bundle_group'] ?? '' );
	if ( '' === $group ) {
		return;
	}
	$removing = true;
	foreach ( $cart->get_cart() as $key => $item ) {
		if ( $group === (string) ( $item['glissimo_bundle_group'] ?? '' ) ) {
			$cart->remove_cart_item( $key );
		}
	}
	$removing = false;
}
add_action( 'woocommerce_cart_item_removed', 'glissimo_remove_bundle_group_after_native_removal', 8, 2 );

function glissimo_quantity_break_percent( array $cart_item, WC_Cart $cart ): float {
	if ( $cart->has_discount() || ! empty( $cart_item['glissimo_bundle_group'] ) || ! empty( $cart_item['glissimo_builder_group'] ) || ! empty( $cart_item['glissimo_free_gift'] ) || ! empty( $cart_item['glissimo_order_bump'] ) ) {
		return 0.0;
	}
	$product_id = absint( $cart_item['product_id'] ?? 0 );
	$product = wc_get_product( absint( $cart_item['variation_id'] ?? 0 ) ?: $product_id );
	if ( ! $product || $product->is_on_sale() ) {
		return 0.0;
	}
	$story = glissimo_product_story_meta( $product_id );
	$rules = is_array( $story['quantity_breaks'] ?? null ) ? $story['quantity_breaks'] : array();
	if ( empty( $rules['enabled'] ) ) {
		return 0.0;
	}
	$quantity = max( 0, (int) ( $cart_item['quantity'] ?? 0 ) );
	if ( $quantity >= 3 ) {
		return min( 50, max( 0, (float) ( $rules['qty_3'] ?? 0 ) ) );
	}
	if ( 2 === $quantity ) {
		return min( 50, max( 0, (float) ( $rules['qty_2'] ?? 0 ) ) );
	}
	return 0.0;
}

function glissimo_apply_quantity_breaks( WC_Cart $cart ): void {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return;
	}
	foreach ( $cart->get_cart() as $cart_item ) {
		if ( empty( $cart_item['data'] ) || ! $cart_item['data'] instanceof WC_Product ) {
			continue;
		}
		$base = glissimo_cart_item_base_price( $cart_item );
		if ( ! empty( $cart_item['glissimo_free_gift'] ) ) {
			$cart_item['data']->set_price( 0 );
			continue;
		}
		if ( isset( $cart_item['glissimo_bundle_allocated_price'] ) ) {
			$cart_item['data']->set_price( (float) $cart_item['glissimo_bundle_allocated_price'] );
			continue;
		}
		$percent = glissimo_quantity_break_percent( $cart_item, $cart );
		$cart_item['data']->set_price( $percent > 0 ? $base * ( 1 - ( $percent / 100 ) ) : $base );
	}
}
add_action( 'woocommerce_before_calculate_totals', 'glissimo_apply_quantity_breaks', 20 );

function glissimo_merchandise_subtotal( WC_Cart $cart ): float {
	$total = 0.0;
	foreach ( $cart->get_cart() as $item ) {
		if ( ! empty( $item['glissimo_free_gift'] ) || empty( $item['data'] ) || ! $item['data'] instanceof WC_Product ) {
			continue;
		}
		$unit = isset( $item['glissimo_bundle_allocated_price'] )
			? (float) $item['glissimo_bundle_allocated_price']
			: glissimo_cart_item_base_price( $item );
		$percent = glissimo_quantity_break_percent( $item, $cart );
		if ( $percent > 0 ) {
			$unit *= 1 - ( $percent / 100 );
		}
		$total += $unit * max( 1, (int) ( $item['quantity'] ?? 1 ) );
	}
	return max( 0, $total - (float) $cart->get_discount_total() );
}

function glissimo_sync_free_gift(): void {
	static $syncing = false;
	if ( $syncing || glissimo_bundle_assembly_active() || ! function_exists( 'WC' ) || ! WC()->cart ) {
		return;
	}
	$syncing = true;
	$settings = glissimo_core_settings();
	$config = $settings['free_gift'] ?? array();
	$gift_id = absint( $config['product_id'] ?? 0 );
	$threshold = (float) ( $config['threshold'] ?? 0 );
	$gift = $gift_id ? wc_get_product( $gift_id ) : false;
	$gift_available = $gift && $gift->is_type( 'simple' ) && $gift->is_purchasable() && $gift->is_in_stock() && $gift->has_enough_stock( 1 );
	$enabled = ! empty( $config['enabled'] ) && $gift_id > 0 && $threshold > 0 && $gift_available;
	$subtotal = glissimo_merchandise_subtotal( WC()->cart );
	$qualifies = $enabled && $subtotal >= $threshold;
	$gift_keys = array();
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		if ( ! empty( $item['glissimo_free_gift'] ) ) {
			$item_id = absint( $item['variation_id'] ?? 0 ) ?: absint( $item['product_id'] ?? 0 );
			if ( ! $gift_available || $item_id !== $gift_id ) {
				WC()->cart->remove_cart_item( $key );
				if ( WC()->session ) {
					WC()->session->set( 'glissimo_gift_declined', false );
				}
				continue;
			}
			$gift_keys[] = $key;
		}
	}

	if ( ! $qualifies ) {
		foreach ( $gift_keys as $key ) {
			WC()->cart->remove_cart_item( $key );
		}
		if ( WC()->session ) {
			WC()->session->set( 'glissimo_gift_declined', false );
		}
		$syncing = false;
		return;
	}

	$declined = WC()->session && WC()->session->get( 'glissimo_gift_declined' );
	if ( ! $gift_keys && ! $declined ) {
		if ( $gift_available ) {
			WC()->cart->add_to_cart(
				$gift_id,
				1,
				0,
				array(),
				array( 'glissimo_free_gift' => true, 'glissimo_unique' => wp_generate_uuid4() )
			);
		}
	}
	$syncing = false;
}
add_action( 'woocommerce_cart_loaded_from_session', 'glissimo_sync_free_gift', 30 );
add_action( 'woocommerce_add_to_cart', 'glissimo_sync_free_gift', 30 );
add_action( 'woocommerce_cart_item_removed', 'glissimo_sync_free_gift', 30 );
add_action( 'woocommerce_cart_item_restored', 'glissimo_sync_free_gift', 30 );

function glissimo_reconcile_free_gift_after_totals( WC_Cart $cart ): void {
	static $recalculating = false;
	if ( $recalculating ) {
		return;
	}
	$before = array_keys(
		array_filter(
			$cart->get_cart(),
			static fn( array $item ): bool => ! empty( $item['glissimo_free_gift'] )
		)
	);
	glissimo_sync_free_gift();
	$after = array_keys(
		array_filter(
			$cart->get_cart(),
			static fn( array $item ): bool => ! empty( $item['glissimo_free_gift'] )
		)
	);
	if ( $before !== $after ) {
		$recalculating = true;
		$cart->calculate_totals();
		$recalculating = false;
	}
}
add_action( 'woocommerce_after_calculate_totals', 'glissimo_reconcile_free_gift_after_totals', 30 );

function glissimo_mark_removed_gift_declined( string $cart_item_key, WC_Cart $cart ): void {
	$item = $cart->removed_cart_contents[ $cart_item_key ] ?? array();
	if ( ! empty( $item['glissimo_free_gift'] ) && WC()->session ) {
		WC()->session->set( 'glissimo_gift_declined', true );
	}
}
add_action( 'woocommerce_cart_item_removed', 'glissimo_mark_removed_gift_declined', 5, 2 );

/** @return array<int, string>|WP_Error */
function glissimo_allocate_bundle_minor_units( array $prices, float $offer_price, ?int $decimals = null ): array {
	$decimals = null === $decimals ? wc_get_price_decimals() : max( 0, $decimals );
	$factor = 10 ** $decimals;
	$offer_minor = (int) round( $offer_price * $factor );
	$combined = array_sum( $prices );
	$allocations = array_fill( 0, count( $prices ), 0 );
	$remainders = array();
	foreach ( $prices as $index => $price ) {
		$raw = $combined > 0 ? $offer_minor * ( (float) $price / $combined ) : 0;
		$allocations[ $index ] = (int) floor( $raw );
		$remainders[ $index ] = $raw - $allocations[ $index ];
	}
	arsort( $remainders, SORT_NUMERIC );
	$remaining = $offer_minor - array_sum( $allocations );
	foreach ( array_keys( $remainders ) as $index ) {
		if ( $remaining-- <= 0 ) {
			break;
		}
		$allocations[ $index ]++;
	}
	return array_map( static fn( int $minor ): float => $minor / $factor, $allocations );
}

/** @return array<int, string>|WP_Error */
function glissimo_add_bundle_to_cart( int $offer_id ) {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return new WP_Error( 'cart_unavailable', __( 'The cart is not available.', 'glissimo' ) );
	}
	$definition = glissimo_bundle_definition( $offer_id );
	if ( ! $definition ) {
		return new WP_Error( 'bundle_unavailable', __( 'This bundle is not available.', 'glissimo' ) );
	}
	$offer = $definition['offer'];
	$components = array();
	$combined = 0.0;
	foreach ( $definition['components'] as $component_id ) {
		$component = wc_get_product( $component_id );
		if ( ! $component || $component->is_type( 'variable' ) || ! $component->is_purchasable() || ! $component->is_in_stock() || ! $component->has_enough_stock( 1 ) ) {
			return new WP_Error( 'component_unavailable', __( 'A bundle component is currently unavailable.', 'glissimo' ) );
		}
		$price = (float) $component->get_price( 'edit' );
		if ( $price < 0 ) {
			return new WP_Error( 'bundle_price_invalid', __( 'The bundle cannot be priced safely.', 'glissimo' ) );
		}
		$combined += $price;
		$components[] = array( 'product' => $component, 'price' => $price );
	}
	$offer_price = (float) $offer->get_price( 'edit' );
	if ( $combined <= 0 || $offer_price < 0 || $offer_price > $combined ) {
		return new WP_Error( 'bundle_price_invalid', __( 'The configured bundle price is invalid.', 'glissimo' ) );
	}

	$group = wp_generate_uuid4();
	$added = array();
	$allocations = glissimo_allocate_bundle_minor_units( array_column( $components, 'price' ), $offer_price );
	glissimo_bundle_assembly_active( true );
	try {
		foreach ( $components as $index => $row ) {
			$component = $row['product'];
			$component_id = $component->get_id();
			$line_price = $allocations[ $index ];
			$product_id = $component->is_type( 'variation' ) ? $component->get_parent_id() : $component_id;
			$variation_id = $component->is_type( 'variation' ) ? $component_id : 0;
			$variation = $component->is_type( 'variation' ) ? $component->get_variation_attributes() : array();
			$key = WC()->cart->add_to_cart(
				$product_id,
				1,
				$variation_id,
				$variation,
				array(
					'glissimo_bundle_group'           => $group,
					'glissimo_bundle_offer_id'        => $offer_id,
					'glissimo_bundle_title'           => $offer->get_name(),
					'glissimo_bundle_allocated_price' => $line_price,
					'glissimo_unique'                 => $group . '-' . $index,
				)
			);
			if ( ! $key ) {
				foreach ( $added as $added_key ) {
					WC()->cart->remove_cart_item( $added_key );
				}
				return new WP_Error( 'bundle_add_failed', __( 'The bundle could not be added. Your cart was not changed.', 'glissimo' ) );
			}
			$added[] = $key;
		}
	} finally {
		glissimo_bundle_assembly_active( false );
	}
	glissimo_sync_free_gift();
	WC()->cart->calculate_totals();
	return $added;
}

function glissimo_bundle_add_to_cart(): void {
	check_ajax_referer( 'glissimo_cart', 'nonce' );
	$offer_id = absint( $_POST['offer_id'] ?? 0 );
	$result = glissimo_add_bundle_to_cart( $offer_id );
	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ), 409 );
	}
	$offer = wc_get_product( $offer_id );
	$commerce_event = $offer instanceof WC_Product ? array( 'event' => 'add_to_cart', 'event_id' => 'bundle_add_' . wp_generate_uuid4(), 'ecommerce' => array( 'currency' => get_woocommerce_currency(), 'value' => (float) wc_get_price_to_display( $offer ), 'items' => array( glissimo_analytics_item( $offer, 1 ) ) ) ) : array();
	glissimo_send_cart_state( __( 'Bundle added to your cart.', 'glissimo' ), array( 'event' => 'bundle_interaction', 'event_id' => 'bundle_' . wp_generate_uuid4(), 'offer_id' => (string) $offer_id, 'action' => 'add' ), $commerce_event ? array( $commerce_event ) : array() );
}
add_action( 'wp_ajax_glissimo_bundle_add', 'glissimo_bundle_add_to_cart' );
add_action( 'wp_ajax_nopriv_glissimo_bundle_add', 'glissimo_bundle_add_to_cart' );

function glissimo_bundle_post_fallback(): void {
	if ( empty( $_POST['glissimo_bundle_offer'] ) ) {
		return;
	}
	$offer_id = absint( wp_unslash( $_POST['glissimo_bundle_offer'] ) );
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['glissimo_bundle_nonce'] ?? '' ) ), 'glissimo_bundle_' . $offer_id ) ) {
		wc_add_notice( __( 'The bundle request expired. Please try again.', 'glissimo' ), 'error' );
	} else {
		$result = glissimo_add_bundle_to_cart( $offer_id );
		wc_add_notice( is_wp_error( $result ) ? $result->get_error_message() : __( 'Bundle added to your cart.', 'glissimo' ), is_wp_error( $result ) ? 'error' : 'success' );
	}
	wp_safe_redirect( wc_get_cart_url() );
	exit;
}
add_action( 'template_redirect', 'glissimo_bundle_post_fallback', 5 );

function glissimo_special_cart_item_data( array $data, array $cart_item ): array {
	if ( ! empty( $cart_item['glissimo_bundle_title'] ) ) {
		$data[] = array( 'key' => __( 'Bundle', 'glissimo' ), 'value' => (string) $cart_item['glissimo_bundle_title'] );
	}
	if ( ! empty( $cart_item['glissimo_free_gift'] ) ) {
		$data[] = array( 'key' => __( 'Offer', 'glissimo' ), 'value' => __( 'Complimentary gift', 'glissimo' ) );
	}
	if ( ! empty( $cart_item['glissimo_order_bump'] ) ) {
		$data[] = array( 'key' => __( 'Added at checkout', 'glissimo' ), 'value' => __( 'Order addition', 'glissimo' ) );
	}
	return $data;
}
add_filter( 'woocommerce_get_item_data', 'glissimo_special_cart_item_data', 10, 2 );

function glissimo_add_order_line_metadata( WC_Order_Item_Product $item, string $cart_item_key, array $values ): void {
	if ( ! empty( $values['glissimo_bundle_offer_id'] ) ) {
		$item->add_meta_data( '_glissimo_bundle_offer_id', absint( $values['glissimo_bundle_offer_id'] ), true );
		$item->add_meta_data( __( 'Bundle', 'glissimo' ), sanitize_text_field( (string) ( $values['glissimo_bundle_title'] ?? '' ) ), true );
	}
	if ( ! empty( $values['glissimo_free_gift'] ) ) {
		$item->add_meta_data( '_glissimo_free_gift', 1, true );
	}
	if ( ! empty( $values['glissimo_order_bump'] ) ) {
		$item->add_meta_data( '_glissimo_order_bump', 1, true );
	}
}
add_action( 'woocommerce_checkout_create_order_line_item', 'glissimo_add_order_line_metadata', 10, 3 );

function glissimo_exclude_special_lines_from_coupons( bool $valid, WC_Product $product, WC_Coupon $coupon, array $values ): bool {
	if ( ! empty( $values['glissimo_bundle_group'] ) || ( ! empty( $values['glissimo_builder_group'] ) && empty( $values['glissimo_builder_allow_coupons'] ) ) || ! empty( $values['glissimo_free_gift'] ) || ! empty( $values['glissimo_order_bump'] ) ) {
		return false;
	}
	return $valid;
}
add_filter( 'woocommerce_coupon_is_valid_for_product', 'glissimo_exclude_special_lines_from_coupons', 10, 4 );
