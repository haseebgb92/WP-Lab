<?php
/** Bounded product-education modules for the Glissimo PDP. */
defined( 'ABSPATH' ) || exit;

/** @param array<string,mixed> $module */
function glissimo_pdp_editorial_media( array $module, string $size = 'large' ): void {
	$video_id = absint( $module['video'] ?? 0 );
	$image_id = absint( $module['image'] ?? 0 );
	$heading  = (string) ( $module['heading'] ?? $module['title'] ?? '' );
	if ( $video_id ) {
		$source = wp_get_attachment_url( $video_id );
		if ( ! $source ) { return; }
		$poster = absint( $module['poster'] ?? 0 );
		?><video controls playsinline preload="metadata"<?php echo $poster ? ' poster="' . esc_url( (string) wp_get_attachment_image_url( $poster, 'large' ) ) . '"' : ''; ?>><source src="<?php echo esc_url( $source ); ?>" type="<?php echo esc_attr( (string) ( get_post_mime_type( $video_id ) ?: 'video/mp4' ) ); ?>"></video><?php
		return;
	}
	if ( $image_id ) {
		echo wp_get_attachment_image( $image_id, $size, false, array( 'loading' => 'lazy', 'alt' => $heading ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}

/** @param array<string,mixed> $module */
function glissimo_pdp_editorial_copy( array $module, bool $compact = false ): void {
	$eyebrow = trim( (string) ( $module['eyebrow'] ?? '' ) );
	$heading = trim( (string) ( $module['heading'] ?? $module['title'] ?? '' ) );
	$copy    = trim( (string) ( $module['copy'] ?? '' ) );
	if ( '' === $eyebrow && '' === $heading && '' === wp_strip_all_tags( $copy ) ) { return; }
	?><div class="gl-pdp-editorial__copy<?php echo $compact ? ' is-compact' : ''; ?>">
		<?php if ( $eyebrow ) : ?><p class="gl-pdp-editorial__eyebrow"><?php echo esc_html( $eyebrow ); ?></p><?php endif; ?>
		<?php if ( $heading ) : ?><h2><?php echo esc_html( $heading ); ?></h2><?php endif; ?>
		<?php if ( $copy ) : ?><div class="gl-prose"><?php echo wp_kses_post( wpautop( $copy ) ); ?></div><?php endif; ?>
		<?php if ( ! empty( $module['cta_label'] ) && ! empty( $module['cta_url'] ) ) : ?><a class="gl-button gl-button--outline" href="<?php echo esc_url( (string) $module['cta_url'] ); ?>"><?php echo esc_html( (string) $module['cta_label'] ); ?></a><?php endif; ?>
	</div><?php
}

/** @param array<string,mixed> $module */
function glissimo_pdp_editorial_items( array $module, string $class_name ): void {
	$items = array_values( array_filter( (array) ( $module['items'] ?? array() ), static function ( $item ): bool {
		return is_array( $item ) && ( '' !== trim( (string) ( $item['title'] ?? '' ) ) || '' !== trim( wp_strip_all_tags( (string) ( $item['copy'] ?? '' ) ) ) || ! empty( $item['image'] ) );
	} ) );
	if ( ! $items ) { return; }
	?><div class="<?php echo esc_attr( $class_name ); ?>"><?php foreach ( array_slice( $items, 0, 4 ) as $item ) : ?><article>
		<?php if ( ! empty( $item['image'] ) ) : ?><div class="gl-pdp-editorial__item-media"><?php echo wp_get_attachment_image( absint( $item['image'] ), 'medium', false, array( 'loading' => 'lazy', 'alt' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
		<?php if ( ! empty( $item['title'] ) ) : ?><h3><?php echo esc_html( (string) $item['title'] ); ?></h3><?php endif; ?>
		<?php if ( ! empty( $item['copy'] ) ) : ?><div class="gl-prose"><?php echo wp_kses_post( wpautop( (string) $item['copy'] ) ); ?></div><?php endif; ?>
	</article><?php endforeach; ?></div><?php
}

/** @param array<string,mixed> $module */
function glissimo_render_pdp_editorial_module( array $module ): void {
	if ( empty( $module['active'] ) ) { return; }
	$type    = (string) ( $module['type'] ?? 'split' );
	$variant = sanitize_html_class( (string) ( $module['variant'] ?? 'light' ) );
	$has_media = ! empty( $module['image'] ) || ! empty( $module['video'] );
	$has_copy  = '' !== trim( (string) ( $module['heading'] ?? $module['title'] ?? '' ) ) || '' !== trim( wp_strip_all_tags( (string) ( $module['copy'] ?? '' ) ) );
	$has_items = (bool) array_filter( (array) ( $module['items'] ?? array() ) );
	if ( ! $has_media && ! $has_copy && ! $has_items ) { return; }

	switch ( $type ) {
		case 'media_hero':
			?><section class="gl-pdp-editorial gl-pdp-editorial--media-hero is-<?php echo esc_attr( $variant ); ?><?php echo $has_media ? '' : ' has-no-media'; ?>"><div class="gl-pdp-editorial__media"><?php glissimo_pdp_editorial_media( $module, 'full' ); ?></div><?php glissimo_pdp_editorial_copy( $module ); ?></section><?php
			break;
		case 'feature_grid':
			?><section class="gl-pdp-editorial gl-pdp-editorial--feature-grid is-<?php echo esc_attr( $variant ); ?>"><?php glissimo_pdp_editorial_copy( $module, true ); ?><?php glissimo_pdp_editorial_items( $module, 'gl-pdp-editorial__features' ); ?></section><?php
			break;
		case 'product_facts':
			?><section class="gl-pdp-editorial gl-pdp-editorial--product-facts is-<?php echo esc_attr( $variant ); ?>"><?php glissimo_pdp_editorial_copy( $module, true ); ?><?php glissimo_pdp_editorial_items( $module, 'gl-pdp-editorial__facts' ); ?></section><?php
			break;
		case 'media_banner':
			?><section class="gl-pdp-editorial gl-pdp-editorial--media-banner is-<?php echo esc_attr( $variant ); ?><?php echo $has_media ? '' : ' has-no-media'; ?>"><div class="gl-pdp-editorial__media"><?php glissimo_pdp_editorial_media( $module, 'full' ); ?></div><?php glissimo_pdp_editorial_copy( $module, true ); ?></section><?php
			break;
		case 'split':
		default:
			?><section class="gl-pdp-editorial gl-pdp-editorial--split is-<?php echo esc_attr( $variant ); ?><?php echo 'right' === ( $module['align'] ?? 'left' ) ? ' is-reversed' : ''; ?><?php echo $has_media ? '' : ' has-no-media'; ?>"><div class="gl-pdp-editorial__media"><?php glissimo_pdp_editorial_media( $module ); ?></div><?php glissimo_pdp_editorial_copy( $module ); ?></section><?php
	}
}

/** @param array<int,array<string,mixed>> $modules */
function glissimo_render_pdp_editorial_modules( array $modules ): void {
	usort( $modules, static fn( array $a, array $b ): int => (int) ( $a['order'] ?? 0 ) <=> (int) ( $b['order'] ?? 0 ) );
	foreach ( $modules as $module ) { glissimo_render_pdp_editorial_module( $module ); }
}
