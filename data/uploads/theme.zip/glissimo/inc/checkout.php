<?php
/**
 * Checkout, order bump, and order-received presentation.
 *
 * @package Glissimo
 */

defined( 'ABSPATH' ) || exit;

function glissimo_checkout_body_classes( array $classes ): array {
	if ( function_exists( 'is_checkout' ) && is_checkout() ) {
		$classes[] = 'gl-checkout';
	}
	if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
		$classes[] = 'gl-order-received';
	}
	return $classes;
}
add_filter( 'body_class', 'glissimo_checkout_body_classes' );

function glissimo_checkout_intro(): void {
	if ( is_order_received_page() ) {
		return;
	}
	$settings = glissimo_core_settings();
	$config = glissimo_customer_content_tree( $settings['checkout'] ?? array() );
	?>
	<header class="gl-checkout-intro">
		<p><?php esc_html_e( 'Secure checkout', 'glissimo' ); ?></p>
		<h1><?php esc_html_e( 'Complete your order', 'glissimo' ); ?></h1>
		<?php if ( ! empty( $config['reassurance_heading'] ) || ! empty( $config['reassurance_copy'] ) ) : ?><div class="gl-checkout-intro__assurance"><?php if ( ! empty( $config['reassurance_heading'] ) ) : ?><strong><?php echo esc_html( $config['reassurance_heading'] ); ?></strong><?php endif; ?><?php if ( ! empty( $config['reassurance_copy'] ) ) : ?><span><?php echo esc_html( $config['reassurance_copy'] ); ?></span><?php endif; ?></div><?php endif; ?>
		<?php if ( ! empty( $config['support_url'] ) ) : ?><a href="<?php echo esc_url( $config['support_url'] ); ?>"><?php esc_html_e( 'Need help with your order?', 'glissimo' ); ?></a><?php endif; ?>
	</header>
	<?php
}
add_action( 'woocommerce_before_checkout_form', 'glissimo_checkout_intro', 5 );

/** Give the native cart route the same merchandising hierarchy as the drawer. */
function glissimo_cart_page_intro(): void {
	$shipping = glissimo_shipping_progress_state();
	if ( ! empty( $shipping['message'] ) && function_exists( 'glissimo_is_internal_content' ) && glissimo_is_internal_content( (string) $shipping['message'] ) ) {
		$shipping = array();
	}
	?>
	<header class="gl-cart-page__intro"><p><?php esc_html_e( 'Your selection', 'glissimo' ); ?></p><h1><?php esc_html_e( 'Shopping cart', 'glissimo' ); ?></h1><span><?php esc_html_e( 'Review your items before continuing to secure checkout.', 'glissimo' ); ?></span></header>
	<?php if ( $shipping ) : ?><section class="gl-cart-page__progress" aria-label="<?php esc_attr_e( 'Free shipping progress', 'glissimo' ); ?>"><div><strong><?php echo esc_html( $shipping['message'] ); ?></strong><span><?php echo esc_html( (string) round( (float) $shipping['percent'] ) ); ?>%</span></div><i aria-hidden="true"><b style="width:<?php echo esc_attr( (string) $shipping['percent'] ); ?>%"></b></i></section><?php endif; ?>
	<?php
}
add_action( 'woocommerce_before_cart', 'glissimo_cart_page_intro', 5 );

function glissimo_cart_page_recommendations(): void {
	$recommendations = glissimo_cart_recommendations();
	if ( ! $recommendations ) { return; }
	?>
	<section class="gl-cart-page__recommendations" aria-labelledby="gl-cart-page-recommendations"><div><h2 id="gl-cart-page-recommendations"><?php esc_html_e( 'Complete your kitchen', 'glissimo' ); ?></h2><p><?php esc_html_e( 'A few relevant additions selected for this cart.', 'glissimo' ); ?></p></div><div class="gl-product-rail"><?php foreach ( $recommendations as $recommendation ) { glissimo_product_card( $recommendation ); } ?></div></section>
	<?php
}
add_action( 'woocommerce_after_cart', 'glissimo_cart_page_recommendations', 15 );

/** Add product media to the native checkout summary without changing line-item truth. */
function glissimo_checkout_product_name( string $name, array $cart_item, string $cart_item_key ): string {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) { return $name; }
	$product = $cart_item['data'] ?? null;
	if ( ! $product instanceof WC_Product ) { return $name; }
	$image = $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'alt' => $product->get_name() ) );
	return '<span class="gl-checkout-product"><span class="gl-checkout-product__image">' . wp_kses_post( $image ) . '</span><span class="gl-checkout-product__copy">' . wp_kses_post( $name ) . '</span></span>';
}
add_filter( 'woocommerce_cart_item_name', 'glissimo_checkout_product_name', 20, 3 );

/** @return WC_Product|false */
function glissimo_eligible_order_bump() {
	$settings = glissimo_core_settings();
	$config = $settings['order_bump'] ?? array();
	if ( empty( $config['enabled'] ) || empty( $config['product_id'] ) || ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
		return false;
	}
	$product_id = absint( $config['product_id'] );
	$bump_key = glissimo_order_bump_cart_key();
	$cart_ids = array();
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( ! empty( $item['glissimo_order_bump'] ) || ! empty( $item['glissimo_free_gift'] ) ) {
			continue;
		}
		$cart_ids[] = absint( $item['variation_id'] ?? 0 ) ?: absint( $item['product_id'] ?? 0 );
		$cart_ids[] = absint( $item['product_id'] ?? 0 );
	}
	$cart_ids = array_values( array_unique( array_filter( $cart_ids ) ) );
	if ( ( ! $bump_key && in_array( $product_id, $cart_ids, true ) ) || array_intersect( $cart_ids, array_map( 'absint', (array) ( $config['excluded_product_ids'] ?? array() ) ) ) ) {
		return false;
	}
	$qualifying = array_map( 'absint', (array) ( $config['qualifying_product_ids'] ?? array() ) );
	if ( $qualifying && ! array_intersect( $cart_ids, $qualifying ) ) {
		return false;
	}
	$product = wc_get_product( $product_id );
	return $product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && $product->has_enough_stock( 1 ) ? $product : false;
}

function glissimo_order_bump_cart_key(): string {
	$settings = glissimo_core_settings();
	$product_id = absint( $settings['order_bump']['product_id'] ?? 0 );
	foreach ( glissimo_order_bump_cart_keys() as $key ) {
		$item = WC()->cart->get_cart_item( $key );
		$item_id = absint( $item['variation_id'] ?? 0 ) ?: absint( $item['product_id'] ?? 0 );
		if ( $product_id && $item_id === $product_id ) {
			return $key;
		}
	}
	return '';
}

/** @return array<int, string> */
function glissimo_order_bump_cart_keys(): array {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return array();
	}
	$keys = array();
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		if ( ! empty( $item['glissimo_order_bump'] ) ) {
			$keys[] = $key;
		}
	}
	return $keys;
}

function glissimo_render_order_bump(): void {
	$product = glissimo_eligible_order_bump();
	if ( ! $product ) {
		return;
	}
	$config = glissimo_customer_content_tree( glissimo_core_settings()['order_bump'] ?? array() );
	$selected = '' !== glissimo_order_bump_cart_key();
	?>
	<section class="gl-order-bump" data-gl-order-bump>
		<label>
			<input type="checkbox" data-gl-order-bump-toggle value="1" <?php checked( $selected ); ?>>
			<span class="gl-order-bump__image"><?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ) ); ?></span>
			<span><strong><?php echo esc_html( $config['heading'] ?: $product->get_name() ); ?></strong><?php if ( ! empty( $config['copy'] ) ) : ?><small><?php echo esc_html( $config['copy'] ); ?></small><?php endif; ?><b><?php echo wp_kses_post( $product->get_price_html() ); ?></b></span>
		</label>
		<div class="gl-order-bump__status" data-gl-order-bump-status aria-live="polite"></div>
	</section>
	<?php
}
add_action( 'woocommerce_review_order_before_payment', 'glissimo_render_order_bump', 5 );

function glissimo_reconcile_order_bump( WC_Cart $cart ): void {
	static $reconciling = false;
	if ( $reconciling ) {
		return;
	}
	$valid_key = glissimo_order_bump_cart_key();
	$keys = glissimo_order_bump_cart_keys();
	if ( $keys && ( ! $valid_key || ! glissimo_eligible_order_bump() || count( $keys ) > 1 ) ) {
		$reconciling = true;
		foreach ( $keys as $key ) {
			if ( ! $valid_key || $key !== $valid_key || ! glissimo_eligible_order_bump() ) {
				$cart->remove_cart_item( $key );
			}
		}
		$reconciling = false;
	}
}
add_action( 'woocommerce_before_calculate_totals', 'glissimo_reconcile_order_bump', 15 );

/** @return string|WP_Error */
function glissimo_set_order_bump( bool $enabled ) {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return new WP_Error( 'cart_unavailable', __( 'The cart is not available.', 'glissimo' ) );
	}
	$key = glissimo_order_bump_cart_key();
	if ( ! $enabled && $key ) {
		WC()->cart->remove_cart_item( $key );
		WC()->cart->calculate_totals();
		return __( 'Order addition removed.', 'glissimo' );
	}
	if ( $enabled && ! $key ) {
		$product = glissimo_eligible_order_bump();
		if ( ! $product ) {
			return new WP_Error( 'bump_unavailable', __( 'This order addition is no longer available.', 'glissimo' ) );
		}
		$key = WC()->cart->add_to_cart(
			$product->get_id(),
			1,
			0,
			array(),
			array( 'glissimo_order_bump' => true, 'glissimo_unique' => wp_generate_uuid4() )
		);
		if ( ! $key ) {
			return new WP_Error( 'bump_add_failed', __( 'This order addition could not be added.', 'glissimo' ) );
		}
	}
	WC()->cart->calculate_totals();
	return __( 'Order addition updated.', 'glissimo' );
}

function glissimo_order_bump_toggle(): void {
	glissimo_require_cart_request();
	$result = glissimo_set_order_bump( ! empty( $_POST['enabled'] ) );
	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ), 409 );
	}
	wp_send_json_success( array( 'message' => $result, 'event' => ! empty( $_POST['enabled'] ) ? array( 'event' => 'order_bump_acceptance', 'event_id' => 'bump_' . wp_generate_uuid4() ) : array() ) );
}
add_action( 'wp_ajax_glissimo_order_bump_toggle', 'glissimo_order_bump_toggle' );
add_action( 'wp_ajax_nopriv_glissimo_order_bump_toggle', 'glissimo_order_bump_toggle' );

/** @return array<int, array{title:string,url:string}> */
function glissimo_order_care_links( WC_Order $order ): array {
	$links = array();
	foreach ( $order->get_items() as $item ) {
		$product = $item->get_product();
		if ( ! $product ) {
			continue;
		}
		$product_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$story = glissimo_product_story_meta( $product_id );
		$care = is_array( $story['care'] ?? null ) ? $story['care'] : array();
		if ( ! empty( $care['title'] ) && ! empty( $care['url'] ) ) {
			$links[] = array( 'title' => (string) $care['title'], 'url' => (string) $care['url'] );
		}
	}
	return array_values( array_unique( $links, SORT_REGULAR ) );
}
