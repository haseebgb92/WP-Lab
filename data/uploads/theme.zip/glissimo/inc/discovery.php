<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function glissimo_quiz_questions(): array {
	$s = glissimo_phase2_settings()['quiz'] ?? array(); $out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $s['questions'] ?? '' ) ) ?: array() as $line ) { $p = array_map( 'trim', explode( '|', $line, 3 ) ); if ( count( $p ) < 3 ) { continue; } $answers = array(); foreach ( explode( ';', $p[2] ) as $answer ) { $a = array_map( 'trim', explode( ':', $answer, 2 ) ); if ( count( $a ) === 2 ) { $answers[] = array( 'value' => sanitize_key( $a[0] ), 'label' => sanitize_text_field( $a[1] ) ); } } if ( $answers ) { $out[] = array( 'key' => sanitize_key( $p[0] ), 'question' => sanitize_text_field( $p[1] ), 'answers' => $answers ); } }
	return $out;
}

function glissimo_quiz_rules(): array {
	$raw = glissimo_phase2_settings()['quiz']['rules'] ?? ''; $rules = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) ?: array() as $line ) { $parts = array_map( 'trim', explode( '=', $line, 2 ) ); if ( count( $parts ) < 2 ) { continue; } $key = sanitize_key( str_replace( '.', '__', $parts[0] ) ); foreach ( explode( ',', $parts[1] ) as $score ) { $p = array_map( 'trim', explode( ':', $score, 2 ) ); if ( count( $p ) === 2 && absint( $p[0] ) ) { $rules[ $key ][ absint( $p[0] ) ] = max( 0, (int) $p[1] ); } } }
	return $rules;
}

function glissimo_quiz_answer_labels(): array { $labels = array(); foreach ( glissimo_quiz_questions() as $question ) { foreach ( $question['answers'] as $answer ) { $labels[ $question['key'] . '__' . $answer['value'] ] = $answer['label']; } } return $labels; }
function glissimo_validate_quiz_answers( array $answers ) { $validated = array(); foreach ( glissimo_quiz_questions() as $question ) { $value = sanitize_key( $answers[ $question['key'] ] ?? '' ); $allowed = array_column( $question['answers'], 'value' ); if ( ! $value || ! in_array( $value, $allowed, true ) ) { return new WP_Error( 'invalid_quiz_answer', __( 'Complete each product-finder question before viewing a match.', 'glissimo' ) ); } $validated[ $question['key'] ] = $value; } return $validated; }

function glissimo_score_quiz_products( array $answers ): array {
	$rules = glissimo_quiz_rules(); $labels = glissimo_quiz_answer_labels(); $scores = array(); $reasons = array(); ksort( $answers );
	foreach ( $answers as $question => $answer ) { $key = sanitize_key( $question . '__' . $answer ); foreach ( $rules[ $key ] ?? array() as $product_id => $weight ) { $scores[ $product_id ] = ( $scores[ $product_id ] ?? 0 ) + $weight; $reasons[ $product_id ][] = sanitize_text_field( $labels[ $key ] ?? $answer ); } }
	arsort( $scores, SORT_NUMERIC ); $results = array(); foreach ( $scores as $product_id => $score ) { $product = wc_get_product( $product_id ); if ( $product && $product->is_visible() && $product->is_in_stock() ) { $results[] = array( 'product' => $product, 'score' => $score, 'explanation' => implode( ', ', $reasons[ $product_id ] ?? array() ) ); } } return $results;
}

function glissimo_quiz_result(): void {
	check_ajax_referer( 'glissimo_phase2', 'nonce' );
	if ( ! glissimo_phase2_enabled( 'quiz' ) ) { wp_send_json_error( array( 'message' => __( 'The product finder is unavailable.', 'glissimo' ) ), 400 ); }
	$raw = is_array( $_POST['answers'] ?? null ) ? wp_unslash( $_POST['answers'] ) : array();
	$answers = glissimo_validate_quiz_answers( $raw );
	if ( is_wp_error( $answers ) ) { wp_send_json_error( array( 'message' => $answers->get_error_message() ), 422 ); }
	$results = glissimo_score_quiz_products( $answers );
	if ( ! $results ) { wp_send_json_success( array( 'result' => null ) ); }
	$winner = $results[0]; $product = $winner['product']; $settings = glissimo_phase2_settings()['quiz'];
	do_action( 'glissimo_phase2_event', 'quiz_complete', array( 'product_id' => $product->get_id() ) );
	wp_send_json_success( array( 'result' => array(
		'id' => $product->get_id(), 'name' => $product->get_name(), 'url' => $product->get_permalink(),
		'image' => wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_single' ),
		'price' => html_entity_decode( wp_strip_all_tags( $product->get_price_html() ), ENT_QUOTES | ENT_HTML5, get_bloginfo( 'charset' ) ),
		'explanation' => $winner['explanation'], 'resultCopy' => $settings['result_copy'], 'ctaLabel' => $settings['cta_label'],
	) ) );
}
add_action( 'wp_ajax_glissimo_quiz_result', 'glissimo_quiz_result' ); add_action( 'wp_ajax_nopriv_glissimo_quiz_result', 'glissimo_quiz_result' );

function glissimo_phase2_parse_recommendation_mappings( string $raw ): array { $map = array(); foreach ( preg_split( '/\r\n|\r|\n/', $raw ) ?: array() as $line ) { $p = array_map( 'trim', explode( '=', $line, 2 ) ); if ( count( $p ) === 2 ) { $map[ sanitize_key( str_replace( ':', '_', $p[0] ) ) ] = array_values( array_filter( array_map( 'absint', preg_split( '/[\s,]+/', $p[1] ) ) ) ); } } return $map; }
function glissimo_catalog_recommendation_fallback_ids( int $product_id, int $limit ): array { return array_map( 'absint', wc_get_products( array( 'status' => 'publish', 'stock_status' => 'instock', 'exclude' => array( $product_id ), 'limit' => max( 0, $limit ), 'orderby' => 'date', 'order' => 'DESC', 'return' => 'ids' ) ) ); }
function glissimo_recommendation_product_ids( int $product_id = 0, int $limit = 4 ): array { $s = glissimo_phase2_settings()['recommendations'] ?? array(); if ( empty( $s['enabled'] ) ) { return array(); } $max_items = min( $limit, (int) ( $s['max_items'] ?? 4 ) ); $map = glissimo_phase2_parse_recommendation_mappings( (string) $s['mappings'] ); $ids = $map[ 'product_' . $product_id ] ?? array(); if ( ! $ids && $product_id ) { foreach ( wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) ) as $cat ) { if ( isset( $map[ 'category_' . $cat ] ) ) { $ids = array_merge( $ids, $map[ 'category_' . $cat ] ); } } } if ( ! $ids && $product_id ) { $ids = wc_get_related_products( $product_id, $limit ); } $ids = array_values( array_unique( array_diff( array_map( 'absint', $ids ), array( $product_id ) ) ) ); $ids = array_values( array_filter( $ids, static function ( $id ) { $p = wc_get_product( $id ); return $p && $p->is_visible() && $p->is_in_stock(); } ) ); if ( count( $ids ) < $max_items ) { $ids = array_merge( $ids, glissimo_catalog_recommendation_fallback_ids( $product_id, $limit ) ); } return array_slice( array_values( array_unique( array_diff( array_map( 'absint', $ids ), array( $product_id ) ) ) ), 0, $max_items ); }

function glissimo_personalized_recommendation_ids( array $context_ids, int $limit = 4 ): array { if ( ! glissimo_phase2_enabled( 'recommendations' ) ) { return array(); } $context_ids = array_values( array_unique( array_filter( array_map( 'absint', $context_ids ) ) ) ); $excluded = $context_ids; if ( function_exists( 'WC' ) && WC()->cart ) { foreach ( WC()->cart->get_cart() as $item ) { $excluded[] = absint( $item['product_id'] ?? 0 ); } } $ids = array(); foreach ( $context_ids as $context_id ) { $ids = array_merge( $ids, glissimo_recommendation_product_ids( $context_id, $limit ) ); if ( count( array_unique( $ids ) ) >= $limit ) { break; } } $ids = array_values( array_unique( array_diff( array_map( 'absint', $ids ), $excluded ) ) ); return array_slice( $ids, 0, $limit ); }

function glissimo_account_recommendations(): void { if ( ! is_user_logged_in() || ! glissimo_phase2_enabled( 'recommendations' ) ) { return; } $orders = wc_get_orders( array( 'customer_id' => get_current_user_id(), 'limit' => 3, 'status' => wc_get_is_paid_statuses() ) ); $context = array(); foreach ( $orders as $order ) { foreach ( $order->get_items() as $item ) { $context[] = $item->get_product_id(); } } $ids = glissimo_personalized_recommendation_ids( $context, 4 ); if ( ! $ids ) { return; } ?><section class="gl-account-recommendations"><h2><?php esc_html_e( 'Chosen for your kitchen', 'glissimo' ); ?></h2><div class="gl-product-rail"><?php foreach ( $ids as $id ) { $product = wc_get_product( $id ); if ( $product ) { glissimo_product_card( $product ); } } ?></div></section><?php }
add_action( 'woocommerce_account_dashboard', 'glissimo_account_recommendations', 30 );
