<?php
/** SEO ownership boundaries and safe fallbacks. @package Glissimo */
defined( 'ABSPATH' ) || exit;

function glissimo_private_commerce_robots( array $robots ): array {
	if ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_account_page' ) && is_account_page() ) || is_search() ) {
		$robots['noindex'] = true;
		$robots['nofollow'] = true;
		unset( $robots['index'], $robots['follow'] );
	}
	return $robots;
}
// Run after WooCommerce/Core additions so an earlier `follow` cannot conflict.
add_filter( 'wp_robots', 'glissimo_private_commerce_robots', 99 );

function glissimo_wpseo_private_commerce( bool $robots ): bool {
	if ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_account_page' ) && is_account_page() ) ) { return false; }
	return $robots;
}
add_filter( 'wpseo_robots_index', 'glissimo_wpseo_private_commerce' );

/**
 * Generate WooCommerce's canonical Product graph for the custom PDP template.
 *
 * The Glissimo template intentionally does not execute the stock single-product
 * summary hook where WooCommerce normally queues this graph. Keep WooCommerce
 * as schema owner instead of reproducing product commerce data in the theme.
 */
function glissimo_generate_native_product_schema(): void {
	if ( ! function_exists( 'is_product' ) || ! is_product() || defined( 'WPSEO_WOO_VERSION' ) ) { return; }
	if ( ! function_exists( 'WC' ) || ! WC() || ! isset( WC()->structured_data ) ) { return; }
	$product = wc_get_product( get_queried_object_id() );
	if ( $product instanceof WC_Product ) {
		WC()->structured_data->generate_product_data( $product );
	}
}
add_action( 'wp', 'glissimo_generate_native_product_schema', 20 );

function glissimo_product_faq_schema(): void {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
	$story = glissimo_product_story_meta( get_queried_object_id() );
	$faq = is_array( $story['faq'] ?? null ) ? $story['faq'] : array();
	$entities = array();
	foreach ( $faq as $row ) {
		$question = sanitize_text_field( $row['q'] ?? '' );
		$answer = wp_strip_all_tags( (string) ( $row['a'] ?? '' ) );
		if ( $question && $answer ) { $entities[] = array( '@type' => 'Question', 'name' => $question, 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $answer ) ); }
	}
	if ( $entities ) {
		echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $entities ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
add_action( 'wp_head', 'glissimo_product_faq_schema', 30 );
