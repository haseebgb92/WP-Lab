<?php
/** Translation-provider bridge. @package Glissimo */
defined( 'ABSPATH' ) || exit;

/** @return array<int, array{code:string,label:string,url:string,active:bool,available:bool}> */
function glissimo_language_options(): array {
	$supported = array( 'en' => 'ENG', 'de' => 'DE', 'nl' => 'NL', 'fr' => 'FR', 'pl' => 'PL' );
	$wpml = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 1, 'orderby' => 'code' ) );
	$options = array();
	if ( is_array( $wpml ) ) {
		foreach ( $supported as $code => $label ) {
			if ( empty( $wpml[ $code ]['url'] ) ) { continue; }
			$options[] = array( 'code' => $code, 'label' => $label, 'url' => esc_url_raw( $wpml[ $code ]['url'] ), 'active' => ! empty( $wpml[ $code ]['active'] ), 'available' => true );
		}
	}
	if ( ! $options ) {
		$locale = strtolower( substr( determine_locale(), 0, 2 ) );
		$options[] = array( 'code' => $locale, 'label' => $supported[ $locale ] ?? strtoupper( $locale ), 'url' => '', 'active' => true, 'available' => false );
	}
	return apply_filters( 'glissimo_language_options', $options );
}

function glissimo_language_selector( string $class = '' ): void {
	$options = glissimo_language_options();
	$current = current( array_filter( $options, static fn( array $option ): bool => $option['active'] ) ) ?: $options[0];
	?>
	<details class="gl-language <?php echo esc_attr( $class ); ?>" data-gl-language-selector>
		<summary aria-label="<?php esc_attr_e( 'Choose language', 'glissimo' ); ?>"><?php echo glissimo_icon( 'globe' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( $current['label'] ); ?></span></summary>
		<div class="gl-language__menu" role="list">
			<?php foreach ( $options as $option ) : ?>
				<?php if ( $option['available'] ) : ?><a role="listitem" lang="<?php echo esc_attr( $option['code'] ); ?>" hreflang="<?php echo esc_attr( $option['code'] ); ?>" href="<?php echo esc_url( $option['url'] ); ?>" <?php if ( $option['active'] ) : ?>aria-current="page"<?php endif; ?>><?php echo esc_html( $option['label'] ); ?></a><?php else : ?><span role="listitem" aria-current="page"><?php echo esc_html( $option['label'] ); ?></span><small><?php esc_html_e( 'Additional languages activate with WPML translations.', 'glissimo' ); ?></small><?php endif; ?>
			<?php endforeach; ?>
		</div>
	</details>
	<?php
}
