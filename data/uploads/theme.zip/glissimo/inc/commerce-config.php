<?php
/**
 * Read-only commerce merchandising configuration helpers.
 *
 * WooCommerce products, prices, stock, shipping methods and cart data remain
 * authoritative. These helpers only interpret Advertpreneur Core mappings.
 *
 * @package Glissimo
 */

defined( 'ABSPATH' ) || exit;

/** @return array<string, mixed> */
function glissimo_core_settings(): array {
	if ( class_exists( '\\Advertpreneur\\Core\\Sites\\Glissimo\\Settings' ) ) {
		return \Advertpreneur\Core\Sites\Glissimo\Settings::all();
	}
	return array();
}

/** @return array<int, int> */
function glissimo_cart_product_ids(): array {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return array();
	}
	$ids = array();
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( ! empty( $item['glissimo_free_gift'] ) ) {
			continue;
		}
		$ids[] = absint( $item['variation_id'] ?: $item['product_id'] );
		$ids[] = absint( $item['product_id'] );
	}
	return array_values( array_unique( array_filter( $ids ) ) );
}

/** @return array<int, array{type:string,id:int,products:array<int,int>}> */
function glissimo_parse_recommendation_mappings( string $raw ): array {
	$rules = array();
	foreach ( preg_split( '/\R/', $raw ) as $line ) {
		$line = trim( $line );
		if ( ! preg_match( '/^(product|category):(\d+)\s*=\s*([\d,\s]+)$/i', $line, $matches ) ) {
			continue;
		}
		$products = array_values( array_unique( array_filter( array_map( 'absint', preg_split( '/[,\s]+/', $matches[3] ) ) ) ) );
		if ( $products ) {
			$rules[] = array( 'type' => strtolower( $matches[1] ), 'id' => absint( $matches[2] ), 'products' => $products );
		}
	}
	return $rules;
}

/** @return array<int, WC_Product> */
function glissimo_cart_recommendations(): array {
	$settings = glissimo_core_settings();
	$config = $settings['cart_recommendations'] ?? array();
	if ( empty( $config['enabled'] ) || ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
		return array();
	}

	$cart_ids = glissimo_cart_product_ids();
	$candidate_ids = array();
	foreach ( glissimo_parse_recommendation_mappings( (string) ( $config['mappings'] ?? '' ) ) as $rule ) {
		$matches = 'product' === $rule['type'] && in_array( $rule['id'], $cart_ids, true );
		if ( 'category' === $rule['type'] ) {
			foreach ( $cart_ids as $product_id ) {
				$product = wc_get_product( $product_id );
				$parent_id = $product && $product->is_type( 'variation' ) ? $product->get_parent_id() : $product_id;
				if ( has_term( $rule['id'], 'product_cat', $parent_id ) ) {
					$matches = true;
					break;
				}
			}
		}
		if ( $matches ) {
			$candidate_ids = array_merge( $candidate_ids, $rule['products'] );
		}
	}

	$candidate_ids = array_values( array_diff( array_unique( array_filter( $candidate_ids ) ), $cart_ids ) );
	$products = array();
	foreach ( $candidate_ids as $candidate_id ) {
		$product = wc_get_product( $candidate_id );
		if ( $product && $product->is_visible() && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_type( 'variable' ) ) {
			$products[] = $product;
		}
		if ( count( $products ) >= (int) ( $config['max_items'] ?? 3 ) ) {
			break;
		}
	}
	return $products;
}

/**
 * Return a verified WooCommerce free-shipping minimum matching Core.
 * A mismatched configured threshold deliberately produces no promise.
 */
/** @return WC_Shipping_Free_Shipping|false */
function glissimo_verified_shipping_method() {
	$settings = glissimo_core_settings();
	$config = $settings['shipping_progress'] ?? array();
	$configured = (float) ( $config['threshold'] ?? 0 );
	if ( empty( $config['enabled'] ) || $configured <= 0 || ! class_exists( 'WC_Shipping_Zones' ) ) {
		return false;
	}

	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return false;
	}
	$packages = WC()->cart->get_shipping_packages();
	// A single global progress meter cannot truthfully represent split-package thresholds.
	if ( 1 !== count( $packages ) ) {
		return false;
	}
	foreach ( $packages as $package ) {
		$zone = WC_Shipping_Zones::get_zone_matching_package( $package );
		foreach ( $zone->get_shipping_methods( true ) as $method ) {
			if ( ! $method instanceof WC_Shipping_Free_Shipping || 'yes' !== $method->enabled ) {
				continue;
			}
			$requires = (string) $method->get_option( 'requires', '' );
			$minimum = (float) $method->get_option( 'min_amount', 0 );
			if ( 'min_amount' === $requires && abs( $minimum - $configured ) < 0.01 ) {
				return $method;
			}
		}
	}
	return false;
}

/**
 * Replace the single amount token without treating merchant copy as a format string.
 */
function glissimo_progress_message( string $template, string $amount ): string {
	return str_replace( '%s', $amount, $template );
}

function glissimo_verified_shipping_threshold(): float {
	$method = glissimo_verified_shipping_method();
	return $method ? (float) $method->get_option( 'min_amount', 0 ) : 0.0;
}

/** @return array<string, mixed> */
function glissimo_shipping_progress_state(): array {
	$method = glissimo_verified_shipping_method();
	$threshold = $method ? (float) $method->get_option( 'min_amount', 0 ) : 0.0;
	if ( ! $method || $threshold <= 0 || ! function_exists( 'WC' ) || ! WC()->cart ) {
		return array();
	}
	$settings = glissimo_core_settings();
	$config = $settings['shipping_progress'] ?? array();
	$current = (float) WC()->cart->get_displayed_subtotal();
	if ( 'no' === $method->get_option( 'ignore_discounts', 'no' ) ) {
		$current -= (float) WC()->cart->get_discount_total();
		if ( WC()->cart->display_prices_including_tax() ) {
			$current -= (float) WC()->cart->get_discount_tax();
		}
	}
	$current = max( 0, round( $current, wc_get_price_decimals() ) );
	$remaining = max( 0, $threshold - $current );
	return array(
		'threshold' => $threshold,
		'current'   => $current,
		'remaining' => $remaining,
		'percent'   => min( 100, max( 0, ( $current / $threshold ) * 100 ) ),
		'message'   => $remaining > 0
			? glissimo_progress_message( (string) ( $config['before_message'] ?? '%s' ), wp_strip_all_tags( wc_price( $remaining ) ) )
			: (string) ( $config['qualified_message'] ?? '' ),
	);
}

/** @return array<string, mixed> */
function glissimo_bundle_definition( int $offer_id ): array {
	$offer = wc_get_product( $offer_id );
	$story = glissimo_product_story_meta( $offer_id );
	$bundle = is_array( $story['bundle'] ?? null ) ? $story['bundle'] : array();
	if ( ! $offer || empty( $bundle['enabled'] ) || empty( $bundle['component_ids'] ) || ! $offer->is_purchasable() || ! $offer->is_in_stock() || ! $offer->has_enough_stock( 1 ) ) {
		return array();
	}
	$component_ids = array_values( array_map( 'absint', $bundle['component_ids'] ) );
	$offer_tax_class = $offer->get_tax_class();
	foreach ( $component_ids as $component_id ) {
		$component = wc_get_product( $component_id );
		if ( ! $component || $component->get_tax_class() !== $offer_tax_class ) {
			return array();
		}
	}
	return array( 'offer' => $offer, 'components' => $component_ids, 'presentation' => $bundle );
}
