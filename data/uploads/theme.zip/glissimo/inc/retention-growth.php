<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function glissimo_loyalty_provider_ready(): bool { $s = glissimo_phase2_settings()['loyalty'] ?? array(); $loyalty_provider = (string) ( $s['provider'] ?? '' ); return 'woocommerce-points-and-rewards' === $loyalty_provider && class_exists( 'WC_Points_Rewards' ); }
function glissimo_referral_provider_ready(): bool { $s = glissimo_phase2_settings()['referral'] ?? array(); $referral_provider = (string) ( $s['provider'] ?? '' ); return 'automatewoo-refer-a-friend' === $referral_provider && class_exists( 'AutomateWoo\Referrals\Plugin' ); }
