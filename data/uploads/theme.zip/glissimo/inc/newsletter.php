<?php
/** Consent-safe newsletter adapter. @package Glissimo */
defined( 'ABSPATH' ) || exit;

function glissimo_newsletter_subscribe(): void {
	check_ajax_referer( 'glissimo_newsletter', 'nonce' );
	$remote = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? 'unknown' ) );
	$rate_key = 'gl_nl_' . substr( hash( 'sha256', $remote ), 0, 32 );
	$attempts = (int) get_transient( $rate_key );
	if ( $attempts >= 5 ) {
		wp_send_json_error( array( 'message' => __( 'Too many signup attempts. Please try again later.', 'glissimo' ) ), 429 );
	}
	set_transient( $rate_key, $attempts + 1, 10 * MINUTE_IN_SECONDS );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$consent = ! empty( $_POST['consent'] );
	$honeypot = sanitize_text_field( wp_unslash( $_POST['company'] ?? '' ) );
	if ( $honeypot || ! $consent || ! is_email( $email ) ) {
		wp_send_json_error( array( 'message' => __( 'Enter a valid email address and confirm your email preference.', 'glissimo' ) ), 400 );
	}
	$settings = glissimo_core_settings()['retention'] ?? array();
	$source = sanitize_key( wp_unslash( $_POST['source'] ?? ( $settings['source'] ?? 'homepage' ) ) );
	$context = array(
		'source'  => $source ?: 'homepage',
		'list_id' => sanitize_key( $settings['klaviyo_list_id'] ?? '' ),
		'locale'  => determine_locale(),
	);
	$adapter_ready = has_filter( 'glissimo_newsletter_subscribe' );
	$result = $adapter_ready ? apply_filters( 'glissimo_newsletter_subscribe', new WP_Error( 'provider_unavailable', __( 'Email signup is not connected yet.', 'glissimo' ) ), $email, $context ) : new WP_Error( 'provider_unavailable', __( 'Email signup is not connected yet.', 'glissimo' ) );
	$environment = defined( 'WP_ENVIRONMENT_TYPE' ) ? WP_ENVIRONMENT_TYPE : wp_get_environment_type();
	if ( is_wp_error( $result ) && 'production' !== $environment && ! empty( glissimo_core_settings()['analytics']['dry_run'] ) ) {
		$result = true; // Local dry-run: validates UX without storing or transmitting the address.
	}
	if ( is_wp_error( $result ) ) {
		wp_send_json_error( array( 'message' => $result->get_error_message() ), 503 );
	}
	wp_send_json_success( array( 'message' => __( 'Thank you. Your preference has been received.', 'glissimo' ), 'event' => array( 'event' => 'email_signup', 'source' => $context['source'] ) ) );
}
add_action( 'wp_ajax_glissimo_newsletter_subscribe', 'glissimo_newsletter_subscribe' );
add_action( 'wp_ajax_nopriv_glissimo_newsletter_subscribe', 'glissimo_newsletter_subscribe' );

function glissimo_newsletter_form( string $source = 'homepage' ): void {
	$settings = glissimo_core_settings()['retention'] ?? array();
	?>
	<form data-gl-newsletter-form>
		<input type="hidden" name="source" value="<?php echo esc_attr( sanitize_key( $source ) ); ?>">
		<label for="gl-email-<?php echo esc_attr( sanitize_html_class( $source ) ); ?>"><?php esc_html_e( 'Email address', 'glissimo' ); ?></label>
		<div class="gl-newsletter__row"><input id="gl-email-<?php echo esc_attr( sanitize_html_class( $source ) ); ?>" name="email" type="email" autocomplete="email" required placeholder="<?php esc_attr_e( 'Email address', 'glissimo' ); ?>"><button class="gl-button" type="submit"><?php echo esc_html( $settings['button_label'] ?: __( 'Keep me informed', 'glissimo' ) ); ?></button></div>
		<label class="gl-newsletter__consent"><input name="consent" type="checkbox" value="1" required> <span><?php echo esc_html( $settings['consent_copy'] ?: __( 'I would like to receive Glissimo email updates and can unsubscribe at any time.', 'glissimo' ) ); ?></span></label>
		<label class="screen-reader-text" aria-hidden="true"><?php esc_html_e( 'Company', 'glissimo' ); ?><input name="company" tabindex="-1" autocomplete="off"></label>
		<p class="gl-newsletter__status" data-gl-newsletter-status aria-live="polite"></p>
	</form>
	<?php
}
