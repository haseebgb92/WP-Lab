<?php
/**
 * Consent-neutral commerce event contracts. Vendor delivery is handled in JS.
 *
 * @package Glissimo
 */

defined( 'ABSPATH' ) || exit;

/** @return array<string, mixed> */
function glissimo_analytics_item( WC_Product $product, int $quantity = 1 ): array {
	$parent_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
	$categories = wc_get_product_category_list( $parent_id, ',', '', '' );
	return array_filter(
		array(
			'item_id'       => (string) $product->get_id(),
			'item_parent_id'=> (string) $parent_id,
			'item_name'     => $product->get_name(),
			'item_sku'      => $product->get_sku(),
			'item_category' => wp_strip_all_tags( $categories ),
			'item_variant'  => $product->is_type( 'variation' ) ? wc_get_formatted_variation( $product, true, false, false ) : '',
			'price'         => (float) wc_get_price_to_display( $product ),
			'quantity'      => max( 1, $quantity ),
		),
		static fn( $value ): bool => '' !== $value && null !== $value
	);
}

/** @return array<string, mixed> */
function glissimo_analytics_order_item( WC_Order_Item_Product $item ): array {
	$product  = $item->get_product();
	$quantity = max( 1, (int) $item->get_quantity() );
	$product_id = (int) $item->get_product_id();
	$variation_id = (int) $item->get_variation_id();
	$categories = $product_id ? wc_get_product_category_list( $product_id, ',', '', '' ) : '';
	$variant_parts = array();
	foreach ( $item->get_formatted_meta_data( '' ) as $meta ) {
		$variant_parts[] = wp_strip_all_tags( $meta->display_key . ': ' . $meta->display_value );
	}
	return array_filter(
		array(
			'item_id'       => (string) ( $variation_id ?: $product_id ),
			'item_parent_id'=> (string) $product_id,
			'item_name'     => $item->get_name(),
			'item_sku'      => $product instanceof WC_Product ? $product->get_sku() : '',
			'item_category' => wp_strip_all_tags( $categories ),
			'item_variant'  => $variation_id ? implode( ', ', $variant_parts ) : '',
			'price'         => round( (float) $item->get_total() / $quantity, wc_get_price_decimals() ),
			'discount'      => round( max( 0.0, (float) $item->get_subtotal() - (float) $item->get_total() ), wc_get_price_decimals() ),
			'quantity'      => $quantity,
		),
		static fn( $value ): bool => '' !== $value && null !== $value
	);
}

function glissimo_can_track_order( WC_Order $order ): bool {
	$key = isset( $_GET['key'] ) ? wc_clean( wp_unslash( (string) $_GET['key'] ) ) : '';
	if ( $key && hash_equals( $order->get_order_key(), $key ) ) { return true; }
	$customer_id = (int) $order->get_customer_id();
	return $customer_id > 0 && get_current_user_id() === $customer_id;
}

/** @return array<int, array<string, mixed>> */
function glissimo_initial_analytics_events(): array {
	$events = array();
	$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '';
	if ( function_exists( 'is_product' ) && is_product() ) {
		$product = wc_get_product( get_queried_object_id() );
		if ( $product ) {
			$events[] = array( 'event' => 'view_item', 'event_id' => 'view_item_' . $product->get_id(), 'ecommerce' => array( 'currency' => $currency, 'value' => (float) wc_get_price_to_display( $product ), 'items' => array( glissimo_analytics_item( $product ) ) ) );
		}
	} elseif ( function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() ) ) {
		$items = array();
		global $wp_query;
		foreach ( array_slice( (array) ( $wp_query->posts ?? array() ), 0, 24 ) as $post ) {
			$product = wc_get_product( $post );
			if ( $product ) { $items[] = glissimo_analytics_item( $product ); }
		}
		$events[] = array( 'event' => 'view_item_list', 'event_id' => 'view_item_list_' . get_queried_object_id(), 'ecommerce' => array( 'currency' => $currency, 'items' => $items ) );
	}
	if ( is_search() ) {
		$events[] = array( 'event' => 'search', 'event_id' => 'search_' . md5( get_search_query() ), 'search_term' => get_search_query() );
	}
	if ( function_exists( 'WC' ) && WC()->cart && ( is_cart() || ( is_checkout() && ! is_order_received_page() ) ) ) {
		$items = array();
		$has_gift = false;
		$has_quantity_break = false;
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( $item['data'] instanceof WC_Product ) { $items[] = glissimo_analytics_item( $item['data'], (int) $item['quantity'] ); }
			$has_gift = $has_gift || ! empty( $item['glissimo_free_gift'] );
			$has_quantity_break = $has_quantity_break || ( function_exists( 'glissimo_quantity_break_percent' ) && glissimo_quantity_break_percent( $item, WC()->cart ) > 0 );
		}
		$event = is_checkout() && ! is_order_received_page() ? 'begin_checkout' : 'view_cart';
		$events[] = array( 'event' => $event, 'event_id' => $event . '_' . WC()->cart->get_cart_hash(), 'ecommerce' => array( 'currency' => $currency, 'value' => (float) WC()->cart->get_total( 'edit' ), 'coupon' => implode( ',', WC()->cart->get_applied_coupons() ), 'items' => $items ) );
		if ( WC()->cart->get_applied_coupons() ) {
			$events[] = array( 'event' => 'coupon_usage', 'event_id' => 'coupon_' . md5( implode( '|', WC()->cart->get_applied_coupons() ) . WC()->cart->get_cart_hash() ), 'coupon' => implode( ',', WC()->cart->get_applied_coupons() ) );
		}
		if ( $has_gift ) { $events[] = array( 'event' => 'free_gift_qualification', 'event_id' => 'gift_' . WC()->cart->get_cart_hash() ); }
		if ( $has_quantity_break ) { $events[] = array( 'event' => 'quantity_break_qualification', 'event_id' => 'quantity_' . WC()->cart->get_cart_hash() ); }
	}
	if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
		$order_id = absint( get_query_var( 'order-received' ) );
		$order = $order_id ? wc_get_order( $order_id ) : false;
		if ( $order instanceof WC_Order && glissimo_can_track_order( $order ) ) {
			$items = array();
			$merchandise_value = 0.0;
			foreach ( $order->get_items() as $item ) {
				if ( $item instanceof WC_Order_Item_Product ) {
					$items[] = glissimo_analytics_order_item( $item );
					$merchandise_value += (float) $item->get_total();
				}
			}
			$events[] = array(
				'event' => 'purchase',
				'event_id' => 'purchase_' . $order->get_id(),
				'ecommerce' => array(
					'transaction_id' => (string) $order->get_id(),
					'currency'       => $order->get_currency(),
					'value'          => round( $merchandise_value, wc_get_price_decimals() ),
					'tax'            => (float) $order->get_total_tax(),
					'shipping'       => (float) $order->get_shipping_total(),
					'coupon'         => implode( ',', $order->get_coupon_codes() ),
					'items'          => $items,
				),
			);
		}
	}
	return array_values( array_filter( apply_filters( 'glissimo_analytics_initial_events', $events ) ) );
}

function glissimo_analytics_interaction_event_names(): array {
	return array( 'bundle_interaction', 'fbt_interaction', 'cart_recommendation_acceptance', 'free_gift_qualification', 'order_bump_acceptance', 'quantity_break_qualification', 'add_to_cart', 'add_payment_info', 'email_signup' );
}
