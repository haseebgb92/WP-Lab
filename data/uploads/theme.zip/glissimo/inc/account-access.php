<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Keep physical-product account endpoints intentional and provider-truthful. */
function glissimo_account_query_vars( array $vars ): array {
	unset( $vars['downloads'] );
	$vars['wishlist'] = 'wishlist';
	if ( glissimo_back_in_stock_account_available() ) { $vars['back-in-stock'] = 'back-in-stock'; }
	if ( glissimo_account_loyalty_available() ) { $vars['kitchen-club'] = 'kitchen-club'; }
	if ( glissimo_account_referral_available() ) { $vars['referrals'] = 'referrals'; }
	return $vars;
}
add_filter( 'woocommerce_get_query_vars', 'glissimo_account_query_vars' );

function glissimo_account_register_endpoints(): void {
	add_rewrite_endpoint( 'wishlist', EP_ROOT | EP_PAGES );
	if ( glissimo_back_in_stock_account_available() ) { add_rewrite_endpoint( 'back-in-stock', EP_ROOT | EP_PAGES ); }
	if ( glissimo_account_loyalty_available() ) { add_rewrite_endpoint( 'kitchen-club', EP_ROOT | EP_PAGES ); }
	if ( glissimo_account_referral_available() ) { add_rewrite_endpoint( 'referrals', EP_ROOT | EP_PAGES ); }
}
add_action( 'init', 'glissimo_account_register_endpoints', 9 );

function glissimo_back_in_stock_account_available(): bool {
	return glissimo_phase2_enabled( 'back_in_stock' ) && (bool) apply_filters( 'glissimo_back_in_stock_account_available', false );
}
function glissimo_account_loyalty_available(): bool {
	return glissimo_phase2_enabled( 'loyalty' ) && (bool) apply_filters( 'glissimo_account_loyalty_available', false );
}
function glissimo_account_referral_available(): bool {
	return glissimo_phase2_enabled( 'referral' ) && (bool) apply_filters( 'glissimo_account_referral_available', false );
}

function glissimo_account_menu_items( array $items ): array {
	unset( $items['downloads'] );
	$ordered = array();
	foreach ( array( 'dashboard', 'orders', 'edit-address' ) as $key ) { if ( isset( $items[ $key ] ) ) { $ordered[ $key ] = $items[ $key ]; } }
	if ( glissimo_phase2_enabled( 'wishlist' ) ) { $ordered['wishlist'] = __( 'Wishlist', 'glissimo' ); }
	if ( isset( $items['payment-methods'] ) ) { $ordered['payment-methods'] = $items['payment-methods']; }
	if ( glissimo_back_in_stock_account_available() ) { $ordered['back-in-stock'] = __( 'Back in Stock', 'glissimo' ); }
	if ( glissimo_account_loyalty_available() ) { $ordered['kitchen-club'] = __( 'Glissimo Kitchen Club', 'glissimo' ); }
	if ( glissimo_account_referral_available() ) { $ordered['referrals'] = __( 'Referrals', 'glissimo' ); }
	foreach ( array( 'edit-account', 'customer-logout' ) as $key ) { if ( isset( $items[ $key ] ) ) { $ordered[ $key ] = $items[ $key ]; } }
	return $ordered;
}
add_filter( 'woocommerce_account_menu_items', 'glissimo_account_menu_items', 30 );

function glissimo_account_wishlist_content(): void { glissimo_render_wishlist_surface( true ); }
add_action( 'woocommerce_account_wishlist_endpoint', 'glissimo_account_wishlist_content' );

function glissimo_account_back_in_stock_content(): void {
	/** A provider adapter must render only records belonging to the current customer. */
	do_action( 'glissimo_back_in_stock_account_content', get_current_user_id() );
}
add_action( 'woocommerce_account_back-in-stock_endpoint', 'glissimo_account_back_in_stock_content' );

function glissimo_account_loyalty_content(): void { do_action( 'glissimo_account_feature_content', 'loyalty', get_current_user_id() ); }
function glissimo_account_referral_content(): void { do_action( 'glissimo_account_feature_content', 'referral', get_current_user_id() ); }
add_action( 'woocommerce_account_kitchen-club_endpoint', 'glissimo_account_loyalty_content' );
add_action( 'woocommerce_account_referrals_endpoint', 'glissimo_account_referral_content' );
