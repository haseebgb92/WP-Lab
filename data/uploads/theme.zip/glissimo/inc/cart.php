<?php
/**
 * Smart cart rendering and secure AJAX mutations.
 *
 * @package Glissimo
 */

defined( 'ABSPATH' ) || exit;

function glissimo_cart_drawer_html(): string {
	ob_start();
	get_template_part( 'template-parts/cart-drawer' );
	return (string) ob_get_clean();
}

function glissimo_send_cart_state( string $message = '', array $event = array(), array $additional_events = array() ): void {
	if ( function_exists( 'WC' ) && WC()->cart ) {
		WC()->cart->calculate_totals();
	}
	$events = array_values( array_filter( array_merge( $event ? array( $event ) : array(), $additional_events ) ) );
	wp_send_json_success(
		array(
			'html'     => glissimo_cart_drawer_html(),
			'count'    => function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0,
			'subtotal' => function_exists( 'WC' ) && WC()->cart ? wp_strip_all_tags( WC()->cart->get_cart_subtotal() ) : '',
			'cartHash' => function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_hash() : '',
			'message'  => $message,
			'event'    => $event,
			'events'   => $events,
		)
	);
}

function glissimo_require_cart_request(): WC_Cart {
	check_ajax_referer( 'glissimo_cart', 'nonce' );
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		wp_send_json_error( array( 'message' => __( 'The cart is not available.', 'glissimo' ) ), 503 );
	}
	return WC()->cart;
}

function glissimo_cart_state(): void {
	$cart = glissimo_require_cart_request();
	glissimo_sync_free_gift();
	$product_id = absint( $_POST['product_id'] ?? 0 );
	$quantity = max( 1, min( 99, wc_stock_amount( wp_unslash( $_POST['quantity'] ?? 1 ) ) ) );
	$event = array();
	if ( $product_id ) {
		foreach ( $cart->get_cart() as $item ) {
			$product = $item['data'] ?? null;
			if ( $product instanceof WC_Product && in_array( $product_id, array( $product->get_id(), $product->get_parent_id() ), true ) ) {
				$event = array( 'event' => 'add_to_cart', 'event_id' => 'native_add_' . wp_generate_uuid4(), 'ecommerce' => array( 'currency' => get_woocommerce_currency(), 'value' => (float) wc_get_price_to_display( $product ) * $quantity, 'items' => array( glissimo_analytics_item( $product, $quantity ) ) ) );
				break;
			}
		}
	}
	glissimo_send_cart_state( '', $event );
}
add_action( 'wp_ajax_glissimo_cart_state', 'glissimo_cart_state' );
add_action( 'wp_ajax_nopriv_glissimo_cart_state', 'glissimo_cart_state' );

function glissimo_cart_add(): void {
	$cart = glissimo_require_cart_request();
	$product_id = absint( $_POST['product_id'] ?? 0 );
	$variation_id = absint( $_POST['variation_id'] ?? 0 );
	$quantity = max( 1, min( 99, wc_stock_amount( wp_unslash( $_POST['quantity'] ?? 1 ) ) ) );
	$product = wc_get_product( $variation_id ?: $product_id );
	if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() || ! $product->has_enough_stock( $quantity ) ) {
		wp_send_json_error( array( 'message' => __( 'This product is not available in the requested quantity.', 'glissimo' ) ), 409 );
	}
	if ( $product->is_type( 'variation' ) ) {
		if ( $product->get_parent_id() !== $product_id ) {
			wp_send_json_error( array( 'message' => __( 'The selected variation is invalid.', 'glissimo' ) ), 400 );
		}
		$variation_id = $product->get_id();
		$variation = $product->get_variation_attributes();
	} elseif ( $product->is_type( 'variable' ) ) {
		wp_send_json_error( array( 'message' => __( 'Choose product options before adding this item.', 'glissimo' ) ), 400 );
	} else {
		$product_id = $product->get_id();
		$variation_id = 0;
		$variation = array();
	}
	$valid = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity, $variation_id, $variation );
	$key = $valid ? $cart->add_to_cart( $product_id, $quantity, $variation_id, $variation ) : false;
	if ( ! $key ) {
		wp_send_json_error( array( 'message' => __( 'This item could not be added. Your cart was not changed.', 'glissimo' ) ), 409 );
	}
	glissimo_sync_free_gift();
	glissimo_send_cart_state(
		__( 'Added to your cart.', 'glissimo' ),
		array( 'event' => 'add_to_cart', 'event_id' => 'add_' . wp_generate_uuid4(), 'ecommerce' => array( 'currency' => get_woocommerce_currency(), 'value' => (float) wc_get_price_to_display( $product ) * $quantity, 'items' => array( glissimo_analytics_item( $product, $quantity ) ) ) )
	);
}
add_action( 'wp_ajax_glissimo_cart_add', 'glissimo_cart_add' );
add_action( 'wp_ajax_nopriv_glissimo_cart_add', 'glissimo_cart_add' );

function glissimo_cart_update(): void {
	$cart = glissimo_require_cart_request();
	$key = wc_clean( wp_unslash( $_POST['cart_item_key'] ?? '' ) );
	$quantity = max( 0, min( 99, wc_stock_amount( wp_unslash( $_POST['quantity'] ?? 1 ) ) ) );
	$item = $cart->get_cart_item( $key );
	if ( ! $item ) {
		wp_send_json_error( array( 'message' => __( 'That cart item no longer exists.', 'glissimo' ) ), 404 );
	}
	if ( ! empty( $item['glissimo_free_gift'] ) || ! empty( $item['glissimo_bundle_group'] ) || ! empty( $item['glissimo_order_bump'] ) ) {
		wp_send_json_error( array( 'message' => __( 'This promotional item has a fixed quantity.', 'glissimo' ) ), 409 );
	}
	if ( $quantity > 0 && ! $item['data']->has_enough_stock( $quantity ) ) {
		wp_send_json_error( array( 'message' => __( 'The requested quantity is not currently available.', 'glissimo' ) ), 409 );
	}
	if ( $quantity > 1 && $item['data']->is_sold_individually() ) {
		wp_send_json_error( array( 'message' => __( 'This product is limited to one per order.', 'glissimo' ) ), 409 );
	}
	$valid = apply_filters( 'woocommerce_update_cart_validation', true, $key, $item, $quantity );
	if ( ! $valid ) {
		wp_send_json_error( array( 'message' => __( 'This cart quantity could not be updated.', 'glissimo' ) ), 409 );
	}
	$cart->set_quantity( $key, $quantity, false );
	glissimo_sync_free_gift();
	glissimo_send_cart_state( __( 'Cart updated.', 'glissimo' ) );
}
add_action( 'wp_ajax_glissimo_cart_update', 'glissimo_cart_update' );
add_action( 'wp_ajax_nopriv_glissimo_cart_update', 'glissimo_cart_update' );

function glissimo_cart_remove(): void {
	$cart = glissimo_require_cart_request();
	$key = wc_clean( wp_unslash( $_POST['cart_item_key'] ?? '' ) );
	$item = $cart->get_cart_item( $key );
	if ( ! $item ) {
		wp_send_json_error( array( 'message' => __( 'That cart item no longer exists.', 'glissimo' ) ), 404 );
	}
	if ( ! empty( $item['glissimo_free_gift'] ) && WC()->session ) {
		WC()->session->set( 'glissimo_gift_declined', true );
	}
	$keys = array( $key );
	if ( ! empty( $item['glissimo_bundle_group'] ) ) {
		$keys = array();
		foreach ( $cart->get_cart() as $candidate_key => $candidate ) {
			if ( (string) ( $candidate['glissimo_bundle_group'] ?? '' ) === (string) $item['glissimo_bundle_group'] ) {
				$keys[] = $candidate_key;
			}
		}
	}
	foreach ( $keys as $remove_key ) {
		$cart->remove_cart_item( $remove_key );
	}
	glissimo_sync_free_gift();
	glissimo_send_cart_state( __( 'Item removed.', 'glissimo' ) );
}
add_action( 'wp_ajax_glissimo_cart_remove', 'glissimo_cart_remove' );
add_action( 'wp_ajax_nopriv_glissimo_cart_remove', 'glissimo_cart_remove' );

function glissimo_cart_fragments( array $fragments ): array {
	$fragments['div.gl-cart-drawer-root'] = '<div class="gl-cart-drawer-root">' . glissimo_cart_drawer_html() . '</div>';
	$count = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	$fragments['span.gl-cart-count'] = '<span class="gl-cart-count">' . esc_html( $count ) . '</span>';
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'glissimo_cart_fragments' );
