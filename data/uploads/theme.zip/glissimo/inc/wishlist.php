<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function glissimo_wishlist_ids(): array { return is_user_logged_in() ? array_values( array_filter( array_map( 'absint', (array) get_user_meta( get_current_user_id(), '_glissimo_wishlist', true ) ) ) ) : array(); }
function glissimo_wishlist_url(): string {
	$page = get_page_by_path( 'wishlist' );
	return $page instanceof WP_Post ? get_permalink( $page ) : home_url( '/wishlist/' );
}
function glissimo_wishlist_sync(): void { check_ajax_referer( 'glissimo_phase2', 'nonce' ); if ( ! glissimo_phase2_enabled( 'wishlist' ) ) { wp_send_json_error( array( 'message' => __( 'Wishlist is unavailable.', 'glissimo' ) ), 400 ); } $ids = array_values( array_unique( array_filter( array_map( 'absint', is_array( $_POST['product_ids'] ?? null ) ? wp_unslash( $_POST['product_ids'] ) : array() ) ) ) ); $ids = array_slice( $ids, 0, 100 ); if ( is_user_logged_in() ) { update_user_meta( get_current_user_id(), '_glissimo_wishlist', $ids ); } wp_send_json_success( array( 'productIds' => $ids ) ); }
add_action( 'wp_ajax_glissimo_wishlist_sync', 'glissimo_wishlist_sync' ); add_action( 'wp_ajax_nopriv_glissimo_wishlist_sync', 'glissimo_wishlist_sync' );
function glissimo_wishlist_product_payload( WC_Product $p ): array { return array( 'id' => $p->get_id(), 'name' => $p->get_name(), 'url' => $p->get_permalink(), 'image' => wp_get_attachment_image_url( $p->get_image_id(), 'woocommerce_thumbnail' ) ?: wc_placeholder_img_src(), 'priceHtml' => wp_kses_post( $p->get_price_html() ), 'inStock' => $p->is_in_stock(), 'cartUrl' => $p->is_in_stock() && $p->is_type( 'simple' ) && $p->is_purchasable() ? add_query_arg( 'add-to-cart', $p->get_id(), wc_get_cart_url() ) : $p->get_permalink() ); }
function glissimo_wishlist_products(): void { check_ajax_referer( 'glissimo_phase2', 'nonce' ); if ( ! glissimo_phase2_enabled( 'wishlist' ) ) { wp_send_json_error( array( 'message' => __( 'Wishlist is unavailable.', 'glissimo' ) ), 400 ); } $ids = array_values( array_unique( array_filter( array_map( 'absint', is_array( $_GET['product_ids'] ?? null ) ? wp_unslash( $_GET['product_ids'] ) : array() ) ) ) ); if ( is_user_logged_in() ) { $ids = array_values( array_unique( array_merge( glissimo_wishlist_ids(), $ids ) ) ); } $results = array(); foreach ( array_slice( $ids, 0, 100 ) as $id ) { $p = wc_get_product( $id ); if ( ! $p || ! $p->is_visible() ) { continue; } $results[] = glissimo_wishlist_product_payload( $p ); } $recommendations = array(); foreach ( glissimo_personalized_recommendation_ids( $ids, 4 ) as $id ) { $product = wc_get_product( $id ); if ( $product ) { $recommendations[] = glissimo_wishlist_product_payload( $product ); } } wp_send_json_success( array( 'products' => $results, 'recommendations' => $recommendations ) ); }
add_action( 'wp_ajax_glissimo_wishlist_products', 'glissimo_wishlist_products' ); add_action( 'wp_ajax_nopriv_glissimo_wishlist_products', 'glissimo_wishlist_products' );
function glissimo_wishlist_button(): void { if ( ! glissimo_phase2_enabled( 'wishlist' ) ) { return; } global $product; if ( ! $product instanceof WC_Product ) { return; } ?><button type="button" class="gl-wishlist-button gl-button gl-button--secondary" data-gl-wishlist-toggle data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" aria-pressed="false"><?php echo glissimo_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php esc_html_e( 'Save for later', 'glissimo' ); ?></span></button><?php }

function glissimo_render_wishlist_surface( bool $account = false ): void {
	$heading = $account ? __( 'Wishlist', 'glissimo' ) : ( glissimo_phase2_settings()['wishlist']['title'] ?? __( 'Wishlist', 'glissimo' ) );
	?>
	<section class="gl-container gl-wishlist <?php echo $account ? 'gl-wishlist--account' : ''; ?>" data-gl-wishlist-page data-server-ids="<?php echo esc_attr( wp_json_encode( glissimo_wishlist_ids() ) ); ?>">
		<?php if ( $account ) : ?><header class="gl-wishlist__account-heading"><p class="gl-eyebrow"><?php esc_html_e( 'Saved for later', 'glissimo' ); ?></p><h2><?php echo esc_html( $heading ); ?></h2></header><?php endif; ?>
		<div class="gl-product-grid" data-gl-wishlist-grid></div>
		<div class="gl-empty" data-gl-wishlist-empty><h2><?php esc_html_e( 'Your wishlist is ready when inspiration strikes.', 'glissimo' ); ?></h2><p><?php esc_html_e( 'Save products while you browse and return to them here.', 'glissimo' ); ?></p><a class="gl-button" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Explore products', 'glissimo' ); ?></a></div>
		<section class="gl-wishlist__recommendations" data-gl-personalized hidden><p class="gl-eyebrow"><?php esc_html_e( 'Based on your saved products', 'glissimo' ); ?></p><h2><?php esc_html_e( 'More for your kitchen', 'glissimo' ); ?></h2><div class="gl-product-rail" data-gl-personalized-grid></div></section>
	</section>
	<?php
}
