<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function glissimo_phase2_settings(): array {
	return class_exists( '\\Advertpreneur\\Core\\Sites\\Glissimo\\Phase2Settings' ) ? \Advertpreneur\Core\Sites\Glissimo\Phase2Settings::all() : array();
}

function glissimo_phase2_enabled( string $feature ): bool {
	$settings = glissimo_phase2_settings();
	if ( empty( $settings[ $feature ]['enabled'] ) ) { return false; }
	if ( 'bundle_builder' === $feature ) { return '' !== trim( (string) ( $settings[ $feature ]['steps'] ?? '' ) ); }
	if ( 'comparison' === $feature ) { return ! empty( $settings[ $feature ]['product_ids'] ); }
	if ( 'quiz' === $feature ) { return '' !== trim( (string) ( $settings[ $feature ]['questions'] ?? '' ) ) && '' !== trim( (string) ( $settings[ $feature ]['rules'] ?? '' ) ); }
	if ( 'loyalty' === $feature && function_exists( 'glissimo_loyalty_provider_ready' ) ) { return glissimo_loyalty_provider_ready(); }
	if ( 'referral' === $feature && function_exists( 'glissimo_referral_provider_ready' ) ) { return glissimo_referral_provider_ready(); }
	return true;
}

function glissimo_phase2_enqueue(): void {
	$wishlist_active = glissimo_phase2_enabled( 'wishlist' );
	$interactive_surface = is_page( array( 'build-your-kitchen', 'compare-products', 'product-finder', 'kitchen-club', 'refer-a-friend' ) ) || is_singular( 'glissimo_landing' ) || is_product() || ( function_exists( 'is_order_received_page' ) && is_order_received_page() && ! empty( glissimo_phase2_settings()['post_purchase']['enabled'] ) );
	if ( ! $interactive_surface && ! $wishlist_active ) { return; }
	wp_enqueue_style( 'glissimo-phase2', get_theme_file_uri( '/assets/css/phase2.css' ), array( 'glissimo-commerce-ui-refinement' ), glissimo_asset_version( '/assets/css/phase2.css' ) );
	$phase2 = glissimo_phase2_settings();
	$localized = array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce' => wp_create_nonce( 'glissimo_phase2' ),
		'cartUrl' => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' ),
		'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '',
		'currencySymbol' => function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '',
		'priceFormat' => function_exists( 'get_woocommerce_price_format' ) ? get_woocommerce_price_format() : '%1$s%2$s',
		'decimalSeparator' => function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : '.',
		'thousandSeparator' => function_exists( 'wc_get_price_thousand_separator' ) ? wc_get_price_thousand_separator() : ',',
		'priceDecimals' => function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2,
		'builderDiscount' => (float) ( $phase2['bundle_builder']['discount_percent'] ?? 0 ),
		'wishlistIds' => glissimo_phase2_enabled( 'wishlist' ) && function_exists( 'glissimo_wishlist_ids' ) ? glissimo_wishlist_ids() : array(),
		'error' => __( 'That action could not be completed. Please try again.', 'glissimo' ),
		'labels' => array(
			'chooseProducts' => __( 'Choose products to build your set.', 'glissimo' ),
			'noMatch' => __( 'No exact match yet', 'glissimo' ),
			'noMatchCopy' => __( 'Explore the collection or adjust your answers.', 'glissimo' ),
			'matchEyebrow' => __( 'Your Glissimo match', 'glissimo' ),
			'resultHeading' => __( 'Chosen for the way you cook.', 'glissimo' ),
			'shopMatch' => __( 'Shop your match', 'glissimo' ),
			'whyItFits' => __( 'Why it fits', 'glissimo' ),
			'basedOnAnswers' => __( 'Based on your answers', 'glissimo' ),
			'retakeFinder' => __( 'Retake the finder', 'glissimo' ),
			'saved' => __( 'Saved', 'glissimo' ),
			'save' => __( 'Save for later', 'glissimo' ),
			'addToCart' => __( 'Add to cart', 'glissimo' ),
			'viewProduct' => __( 'View product', 'glissimo' ),
			'remove' => __( 'Remove', 'glissimo' ),
			'wishlistEmpty' => __( 'Wishlist, no saved items', 'glissimo' ),
			'wishlistCount' => __( 'Wishlist, %d saved items', 'glissimo' ),
			'wishlistCountSingle' => __( 'Wishlist, 1 saved item', 'glissimo' ),
		),
	);
	if ( $interactive_surface ) {
		wp_enqueue_script( 'glissimo-phase2', get_theme_file_uri( '/assets/js/phase2.js' ), array( 'glissimo-analytics' ), glissimo_asset_version( '/assets/js/phase2.js' ), true );
		wp_localize_script( 'glissimo-phase2', 'GlissimoPhase2', $localized );
	}
	if ( $wishlist_active ) {
		$dependencies = $interactive_surface ? array( 'glissimo-phase2' ) : array( 'glissimo-analytics' );
		wp_enqueue_script( 'glissimo-wishlist', get_theme_file_uri( '/assets/js/wishlist.js' ), $dependencies, glissimo_asset_version( '/assets/js/wishlist.js' ), true );
		if ( ! $interactive_surface ) { wp_localize_script( 'glissimo-wishlist', 'GlissimoPhase2', $localized ); }
	}
}
add_action( 'wp_enqueue_scripts', 'glissimo_phase2_enqueue', 30 );

function glissimo_phase2_template( string $template ): string {
	$map = array( 'build-your-kitchen' => 'page-build-your-kitchen.php', 'compare-products' => 'page-product-comparison.php', 'wishlist' => 'page-wishlist.php', 'product-finder' => 'page-product-finder.php', 'kitchen-club' => 'page-kitchen-club.php', 'refer-a-friend' => 'page-refer-a-friend.php' );
	foreach ( $map as $slug => $file ) { if ( is_page( $slug ) && is_file( get_theme_file_path( '/' . $file ) ) ) { return get_theme_file_path( '/' . $file ); } }
	return $template;
}
add_filter( 'template_include', 'glissimo_phase2_template', 50 );
