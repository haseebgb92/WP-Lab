<?php
/**
 * Customer account page without the generic WordPress title wrapper.
 *
 * WooCommerce supplies authentication and account endpoint content. The
 * Glissimo account templates provide the visible page hierarchy.
 *
 * @package Glissimo
 */

get_header();
?>
<main id="main-content" class="gl-main" tabindex="-1">
	<?php while ( have_posts() ) : ?>
		<?php the_post(); ?>
		<?php the_content(); ?>
	<?php endwhile; ?>
</main>
<?php
get_footer();
