<?php
/** Reusable Core-managed branded editorial/support page. */
defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	$slug     = get_post_field( 'post_name', get_the_ID() );
	$settings = glissimo_core_settings();
	$page     = glissimo_customer_content_tree( $settings['editorial_pages'][ $slug ] ?? array() );
	$defaults = array(
		'about-glissimo'   => array( 'eyebrow' => __( 'About Glissimo', 'glissimo' ), 'heading' => __( 'Made for everyday excellence.', 'glissimo' ), 'intro' => __( 'A considered kitchen starts with products that earn their place in it.', 'glissimo' ) ),
		'faq'              => array( 'eyebrow' => __( 'Support', 'glissimo' ), 'heading' => __( 'How can we help?', 'glissimo' ), 'intro' => __( 'Browse common topics or contact our support team for individual help.', 'glissimo' ) ),
		'contact'          => array( 'eyebrow' => __( 'Contact Glissimo', 'glissimo' ), 'heading' => __( 'We are here to help.', 'glissimo' ), 'intro' => __( 'Tell us what you need and our support team will respond using the details you provide.', 'glissimo' ) ),
		'shipping-returns' => array( 'eyebrow' => __( 'Customer care', 'glissimo' ), 'heading' => __( 'Shipping & Returns', 'glissimo' ), 'intro' => '' ),
		'warranty'         => array( 'eyebrow' => __( 'Product support', 'glissimo' ), 'heading' => __( 'Warranty', 'glissimo' ), 'intro' => '' ),
		'product-care'     => array( 'eyebrow' => __( 'Use it well', 'glissimo' ), 'heading' => __( 'Product Care', 'glissimo' ), 'intro' => '' ),
		'bundles'          => array( 'eyebrow' => __( 'Shop together', 'glissimo' ), 'heading' => __( 'Build a considered kitchen.', 'glissimo' ), 'intro' => __( 'Explore complementary pieces for your kitchen. Each item keeps its individual checkout price unless a verified bundle offer is shown.', 'glissimo' ) ),
		'privacy-policy'   => array( 'eyebrow' => __( 'Legal', 'glissimo' ), 'heading' => __( 'Privacy Policy', 'glissimo' ), 'intro' => '' ),
		'terms-conditions' => array( 'eyebrow' => __( 'Legal', 'glissimo' ), 'heading' => __( 'Terms & Conditions', 'glissimo' ), 'intro' => '' ),
		'cookie-policy'    => array( 'eyebrow' => __( 'Legal', 'glissimo' ), 'heading' => __( 'Cookie Policy', 'glissimo' ), 'intro' => '' ),
	);
	$fallback        = $defaults[ $slug ] ?? array( 'eyebrow' => __( 'Glissimo', 'glissimo' ), 'heading' => get_the_title(), 'intro' => '' );
	$eyebrow         = trim( (string) ( $page['eyebrow'] ?? '' ) ) ?: $fallback['eyebrow'];
	$heading         = trim( (string) ( $page['heading'] ?? '' ) ) ?: $fallback['heading'];
	$intro           = trim( (string) ( $page['intro'] ?? '' ) ) ?: $fallback['intro'];
	$body            = trim( (string) ( $page['body'] ?? '' ) );
	$section_heading = trim( (string) ( $page['section_heading'] ?? '' ) );
	$section_body    = trim( (string) ( $page['section_body'] ?? '' ) );
	$layout          = in_array( $page['layout'] ?? '', array( 'standard', 'split', 'media-wide' ), true ) ? $page['layout'] : 'standard';
	$lines           = static fn( $value ): array => array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) $value ) ?: array() ) ) );
	$items           = $lines( $page['items'] ?? '' );
	$links           = $lines( $page['links'] ?? '' );
	$resolve_link    = static fn( string $url ): string => 0 === strpos( $url, '/' ) ? home_url( $url ) : $url;
	$has_support     = 'contact' !== $slug && ( $section_heading || $section_body || ! empty( $page['section_media_id'] ) );
	$has_cta         = ! empty( $page['cta_heading'] ) || ! empty( $page['cta_copy'] ) || ( ! empty( $page['cta_label'] ) && ! empty( $page['cta_url'] ) ) || ( ! empty( $page['secondary_cta_label'] ) && ! empty( $page['secondary_cta_url'] ) );
	?>
	<main id="main-content" class="gl-editorial-page gl-editorial-page--<?php echo esc_attr( $slug ); ?>" tabindex="-1">
		<header class="gl-editorial-hero"><div class="gl-container gl-editorial-hero__grid"><div><p class="gl-eyebrow"><?php echo esc_html( $eyebrow ); ?></p><h1 class="gl-heading-display"><?php echo esc_html( $heading ); ?></h1><?php if ( $intro ) : ?><p class="gl-editorial-hero__intro"><?php echo esc_html( $intro ); ?></p><?php endif; ?></div><?php if ( ! empty( $page['media_id'] ) ) : ?><div class="gl-editorial-hero__media"><?php echo glissimo_editorial_media( absint( $page['media_id'] ), 'large' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?></div></header>

		<?php if ( $body || trim( (string) get_the_content() ) ) : ?><section class="gl-editorial-section gl-container"><div class="gl-editorial-prose"><?php echo wp_kses_post( wpautop( $body ?: get_the_content() ) ); ?></div></section><?php endif; ?>

		<?php if ( $has_support ) : ?>
			<section class="gl-editorial-section gl-editorial-support gl-editorial-support--<?php echo esc_attr( $layout ); ?>"><div class="gl-container gl-editorial-support__grid"><div class="gl-editorial-support__copy"><?php if ( $section_heading ) : ?><h2><?php echo esc_html( $section_heading ); ?></h2><?php endif; ?><?php if ( $section_body ) : ?><div class="gl-editorial-prose"><?php echo wp_kses_post( wpautop( $section_body ) ); ?></div><?php endif; ?></div><?php if ( ! empty( $page['section_media_id'] ) ) : ?><div class="gl-editorial-support__media"><?php echo glissimo_editorial_media( absint( $page['section_media_id'] ), 'large' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?></div></section>
		<?php endif; ?>

		<?php if ( $items && 'faq' === $slug ) : ?>
			<section class="gl-editorial-section gl-container"><div class="gl-editorial-accordions"><?php foreach ( $items as $item ) : $parts = array_map( 'trim', explode( '|', $item, 4 ) ); if ( empty( $parts[0] ) ) { continue; } ?><details class="gl-accordion"><summary><span><?php echo esc_html( $parts[0] ); ?></span><span class="gl-accordion__icon" aria-hidden="true"><?php echo glissimo_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></summary><div class="gl-accordion__content"><?php if ( ! empty( $parts[1] ) ) : ?><p><?php echo esc_html( $parts[1] ); ?></p><?php endif; ?><?php if ( ! empty( $parts[2] ) ) : ?><a class="gl-text-link" href="<?php echo esc_url( $resolve_link( $parts[2] ) ); ?>"><?php echo esc_html( $parts[3] ?? __( 'Learn more', 'glissimo' ) ); ?></a><?php endif; ?></div></details><?php endforeach; ?></div></section>
		<?php elseif ( $items ) : ?>
			<section class="gl-editorial-section gl-editorial-section--tint"><div class="gl-container gl-support-card-grid"><?php foreach ( $items as $item ) : $parts = array_map( 'trim', explode( '|', $item, 4 ) ); if ( empty( $parts[0] ) ) { continue; } ?><article><h2><?php echo esc_html( $parts[0] ); ?></h2><?php if ( ! empty( $parts[1] ) ) : ?><p><?php echo esc_html( $parts[1] ); ?></p><?php endif; ?><?php if ( ! empty( $parts[2] ) ) : ?><a class="gl-text-link" href="<?php echo esc_url( $resolve_link( $parts[2] ) ); ?>"><?php echo esc_html( $parts[3] ?? __( 'Learn more', 'glissimo' ) ); ?></a><?php endif; ?></article><?php endforeach; ?></div></section>
		<?php endif; ?>

		<?php if ( 'contact' === $slug ) : ?>
			<section class="gl-editorial-section gl-container gl-contact-layout"><div><p class="gl-eyebrow"><?php esc_html_e( 'Send a message', 'glissimo' ); ?></p><h2><?php echo esc_html( $section_heading ?: __( 'Tell us how we can help.', 'glissimo' ) ); ?></h2><?php if ( $section_body ) : ?><div class="gl-editorial-prose"><?php echo wp_kses_post( wpautop( $section_body ) ); ?></div><?php endif; ?></div><form class="gl-contact-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><?php wp_nonce_field( 'glissimo_contact', 'glissimo_contact_nonce' ); ?><input type="hidden" name="action" value="glissimo_contact"><label><?php esc_html_e( 'Name', 'glissimo' ); ?><input name="name" autocomplete="name" required></label><label><?php esc_html_e( 'Email address', 'glissimo' ); ?><input type="email" name="email" autocomplete="email" required></label><label><?php esc_html_e( 'Order number (optional)', 'glissimo' ); ?><input name="order_number" autocomplete="off"></label><label><?php esc_html_e( 'How can we help?', 'glissimo' ); ?><textarea name="message" rows="6" required></textarea></label><label class="screen-reader-text" aria-hidden="true">Company<input name="company" tabindex="-1" autocomplete="off"></label><button class="gl-button" type="submit"><?php esc_html_e( 'Send message', 'glissimo' ); ?></button><?php if ( isset( $_GET['contact_status'] ) ) : ?><p class="gl-contact-form__status" role="status"><?php echo 'sent' === sanitize_key( wp_unslash( $_GET['contact_status'] ) ) ? esc_html__( 'Thank you. Your message has been submitted.', 'glissimo' ) : esc_html__( 'Please check the form and try again.', 'glissimo' ); ?></p><?php endif; ?></form></section>
		<?php elseif ( 'bundles' === $slug ) :
			$bundle_products = wc_get_products( array( 'limit' => 12, 'status' => 'publish' ) );
			$bundle_products = array_values( array_filter( $bundle_products, static fn( $product ) => function_exists( 'glissimo_bundle_definition' ) && glissimo_bundle_definition( $product->get_id() ) ) );
			$has_verified_bundles = ! empty( $bundle_products );
			if ( ! $has_verified_bundles ) {
				$bundle_products = wc_get_products( array( 'limit' => 4, 'status' => 'publish', 'stock_status' => 'instock', 'orderby' => 'date', 'order' => 'DESC' ) );
			}
			?>
			<section class="gl-editorial-section gl-bundle-discovery"><div class="gl-container"><div class="gl-bundle-discovery__heading"><div><p class="gl-eyebrow"><?php echo esc_html( $has_verified_bundles ? __( 'Verified bundle offers', 'glissimo' ) : __( 'Start with the pieces you need', 'glissimo' ) ); ?></p><h2><?php echo esc_html( $has_verified_bundles ? __( 'Shop Glissimo bundles', 'glissimo' ) : __( 'Complete your kitchen, your way.', 'glissimo' ) ); ?></h2><p><?php echo esc_html( $has_verified_bundles ? __( 'Every displayed bundle shows its included products and actual saving before checkout.', 'glissimo' ) : __( 'These complementary products are available individually. Individual checkout price applies unless a verified bundle offer is shown.', 'glissimo' ) ); ?></p></div><a class="gl-button gl-button--outline" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Shop the collection', 'glissimo' ); ?></a></div><?php if ( $bundle_products ) : ?><div class="gl-product-grid"><?php foreach ( $bundle_products as $bundle_product ) { glissimo_product_card( $bundle_product ); } ?></div><?php endif; ?></div></section>
		<?php endif; ?>

		<?php if ( $links ) : ?><nav class="gl-editorial-related gl-container" aria-label="<?php esc_attr_e( 'Related information', 'glissimo' ); ?>"><?php foreach ( $links as $link ) : $parts = array_map( 'trim', explode( '|', $link, 2 ) ); if ( empty( $parts[0] ) || empty( $parts[1] ) ) { continue; } ?><a class="gl-text-link" href="<?php echo esc_url( $resolve_link( $parts[1] ) ); ?>"><?php echo esc_html( $parts[0] ); ?></a><?php endforeach; ?></nav><?php endif; ?>

		<?php if ( $has_cta ) : ?><section class="gl-editorial-cta"><div class="gl-container"><div><?php if ( ! empty( $page['cta_heading'] ) ) : ?><h2><?php echo esc_html( $page['cta_heading'] ); ?></h2><?php endif; ?><?php if ( ! empty( $page['cta_copy'] ) ) : ?><div class="gl-editorial-prose"><?php echo wp_kses_post( wpautop( $page['cta_copy'] ) ); ?></div><?php endif; ?></div><div class="gl-editorial-cta__actions"><?php if ( ! empty( $page['cta_label'] ) && ! empty( $page['cta_url'] ) ) : ?><a class="gl-button" href="<?php echo esc_url( $resolve_link( $page['cta_url'] ) ); ?>"><?php echo esc_html( $page['cta_label'] ); ?></a><?php endif; ?><?php if ( ! empty( $page['secondary_cta_label'] ) && ! empty( $page['secondary_cta_url'] ) ) : ?><a class="gl-button gl-button--secondary" href="<?php echo esc_url( $resolve_link( $page['secondary_cta_url'] ) ); ?>"><?php echo esc_html( $page['secondary_cta_label'] ); ?></a><?php endif; ?></div></div></section><?php endif; ?>
	</main>
	<?php
endwhile;
get_footer();
