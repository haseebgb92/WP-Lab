<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$s = glissimo_phase2_settings()['comparison'] ?? array();
if ( ! glissimo_phase2_enabled( 'comparison' ) ) { wp_safe_redirect( wc_get_page_permalink( 'shop' ) ); exit; }
$products = array_values( array_filter( array_map( 'wc_get_product', $s['product_ids'] ), static fn( $product ) => $product instanceof WC_Product && $product->is_visible() ) );
$rows = array(
	array(
		'label'  => __( 'Availability', 'glissimo' ),
		'values' => array_map( static fn( WC_Product $product ): string => $product->is_in_stock() ? __( 'Available', 'glissimo' ) : __( 'Currently sold out', 'glissimo' ), $products ),
	),
);
$dimensions = array_map( static fn( WC_Product $product ): string => wc_format_dimensions( $product->get_dimensions( false ) ), $products );
if ( array_filter( $dimensions, static fn( string $value ): bool => '' !== trim( wp_strip_all_tags( $value ) ) && __( 'N/A', 'woocommerce' ) !== $value ) ) {
	$rows[] = array( 'label' => __( 'Dimensions', 'glissimo' ), 'values' => $dimensions );
}
foreach ( $s['attribute_slugs'] as $slug ) {
	$taxonomy = taxonomy_exists( $slug ) ? $slug : 'pa_' . sanitize_title( $slug );
	$values = array_map( static fn( WC_Product $product ): string => (string) $product->get_attribute( $taxonomy ), $products );
	if ( array_filter( $values, static fn( string $value ): bool => '' !== trim( $value ) ) ) { $rows[] = array( 'label' => wc_attribute_label( $taxonomy ), 'values' => $values ); }
}
get_header();
?>
<main id="main-content" class="gl-phase2 gl-compare">
	<header class="gl-phase2__hero"><div class="gl-container"><p class="gl-eyebrow"><?php esc_html_e( 'Product comparison', 'glissimo' ); ?></p><h1 class="gl-heading-display"><?php echo esc_html( $s['title'] ); ?></h1></div></header>
	<div class="gl-container"><div class="gl-compare__scroll" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Scrollable product comparison', 'glissimo' ); ?>"><div class="gl-compare__grid" style="--gl-compare-count:<?php echo esc_attr( max( 1, count( $products ) ) ); ?>">
		<div class="gl-compare__label"><?php esc_html_e( 'Product', 'glissimo' ); ?></div>
		<?php foreach ( $products as $product ) : ?><article><?php if ( (int) $s['popular_product_id'] === $product->get_id() ) : ?><span class="gl-badge"><?php echo esc_html( $s['badge'] ); ?></span><?php endif; ?><?php echo $product->get_image( 'woocommerce_thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><h2><?php echo esc_html( $product->get_name() ); ?></h2><p><?php echo wp_kses_post( $product->get_price_html() ); ?></p><a class="gl-button gl-button--compact" href="<?php echo esc_url( $product->get_permalink() ); ?>" data-gl-comparison-product data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"><?php esc_html_e( 'View product', 'glissimo' ); ?></a></article><?php endforeach; ?>
		<?php foreach ( $rows as $row ) : ?><div class="gl-compare__label"><?php echo esc_html( $row['label'] ); ?></div><?php foreach ( $row['values'] as $value ) : ?><div class="gl-compare__value"><?php echo wp_kses_post( $value ?: '—' ); ?></div><?php endforeach; endforeach; ?>
	</div></div></div>
</main>
<?php get_footer(); ?>
