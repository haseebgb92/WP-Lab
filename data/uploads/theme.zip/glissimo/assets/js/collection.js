(() => {
	const drawer = document.querySelector('[data-gl-filter-drawer]');
	const openButton = document.querySelector('[data-gl-filter-open]');
	const closeButton = document.querySelector('[data-gl-filter-close]');

	if (!drawer || !openButton || !closeButton) {
		return;
	}

	const focusable = (root) => Array.from(root.querySelectorAll('a,button,input,select,textarea')).filter((node) => !node.disabled);
	let returnFocus = null;

	const trapFocus = (event) => {
		if (event.key !== 'Tab') {
			return;
		}
		const nodes = focusable(drawer);
		if (!nodes.length) {
			return;
		}
		if (event.shiftKey && document.activeElement === nodes[0]) {
			event.preventDefault();
			nodes[nodes.length - 1].focus();
		} else if (!event.shiftKey && document.activeElement === nodes[nodes.length - 1]) {
			event.preventDefault();
			nodes[0].focus();
		}
	};

	const lockBody = () => document.body.classList.add('gl-collection-filter-open');
	const unlockBody = () => document.body.classList.remove('gl-collection-filter-open');

	const openDrawer = () => {
		returnFocus = document.activeElement;
		drawer.hidden = false;
		openButton.setAttribute('aria-expanded', 'true');
		focusable(drawer)[0]?.focus();
		lockBody();
	};

	const closeDrawer = () => {
		drawer.hidden = true;
		openButton.setAttribute('aria-expanded', 'false');
		unlockBody();
		returnFocus?.focus();
	};

	openButton.addEventListener('click', openDrawer);
	closeButton.addEventListener('click', closeDrawer);
	drawer.addEventListener('click', (event) => {
		if (event.target === drawer) closeDrawer();
	});

	document.addEventListener('keydown', (event) => {
		if (!drawer.hidden && event.key === 'Escape') {
			event.preventDefault();
			closeDrawer();
			return;
		}
		if (!drawer.hidden) {
			trapFocus(event);
		}
	});

	// Ensure there is no stale background scroll with touch momentum on iOS.
	document.addEventListener('touchmove', (event) => {
		if (!drawer.hidden && event.target === drawer) event.preventDefault();
	}, { passive: false });
})();
