(() => {
	const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

	const icon = '<svg class="gl-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7"/></svg>';

	document.querySelectorAll('[data-gl-rail]').forEach((track, index) => {
		if (track.closest('[data-gl-rail-shell]')) return;
		const shell = document.createElement('div');
		shell.className = 'gl-rail-shell';
		shell.dataset.glRailShell = '';
		track.parentNode.insertBefore(shell, track);
		shell.appendChild(track);

		const controls = document.createElement('div');
		controls.className = 'gl-rail-controls';
		const previous = document.createElement('button');
		const next = document.createElement('button');
		previous.type = next.type = 'button';
		previous.className = 'gl-rail-control gl-rail-control--previous';
		next.className = 'gl-rail-control gl-rail-control--next';
		previous.setAttribute('aria-label', track.dataset.previousLabel || 'Show previous items');
		next.setAttribute('aria-label', track.dataset.nextLabel || 'Show next items');
		previous.innerHTML = next.innerHTML = icon;
		controls.append(previous, next);
		shell.insertBefore(controls, track);

		if (!track.id) track.id = `gl-rail-${index + 1}`;
		previous.setAttribute('aria-controls', track.id);
		next.setAttribute('aria-controls', track.id);
		if (!track.hasAttribute('tabindex')) track.tabIndex = 0;

		let frame = 0;
		const update = () => {
			frame = 0;
			const overflow = track.scrollWidth - track.clientWidth > 4;
			const max = Math.max(0, track.scrollWidth - track.clientWidth);
			shell.classList.toggle('has-overflow', overflow);
			previous.hidden = next.hidden = !overflow;
			previous.disabled = !overflow || track.scrollLeft <= 3;
			next.disabled = !overflow || track.scrollLeft >= max - 3;
		};
		const scheduleUpdate = () => {
			if (!frame) frame = window.requestAnimationFrame(update);
		};
		const distance = () => {
			const selector = track.dataset.glRailItem || ':scope > *';
			const item = track.querySelector(selector);
			if (!item) return Math.max(240, track.clientWidth * 0.8);
			const style = window.getComputedStyle(track);
			return item.getBoundingClientRect().width + (parseFloat(style.columnGap || style.gap) || 0);
		};
		const move = (direction) => track.scrollBy({ left: direction * distance(), behavior: reduceMotion.matches ? 'auto' : 'smooth' });
		previous.addEventListener('click', () => move(-1));
		next.addEventListener('click', () => move(1));
		track.addEventListener('scroll', scheduleUpdate, { passive: true });
		track.addEventListener('keydown', (event) => {
			if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
			event.preventDefault();
			move(event.key === 'ArrowLeft' ? -1 : 1);
		});
		if ('ResizeObserver' in window) {
			const observer = new ResizeObserver(scheduleUpdate);
			observer.observe(track);
			Array.from(track.children).forEach((item) => observer.observe(item));
		} else {
			window.addEventListener('resize', scheduleUpdate, { passive: true });
		}
		track.querySelectorAll('img').forEach((image) => {
			if (!image.complete) image.addEventListener('load', scheduleUpdate, { once: true });
		});
		if (document.fonts && document.fonts.ready) document.fonts.ready.then(scheduleUpdate);
		window.addEventListener('load', scheduleUpdate, { once: true });
		update();
		window.setTimeout(scheduleUpdate, 250);
	});
})();
