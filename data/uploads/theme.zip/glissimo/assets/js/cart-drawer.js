(() => {
	'use strict';

	const config = window.GlissimoCart || {};
	let returnFocus = null;
	let busy = false;

	const root = () => document.querySelector('.gl-cart-drawer-root');
	const drawer = () => root()?.querySelector('[data-gl-cart-drawer]');
	const focusables = (panel) => Array.from(panel.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])')).filter((node) => !node.hidden);

	function setMessage(message) {
		const live = drawer()?.querySelector('[data-gl-cart-live]');
		if (live) live.textContent = message || '';
	}

	function openCart(trigger) {
		const cart = drawer();
		if (!cart) return;
		returnFocus = trigger || document.activeElement;
		cart.hidden = false;
		document.documentElement.classList.add('gl-cart-open');
		const panel = cart.querySelector('[role="dialog"]');
		window.requestAnimationFrame(() => panel?.focus());
	}

	function closeCart() {
		const cart = drawer();
		if (!cart || cart.hidden) return;
		cart.hidden = true;
		document.documentElement.classList.remove('gl-cart-open');
		if (returnFocus instanceof HTMLElement && document.contains(returnFocus)) returnFocus.focus();
	}

	async function mutate(action, values = {}) {
		if (busy) return null;
		busy = true;
		document.documentElement.classList.add('gl-cart-busy');
		const body = new URLSearchParams({ action, nonce: config.nonce || '', ...values });
		try {
			const response = await fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body });
			const payload = await response.json();
			if (!payload.success) throw new Error(payload.data?.message || config.errorMessage || 'The cart could not be updated.');
			const wasOpen = !drawer()?.hidden;
			if (payload.data?.html && root()) root().innerHTML = payload.data.html;
			document.querySelectorAll('.gl-cart-count').forEach((count) => { count.textContent = String(payload.data?.count ?? 0); });
			if (wasOpen) openCart(returnFocus);
			setMessage(payload.data?.message || '');
			const events = Array.isArray(payload.data?.events) ? payload.data.events : (payload.data?.event?.event ? [payload.data.event] : []);
			if (window.glissimoTrack) events.forEach(window.glissimoTrack);
			return payload.data;
		} catch (error) {
			setMessage(error instanceof Error ? error.message : String(error));
			throw error;
		} finally {
			busy = false;
			document.documentElement.classList.remove('gl-cart-busy');
		}
	}

	async function refreshAndOpen(trigger) {
		try {
			await mutate('glissimo_cart_state');
			openCart(trigger);
		} catch (error) {
			console.error(error);
		}
	}

	document.addEventListener('click', async (event) => {
		const cartTrigger = event.target.closest('[data-gl-cart-open]');
		if (cartTrigger) {
			event.preventDefault();
			refreshAndOpen(cartTrigger);
			return;
		}
		if (event.target.closest('[data-gl-cart-close]')) {
			event.preventDefault();
			closeCart();
			return;
		}
		const quantity = event.target.closest('[data-gl-cart-quantity]');
		if (quantity) {
			try { await mutate('glissimo_cart_update', { cart_item_key: quantity.dataset.cartItemKey, quantity: quantity.dataset.quantity }); } catch (error) { console.error(error); }
			return;
		}
		const remove = event.target.closest('[data-gl-cart-remove]');
		if (remove) {
			try { await mutate('glissimo_cart_remove', { cart_item_key: remove.dataset.cartItemKey }); } catch (error) { console.error(error); }
			return;
		}
		const add = event.target.closest('[data-gl-cart-add]');
		if (add) {
			try { await mutate('glissimo_cart_add', { product_id: add.dataset.productId, quantity: add.dataset.quantity || 1 }); if (window.glissimoTrack) window.glissimoTrack({ event: 'cart_recommendation_acceptance', event_id: `recommendation_${Date.now()}`, product_id: add.dataset.productId }); } catch (error) { console.error(error); }
			return;
		}
		const bundle = event.target.closest('[data-gl-bundle-add]');
		if (bundle) {
			event.preventDefault();
			try { await mutate('glissimo_bundle_add', { offer_id: bundle.dataset.offerId }); openCart(bundle); } catch (error) { console.error(error); }
			return;
		}
	});

	document.addEventListener('submit', async (event) => {
		const form = event.target.closest('form.cart');
		if (!form || form.closest('[data-gl-bundle-offer]')) return;
		event.preventDefault();
		if (!form.reportValidity()) return;
		const productId = form.querySelector('[name="add-to-cart"]')?.value || form.querySelector('[name="product_id"]')?.value;
		const variationId = form.querySelector('[name="variation_id"]')?.value || 0;
		if (!productId || (form.classList.contains('variations_form') && !Number(variationId))) {
			setMessage(config.chooseOptionsMessage || 'Choose product options first.');
			return;
		}
		try {
			await mutate('glissimo_cart_add', { product_id: productId, variation_id: variationId, quantity: form.querySelector('[name="quantity"]')?.value || 1 });
			openCart(form.querySelector('[type="submit"]'));
		} catch (error) { console.error(error); }
	});

	document.addEventListener('keydown', (event) => {
		const cart = drawer();
		if (!cart || cart.hidden) return;
		if (event.key === 'Escape') {
			event.preventDefault();
			closeCart();
			return;
		}
		if (event.key !== 'Tab') return;
		const nodes = focusables(cart);
		if (!nodes.length) return;
		const first = nodes[0];
		const last = nodes[nodes.length - 1];
		if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
		else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
	});

	if (window.jQuery) {
		window.jQuery(document.body).on('added_to_cart', async (_event, fragments, _cartHash, button) => {
			if (fragments?.['div.gl-cart-drawer-root']) {
				const replacement = document.createElement('div');
				replacement.innerHTML = fragments['div.gl-cart-drawer-root'];
				root()?.replaceWith(replacement.firstElementChild);
			}
			const productId = Number(button?.data?.('product_id') || button?.attr?.('data-product_id') || 0);
			const quantity = Number(button?.data?.('quantity') || button?.attr?.('data-quantity') || 1);
			if (productId) {
				try { await mutate('glissimo_cart_state', { product_id: productId, quantity }); } catch (error) { console.error(error); }
			}
			openCart(button?.get?.(0) || document.activeElement);
		});
	}
})();
