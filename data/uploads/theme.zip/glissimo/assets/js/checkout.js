(() => {
	'use strict';
	const config = window.GlissimoCheckout || {};
	document.addEventListener('change', async (event) => {
		const input = event.target.closest('[data-gl-order-bump-toggle]');
		if (!input) return;
		const status = document.querySelector('[data-gl-order-bump-status]');
		input.disabled = true;
		try {
			const body = new URLSearchParams({ action: 'glissimo_order_bump_toggle', nonce: config.nonce || '', enabled: input.checked ? '1' : '' });
			const response = await fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body });
			const payload = await response.json();
			if (!payload.success) throw new Error(payload.data?.message || 'The order addition could not be updated.');
			if (status) status.textContent = payload.data?.message || '';
			if (payload.data?.event?.event && window.glissimoTrack) window.glissimoTrack(payload.data.event);
			if (window.jQuery) window.jQuery(document.body).trigger('update_checkout');
		} catch (error) {
			input.checked = !input.checked;
			if (status) status.textContent = error instanceof Error ? error.message : String(error);
		} finally {
			input.disabled = false;
		}
	});
})();
