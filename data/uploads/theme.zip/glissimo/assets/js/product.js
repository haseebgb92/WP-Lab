(() => {
	const toArray = (list) => Array.from(list || []);
	const root = document.querySelector('.gl-pdp');
	if (!root) return;
	const productData = window.GlissimoProduct || {};

	const main = root.querySelector('[data-gl-pdp-media-main]');
	const thumbs = toArray(root.querySelectorAll('[data-gl-pdp-thumb]'));
	const media = {};
	const track = root.querySelector('[data-gl-pdp-media-track]');
	let activeIndex = 0;

	const setActiveThumb = (btn) => {
		thumbs.forEach((thumb) => {
			thumb.classList.remove('is-active');
			thumb.setAttribute('aria-pressed', 'false');
		});
		btn.classList.add('is-active');
		btn.setAttribute('aria-pressed', 'true');
		activeIndex = Math.max(0, thumbs.indexOf(btn));
		btn.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
	};

	const appendZoom = () => {
		if (!main?.querySelector('img')) return;
		const button = document.createElement('button');
		button.type = 'button';
		button.className = 'gl-pdp__zoom';
		button.dataset.glPdpZoom = '';
		button.setAttribute('aria-label', 'Toggle product image zoom');
		button.setAttribute('aria-pressed', 'false');
		button.textContent = '+';
		main.appendChild(button);
	};

	const renderImage = (url, alt) => {
		main.innerHTML = '';
		const image = document.createElement('img');
		image.src = url;
		image.alt = alt;
		image.loading = 'eager';
		image.fetchPriority = 'high';
		main.appendChild(image);
		appendZoom();
	};

	const renderVideo = (url, alt) => {
		main.innerHTML = '';
		const video = document.createElement('video');
		video.setAttribute('controls', 'controls');
		video.setAttribute('preload', 'metadata');
		video.setAttribute('playsinline', '');
		video.setAttribute('aria-label', alt || 'Product video');
		const src = document.createElement('source');
		src.src = url;
		src.type = 'video/mp4';
		video.appendChild(src);
		main.appendChild(video);
	};

	const cacheSources = () => {
		thumbs.forEach((thumb) => {
			const id = thumb.dataset.mediaId;
			const type = thumb.dataset.mediaType || 'image';
			const url = thumb.dataset.mediaUrl || '';
			media[id] = media[id] || { type, url };
		});
	};

	const activateMedia = (thumb) => {
		if (!thumb) return;
		const url = thumb.dataset.mediaUrl || '';
		const type = thumb.dataset.mediaType || 'image';
		const alt = thumb.getAttribute('aria-label') || '';
		if (type === 'video' && url) {
			renderVideo(url, alt);
		} else if (url) {
			renderImage(url, alt);
		}
		setActiveThumb(thumb);
	};

	const activateByIndex = (index) => {
		if (!thumbs.length) return;
		const normalized = Math.max(0, Math.min(index, thumbs.length - 1));
		activateMedia(thumbs[normalized]);
	};

	cacheSources();
	thumbs.forEach((thumb) => {
		thumb.addEventListener('click', () => activateMedia(thumb));
		thumb.addEventListener('keydown', (event) => {
			if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
				const next = thumbs[Math.min(thumbs.indexOf(thumb) + 1, thumbs.length - 1)];
				next?.focus();
				if (next) activateMedia(next);
			}
			if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
				const prev = thumbs[Math.max(thumbs.indexOf(thumb) - 1, 0)];
				prev?.focus();
				if (prev) activateMedia(prev);
			}
		});
	});

	if (main && thumbs.length > 1) {
		let swipeStartX = 0;
		let swipeStartY = 0;
		main.addEventListener('pointerdown', (event) => {
			if (event.pointerType === 'mouse') return;
			swipeStartX = event.clientX;
			swipeStartY = event.clientY;
		});
		main.addEventListener('pointerup', (event) => {
			if (event.pointerType === 'mouse' || !swipeStartX) return;
			const deltaX = event.clientX - swipeStartX;
			const deltaY = event.clientY - swipeStartY;
			swipeStartX = 0;
			if (Math.abs(deltaX) < 45 || Math.abs(deltaX) <= Math.abs(deltaY)) return;
			activateByIndex(activeIndex + (deltaX < 0 ? 1 : -1));
		});
	}

	main?.addEventListener('click', (event) => {
		const zoom = event.target.closest('[data-gl-pdp-zoom]');
		if (!zoom) return;
		const isZoomed = main.classList.toggle('is-zoomed');
		zoom.setAttribute('aria-pressed', String(isZoomed));
		zoom.textContent = isZoomed ? '−' : '+';
	});

	if (track) {
		let startX = 0;
		let scrollLeft = 0;
		let isDown = false;
		track.addEventListener('pointerdown', (event) => {
			isDown = true;
			startX = event.pageX;
			scrollLeft = track.scrollLeft;
		});
		track.addEventListener('pointermove', (event) => {
			if (!isDown) return;
			const x = event.pageX - startX;
			track.scrollLeft = scrollLeft - x;
		});
		track.addEventListener('pointerup', () => {
			isDown = false;
		});
		track.addEventListener('pointerleave', () => {
			isDown = false;
		});
	}

	if (thumbs[0]) setActiveThumb(thumbs[0]);

	const purchaseForm = root.querySelector('form.cart');
	const variationForm = root.querySelector('.variations_form');
	const variationOptions = root.querySelector('[data-gl-variation-options]');
	const variationStatus = root.querySelector('[data-gl-variation-status]');
	const nativeVariationAdd = variationForm?.querySelector('.single_add_to_cart_button');
	const priceNode = root.querySelector('[data-gl-pdp-price]');
	const stockNode = root.querySelector('[data-gl-pdp-stock-status]');
	const stickyBar = root.querySelector('[data-gl-sticky-atc]');
	const stickyButton = root.querySelector('[data-gl-sticky-atc-button]');
	const stickyPrice = root.querySelector('[data-gl-sticky-price]');
	const stickySelection = root.querySelector('[data-gl-sticky-selection]');
	const initialPrice = priceNode?.innerHTML || '';
	const initialStock = stockNode?.textContent?.trim() || '';

	const selectedVariationLabels = () => toArray(variationForm?.querySelectorAll('.variations select'))
		.map((select) => select.selectedOptions?.[0]?.textContent?.trim() || '')
		.filter((label) => label && !/^choose/i.test(label));

	const syncVariationOptionState = () => {
		if (!variationForm || !variationOptions) return;
		toArray(variationForm.querySelectorAll('.variations select')).forEach((select) => {
			const group = variationOptions.querySelector(`[data-gl-variation-group="${CSS.escape(select.name)}"]`);
			if (!group) return;
			toArray(group.querySelectorAll('[data-gl-variation-option]')).forEach((button) => {
				const option = toArray(select.options).find((item) => item.value === button.dataset.value);
				const selected = select.value === button.dataset.value;
				button.classList.toggle('is-selected', selected);
				button.setAttribute('aria-pressed', String(selected));
				button.disabled = Boolean(option?.disabled);
			});
		});
		const labels = selectedVariationLabels();
		if (stickySelection) stickySelection.textContent = labels.join(' · ');
	};

	const enhanceVariationSelectors = () => {
		if (!variationForm || !variationOptions) return;
		const selects = toArray(variationForm.querySelectorAll('.variations select'));
		if (!selects.length) return;
		variationOptions.innerHTML = '';

		selects.forEach((select) => {
			const nativeLabel = variationForm.querySelector(`label[for="${CSS.escape(select.id)}"]`);
			const group = document.createElement('div');
			group.className = 'gl-variation-options__group';
			group.dataset.glVariationGroup = select.name;
			const heading = document.createElement('span');
			heading.className = 'gl-variation-options__label';
			heading.textContent = nativeLabel?.textContent?.trim() || select.dataset.attribute_name || productData.optionLabel || 'Option';
			const choices = document.createElement('div');
			choices.className = 'gl-variation-options__choices';
			choices.setAttribute('role', 'group');
			choices.setAttribute('aria-label', heading.textContent);

			toArray(select.options).filter((option) => option.value).forEach((option) => {
				const button = document.createElement('button');
				button.type = 'button';
				button.className = 'gl-variation-option';
				button.dataset.glVariationOption = '';
				button.dataset.value = option.value;
				button.textContent = option.textContent.trim();
				button.setAttribute('aria-pressed', 'false');
				button.addEventListener('click', () => {
					select.value = button.dataset.value;
					select.dispatchEvent(new Event('change', { bubbles: true }));
					syncVariationOptionState();
				});
				choices.appendChild(button);
			});

			group.append(heading, choices);
			variationOptions.appendChild(group);
			select.addEventListener('change', syncVariationOptionState);
		});

		const clear = document.createElement('button');
		clear.type = 'button';
		clear.className = 'gl-variation-options__clear';
		clear.textContent = variationForm.querySelector('.reset_variations')?.textContent?.trim() || productData.clearSelection || 'Clear selection';
		clear.addEventListener('click', () => {
			selects.forEach((select) => {
				select.value = '';
				select.dispatchEvent(new Event('change', { bubbles: true }));
			});
			syncVariationOptionState();
		});
		variationOptions.appendChild(clear);
		root.classList.add('is-variation-enhanced');
		syncVariationOptionState();
	};

	const setVariationState = (variation) => {
		const purchasable = Boolean(variation?.is_purchasable && variation?.is_in_stock);
		if (nativeVariationAdd) {
			nativeVariationAdd.disabled = !purchasable;
			nativeVariationAdd.setAttribute('aria-disabled', String(!purchasable));
		}
		if (variation?.price_html && priceNode) priceNode.innerHTML = variation.price_html;
		if (variation?.price_html && stickyPrice) stickyPrice.innerHTML = variation.price_html;
		if (stockNode) {
			const availability = document.createElement('div');
			availability.innerHTML = variation?.availability_html || '';
			stockNode.textContent = availability.textContent.trim() || (purchasable ? (productData.available || 'Available') : (productData.unavailable || 'Currently unavailable'));
			stockNode.classList.toggle('is-available', purchasable);
			stockNode.classList.toggle('is-unavailable', !purchasable);
		}
		if (variationStatus) variationStatus.textContent = purchasable ? (productData.variationReady || 'Your selection is ready to add.') : (productData.unavailable || 'Currently unavailable');
		if (stickyButton) {
			stickyButton.disabled = !purchasable;
			stickyButton.textContent = purchasable ? (productData.addToCart || 'Add to cart') : (productData.unavailable || 'Currently unavailable');
		}
		if (variation?.image?.full_src) {
			renderImage(variation.image.full_src, variation.image.alt || variation.image.title || 'Selected product variation');
			thumbs.forEach((thumb) => thumb.classList.remove('is-active'));
		}
		syncVariationOptionState();
	};

	const resetVariationState = () => {
		if (nativeVariationAdd) {
			nativeVariationAdd.disabled = true;
			nativeVariationAdd.setAttribute('aria-disabled', 'true');
		}
		if (priceNode) priceNode.innerHTML = initialPrice;
		if (stickyPrice) stickyPrice.innerHTML = initialPrice;
		if (stockNode) {
			stockNode.textContent = initialStock;
			stockNode.classList.remove('is-unavailable', 'is-available');
		}
		if (variationStatus) variationStatus.textContent = productData.variationPrompt || 'Choose the options that suit your kitchen.';
		if (stickyButton) {
			stickyButton.disabled = true;
			stickyButton.textContent = productData.chooseOptions || 'Choose options';
		}
		if (thumbs[0]) activateMedia(thumbs[0]);
		syncVariationOptionState();
	};

	enhanceVariationSelectors();
	if (variationForm && window.jQuery) {
		window.jQuery(variationForm)
			.on('found_variation', (_event, variation) => setVariationState(variation))
			.on('reset_data hide_variation', resetVariationState)
			.on('woocommerce_update_variation_values', syncVariationOptionState);
		resetVariationState();
	}

	const checkboxNodes = toArray(root.querySelectorAll('[data-gl-fbt-item]'));
	const addButton = root.querySelector('[data-gl-fbt-add]');
	const selectedNode = root.querySelector('[data-gl-fbt-selected]');
	const selectedCountNode = root.querySelector('[data-gl-fbt-selected-count]');
	const regularTotalNode = root.querySelector('[data-gl-fbt-regular]');
	const offerTotalNode = root.querySelector('[data-gl-fbt-offer]');
	const savingsNode = root.querySelector('[data-gl-fbt-savings]');
	const savingsRow = root.querySelector('[data-gl-fbt-savings-row]');
	const regularRow = root.querySelector('[data-gl-fbt-regular-row]');
	const totalLabel = root.querySelector('[data-gl-fbt-total-label]');
	const fbtData = productData;
	const singularLabel = fbtData.singular || 'product';
	const pluralLabel = fbtData.plural || 'products';
	const fallbackLabel = addButton?.dataset.label || addButton?.textContent || '';

	const currencyFormat = new Intl.NumberFormat(document.documentElement.lang || undefined, {
		style: 'currency',
		currency: fbtData.currencyCode || 'EUR',
		minimumFractionDigits: Number(fbtData.priceDecimals ?? 2),
		maximumFractionDigits: Number(fbtData.priceDecimals ?? 2),
	});

	const updateFbtSummary = () => {
		let selected = 0;
		let regular = 0;
		let offer = 0;
		let saving = 0;
		checkboxNodes.forEach((checkbox) => {
			if (!checkbox.checked) return;
			const offerPrice = Number(checkbox.dataset.fbtPrice || 0);
			const regularPrice = Number(checkbox.dataset.fbtRegularPrice || 0) || offerPrice;
			selected += 1;
			offer += offerPrice;
			regular += regularPrice;
			if (regularPrice > offerPrice) {
				saving += (regularPrice - offerPrice);
			}
		});

		if (selectedNode) {
			selectedNode.textContent = selected ? `${selected} ${selected === 1 ? singularLabel : pluralLabel}` : '';
		}
		if (selectedCountNode) {
			selectedCountNode.textContent = selected ? currencyFormat.format(offer) : currencyFormat.format(0);
		}
		if (regularTotalNode) {
			regularTotalNode.textContent = selected ? currencyFormat.format(regular) : currencyFormat.format(0);
		}
		if (offerTotalNode) {
			offerTotalNode.textContent = selected ? currencyFormat.format(offer) : currencyFormat.format(0);
		}
		if (savingsNode) {
			savingsNode.textContent = selected ? currencyFormat.format(saving) : currencyFormat.format(0);
		}
		const hasSaving = selected > 0 && saving > 0.005;
		if (savingsRow) savingsRow.hidden = !hasSaving;
		if (regularRow) regularRow.hidden = !hasSaving;
		if (totalLabel) totalLabel.textContent = hasSaving ? (fbtData.offerTotal || 'Offer total') : (fbtData.selectedTotal || 'Selected total');
		checkboxNodes.forEach((checkbox) => checkbox.closest('.gl-fbt-product')?.classList.toggle('is-selected', checkbox.checked));
		if (addButton) addButton.disabled = selected < 1;
	};

	checkboxNodes.forEach((input) => input.addEventListener('change', updateFbtSummary));
	updateFbtSummary();

	if (addButton && fbtData.ajaxUrl && fbtData.nonce) {
		addButton.addEventListener('click', async () => {
			const ids = checkboxNodes.filter((item) => item.checked).map((item) => Number(item.dataset.fbtProductId || 0)).filter(Boolean);
			if (!ids.length) {
				addButton.textContent = fallbackLabel;
				return;
			}
			addButton.disabled = true;
			addButton.dataset.loading = '1';
			try {
				const response = await fetch(fbtData.ajaxUrl, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
					},
					body: new URLSearchParams({
						action: fbtData.action || 'glissimo_fbt_add_to_cart',
						nonce: fbtData.nonce,
						product_ids: JSON.stringify(ids),
						anchor_product_id: root.querySelector('[data-gl-fbt]')?.dataset.anchorProductId || '',
					}),
				});
				const result = await response.json();
				if (result && result.success) {
					const trackingEvents = Array.isArray(result.data?.events) ? result.data.events : (result.data?.event ? [result.data.event] : []);
					if (window.glissimoTrack) trackingEvents.forEach(window.glissimoTrack);
					addButton.textContent = fallbackLabel || addButton.textContent;
					addButton.disabled = false;
					addButton.dataset.loading = '0';
					document.querySelector('[data-gl-cart-open]')?.click();
					return;
				}
				throw new Error(result?.data?.message || 'Unable to add to cart');
			} catch (error) {
				addButton.textContent = error.message || 'Action failed';
				setTimeout(() => {
					addButton.textContent = fallbackLabel || addButton.textContent;
				}, 1200);
				addButton.disabled = false;
				addButton.dataset.loading = '0';
			}
		});
	}

	const bundleButton = root.querySelector('[data-gl-bundle-add]');
	const purchaseTarget = purchaseForm || bundleButton;
	if (stickyBar && purchaseTarget) {
		let stickyFrame = 0;
		const updateSticky = () => {
			stickyFrame = 0;
			stickyBar.hidden = purchaseTarget.getBoundingClientRect().bottom >= 0;
		};
		const scheduleSticky = () => {
			if (!stickyFrame) stickyFrame = window.requestAnimationFrame(updateSticky);
		};
		window.addEventListener('scroll', scheduleSticky, { passive: true });
		window.addEventListener('resize', scheduleSticky, { passive: true });
		updateSticky();
	}
	stickyButton?.addEventListener('click', () => {
		if (bundleButton) {
			bundleButton.click();
			return;
		}
		const nativeButton = purchaseForm?.querySelector('.single_add_to_cart_button:not(.disabled)');
		if (nativeButton) {
			nativeButton.click();
			return;
		}
		purchaseForm?.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' });
		purchaseForm?.querySelector('select, input, button')?.focus({ preventScroll: true });
	});
})();
