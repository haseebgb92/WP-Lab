(() => {
	'use strict';
	const config = window.GlissimoPrivacy || {};
	const key = 'glissimo_consent_v1';
	const banner = document.querySelector('[data-gl-consent-banner]');
	const preferences = banner?.querySelector('[data-gl-consent-preferences]');
	let returnFocus = null;
	const necessary = { necessary: true, analytics: false, marketing: false, preferences: false };
	window.dataLayer = window.dataLayer || [];
	window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
	window.gtag('consent', 'default', {
		analytics_storage: 'denied', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied', wait_for_update: 500
	});
	const read = () => {
		try { return { ...necessary, ...JSON.parse(localStorage.getItem(key) || 'null') }; } catch (_error) { return { ...necessary }; }
	};
	const hasChoice = () => localStorage.getItem(key) !== null;
	const complianzState = () => ({
		necessary: true,
		analytics: typeof window.cmplz_has_consent === 'function' && Boolean(window.cmplz_has_consent('statistics')),
		marketing: typeof window.cmplz_has_consent === 'function' && Boolean(window.cmplz_has_consent('marketing')),
		preferences: typeof window.cmplz_has_consent === 'function' && Boolean(window.cmplz_has_consent('preferences'))
	});
	const loadScript = (src, id) => {
		if (!src || document.getElementById(id)) return;
		const script = document.createElement('script'); script.id = id; script.async = true; script.src = src; document.head.append(script);
	};
	function loadVendors(state) {
		if (config.dryRun || !config.enabled) return;
		if (state.analytics && config.gtm) {
			window.dataLayer = window.dataLayer || []; window.dataLayer.push({ 'gtm.start': Date.now(), event: 'gtm.js' });
			loadScript(`https://www.googletagmanager.com/gtm.js?id=${encodeURIComponent(config.gtm)}`, 'gl-vendor-gtm');
		}
		if (state.analytics && !config.gtm && config.ga4) {
			window.dataLayer = window.dataLayer || []; window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
			window.gtag('js', new Date()); window.gtag('config', config.ga4, { anonymize_ip: true });
			loadScript(`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(config.ga4)}`, 'gl-vendor-ga4');
		}
		if (state.analytics && config.clarity) {
			window.clarity = window.clarity || function () { (window.clarity.q = window.clarity.q || []).push(arguments); };
			loadScript(`https://www.clarity.ms/tag/${encodeURIComponent(config.clarity)}`, 'gl-vendor-clarity');
		}
		if (state.marketing && config.meta) {
			window.fbq = window.fbq || function () { (window.fbq.queue = window.fbq.queue || []).push(arguments); }; window.fbq.loaded = true; window.fbq.version = '2.0';
			window.fbq('init', config.meta); window.fbq('track', 'PageView');
			loadScript('https://connect.facebook.net/en_US/fbevents.js', 'gl-vendor-meta');
		}
	}
	function announce(state) {
		const previous = window.GlissimoConsent;
		const vendorWasLoaded = Boolean(document.querySelector('[id^="gl-vendor-"]'));
		window.GlissimoConsent = state;
		if (window.gtag) window.gtag('consent', 'update', {
			analytics_storage: state.analytics ? 'granted' : 'denied',
			ad_storage: state.marketing ? 'granted' : 'denied',
			ad_user_data: state.marketing ? 'granted' : 'denied',
			ad_personalization: state.marketing ? 'granted' : 'denied'
		});
		if (window.fbq) window.fbq('consent', state.marketing ? 'grant' : 'revoke');
		loadVendors(state);
		window.dispatchEvent(new CustomEvent('glissimo:consent', { detail: state }));
		if (previous && vendorWasLoaded && ((previous.analytics && !state.analytics) || (previous.marketing && !state.marketing))) window.location.reload();
	}
	function save(state) {
		const value = { ...necessary, ...state, necessary: true, updatedAt: new Date().toISOString() };
		localStorage.setItem(key, JSON.stringify(value));
		document.cookie = `glissimo_consent=1;path=/;max-age=31536000;SameSite=Lax`;
		banner.hidden = true; preferences.hidden = true; announce(value);
		if (returnFocus instanceof HTMLElement && document.contains(returnFocus)) returnFocus.focus();
	}
	function open(customize = false) {
		if (!banner) return;
		returnFocus = document.activeElement;
		banner.hidden = false;
		preferences.hidden = !customize;
		if (customize) {
			const state = read();
			for (const name of ['analytics', 'marketing', 'preferences']) preferences.elements[name].checked = Boolean(state[name]);
		}
		banner.querySelector('button:not([hidden])')?.focus();
	}
	banner?.querySelector('[data-gl-consent-accept]')?.addEventListener('click', () => save({ analytics: true, marketing: true, preferences: true }));
	banner?.querySelector('[data-gl-consent-reject]')?.addEventListener('click', () => save(necessary));
	banner?.querySelector('[data-gl-consent-customize]')?.addEventListener('click', () => open(true));
	preferences?.addEventListener('submit', (event) => { event.preventDefault(); save({ analytics: preferences.elements.analytics.checked, marketing: preferences.elements.marketing.checked, preferences: preferences.elements.preferences.checked }); });
	document.querySelector('[data-gl-consent-reopen]')?.addEventListener('click', () => open(true));
	const syncComplianz = () => {
		if (config.provider !== 'complianz' || typeof window.cmplz_has_consent !== 'function') return;
		if (banner) banner.hidden = true;
		announce(complianzState());
	};
	document.addEventListener('cmplz_event', syncComplianz);
	document.addEventListener('cmplz_status_change', syncComplianz);
	banner?.addEventListener('keydown', (event) => {
		if (event.key === 'Escape' && hasChoice()) { event.preventDefault(); banner.hidden = true; returnFocus?.focus(); }
		if (event.key !== 'Tab') return;
		const nodes = [...banner.querySelectorAll('a[href],button:not([disabled]),input:not([disabled])')].filter((node) => !node.closest('[hidden]'));
		if (!nodes.length) return;
		if (event.shiftKey && document.activeElement === nodes[0]) { event.preventDefault(); nodes.at(-1).focus(); }
		if (!event.shiftKey && document.activeElement === nodes.at(-1)) { event.preventDefault(); nodes[0].focus(); }
	});
	if (config.provider === 'complianz' && typeof window.cmplz_has_consent === 'function') syncComplianz();
	else if (config.localBridge) {
		const current = read(); announce(current);
		if (banner && !hasChoice()) open(false);
	} else announce(necessary);
})();
