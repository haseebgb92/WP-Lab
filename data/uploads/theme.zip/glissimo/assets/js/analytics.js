(() => {
	'use strict';
	const config = window.GlissimoAnalytics || {};
	window.glissimoEventLog = window.glissimoEventLog || [];
	window.dataLayer = window.dataLayer || [];
	document.documentElement.dataset.glAnalyticsReady = 'true';
	const consent = () => window.GlissimoConsent || { necessary: true, analytics: false, marketing: false };
	const pending = new Map();
	const logged = new Set();
	const eventKey = (event) => event.event_id || `${event.event}_${JSON.stringify(event.ecommerce || event)}`;
	const storage = (event) => event.event === 'purchase' ? localStorage : sessionStorage;
	const wasSent = (event, channel) => {
		try { return Boolean(event.event_id && storage(event).getItem(`glissimo_event_${channel}_${event.event_id}`)); } catch (_error) { return false; }
	};
	const markSent = (event, channel) => {
		if (!event.event_id) return;
		try { storage(event).setItem(`glissimo_event_${channel}_${event.event_id}`, '1'); } catch (_error) {}
	};
	function deliverVendors(safe) {
		if (config.dryRun || !config.enabled) return;
		const state = consent();
		if (state.analytics && !wasSent(safe, 'analytics')) {
			if (config.gtm) window.dataLayer.push(safe);
			else if (config.ga4 && window.gtag) window.gtag('event', safe.event, safe.ecommerce || safe);
			markSent(safe, 'analytics');
		}
		if (state.marketing && config.meta && window.fbq && !wasSent(safe, 'marketing')) {
			const names = { view_item: 'ViewContent', view_item_list: 'ViewCategory', add_to_cart: 'AddToCart', view_cart: 'ViewCart', begin_checkout: 'InitiateCheckout', purchase: 'Purchase' };
			if (names[safe.event]) window.fbq('track', names[safe.event], safe.ecommerce || {}, { eventID: safe.event_id });
			markSent(safe, 'marketing');
		}
		const analyticsDone = !(config.gtm || config.ga4) || wasSent(safe, 'analytics');
		const marketingDone = !config.meta || wasSent(safe, 'marketing');
		if (analyticsDone && marketingDone) pending.delete(eventKey(safe));
	}
	function deliver(event) {
		if (!event?.event) return;
		const safe = JSON.parse(JSON.stringify(event));
		const key = eventKey(safe);
		if (!logged.has(key)) {
			logged.add(key);
			window.glissimoEventLog.push(safe);
			document.documentElement.dataset.glEventCount = String(window.glissimoEventLog.length);
			document.documentElement.dataset.glLastEvent = safe.event;
			document.dispatchEvent(new CustomEvent('glissimo:event', { detail: safe }));
		}
		pending.set(key, safe);
		deliverVendors(safe);
	}
	window.glissimoTrack = deliver;
	(config.initialEvents || []).forEach(deliver);
	if (config.dryRun && 'PerformanceObserver' in window) {
		let cls = 0;
		try { new PerformanceObserver((list) => { const entry = list.getEntries().at(-1); if (entry) document.documentElement.dataset.glLcp = String(Math.round(entry.startTime)); }).observe({ type: 'largest-contentful-paint', buffered: true }); } catch (_error) {}
		try { new PerformanceObserver((list) => { list.getEntries().forEach((entry) => { if (!entry.hadRecentInput) cls += entry.value; }); document.documentElement.dataset.glCls = cls.toFixed(4); }).observe({ type: 'layout-shift', buffered: true }); } catch (_error) {}
		try { new PerformanceObserver((list) => { const duration = Math.max(...list.getEntries().map((entry) => entry.duration), 0); if (duration) document.documentElement.dataset.glInp = String(Math.round(duration)); }).observe({ type: 'event', buffered: true, durationThreshold: 40 }); } catch (_error) {}
	}
	document.addEventListener('glissimo:track', (event) => deliver(event.detail));
	window.addEventListener('glissimo:consent', () => pending.forEach(deliverVendors));
	document.addEventListener('submit', (event) => {
		if (event.target.matches('form[role="search"]')) deliver({ event: 'search', event_id: `search_${Date.now()}`, search_term: event.target.querySelector('[name="s"]')?.value || '' });
	});
	document.addEventListener('change', (event) => {
		if (event.target.matches('input[name="payment_method"]')) deliver({ event: 'add_payment_info', event_id: `payment_${Date.now()}`, payment_type: event.target.value });
	});
})();
