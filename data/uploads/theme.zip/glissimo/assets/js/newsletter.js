(() => {
	'use strict';
	const config = window.GlissimoNewsletter || {};
	document.querySelectorAll('[data-gl-newsletter-form]').forEach((form) => form.addEventListener('submit', async (event) => {
		event.preventDefault();
		if (!form.reportValidity()) return;
		const status = form.querySelector('[data-gl-newsletter-status]');
		const button = form.querySelector('button[type="submit"]');
		button.disabled = true; status.textContent = '';
		try {
			const body = new FormData(form); body.set('action', 'glissimo_newsletter_subscribe'); body.set('nonce', config.nonce || '');
			const response = await fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body });
			const payload = await response.json();
			if (!payload.success) throw new Error(payload.data?.message || config.errorMessage);
			status.textContent = payload.data.message; form.reset();
			if (payload.data.event && window.glissimoTrack) window.glissimoTrack(payload.data.event);
		} catch (error) { status.textContent = error instanceof Error ? error.message : config.errorMessage; }
		finally { button.disabled = false; }
	}));
})();
