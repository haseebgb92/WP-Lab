(() => {
	'use strict';
	const dialog = document.querySelector('[data-gl-scratch-dialog]');
	const trigger = document.querySelector('[data-gl-scratch-trigger]');
	document.querySelectorAll('.gl-demo__media').forEach((media) => {
		const play = document.createElement('span'); play.className = 'gl-demo__play'; play.setAttribute('aria-hidden', 'true'); play.textContent = '▶'; media.append(play);
		const note = document.createElement('p'); note.className = 'gl-demo__film-note'; note.textContent = 'Product film coming soon'; media.append(note);
	});
	if (!dialog) return;
	if (trigger) trigger.hidden = true;
	const panel = dialog.querySelector('.gl-scratch-dialog__panel');
	const reveal = dialog.querySelector('[data-gl-scratch-reveal]');
	const code = dialog.querySelector('[data-gl-scratch-code]');
	const canvas = dialog.querySelector('[data-gl-scratch-canvas]');
	const seenKey = 'glissimo_scratch_campaign_v2';
	let returnFocus = null;
	let context = null;
	let active = false;
	let revealed = false;
	const track = (event) => window.glissimoTrack?.({ event, event_id: `${event}_${Date.now()}` });
	const showCode = (fallback = false) => {
		if (revealed) return;
		revealed = true;
		code.removeAttribute('aria-hidden');
		canvas.hidden = true;
		reveal.hidden = true;
		track(fallback ? 'scratch_campaign_accessible_reveal' : 'scratch_campaign_reveal');
	};
	const paint = () => {
		const box = canvas.getBoundingClientRect();
		const scale = window.devicePixelRatio || 1;
		canvas.width = Math.max(1, Math.round(box.width * scale));
		canvas.height = Math.max(1, Math.round(box.height * scale));
		context = canvas.getContext('2d');
		context.scale(scale, scale);
		context.fillStyle = '#263027';
		context.fillRect(0, 0, box.width, box.height);
		context.fillStyle = '#d9dfd6';
		context.font = '700 12px sans-serif';
		context.textAlign = 'center';
		context.fillText('Scratch to reveal', box.width / 2, box.height / 2 + 4);
	};
	const scratch = (event) => {
		if (!active || !context || revealed) return;
		const rect = canvas.getBoundingClientRect();
		context.globalCompositeOperation = 'destination-out';
		context.beginPath();
		context.arc(event.clientX - rect.left, event.clientY - rect.top, 24, 0, Math.PI * 2);
		context.fill();
		const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
		let clear = 0;
		for (let index = 3; index < pixels.length; index += 160) if (pixels[index] === 0) clear++;
		if (clear / (pixels.length / 160) > .42) showCode();
	};
	const open = () => {
		returnFocus = document.activeElement;
		dialog.hidden = false;
		revealed = false;
		code.setAttribute('aria-hidden', 'true');
		reveal.hidden = false;
		canvas.hidden = false;
		paint();
		panel.querySelector('[data-gl-scratch-close]')?.focus();
		track('scratch_campaign_open');
	};
	const close = () => {
		dialog.hidden = true;
		active = false;
		try { sessionStorage.setItem(seenKey, '1'); } catch (_error) {}
		if (returnFocus instanceof HTMLElement) returnFocus.focus();
	};
	dialog.querySelectorAll('[data-gl-scratch-close]').forEach((button) => button.addEventListener('click', close));
	reveal.addEventListener('click', () => showCode(true));
	canvas.addEventListener('pointerdown', (event) => { active = true; canvas.setPointerCapture?.(event.pointerId); scratch(event); });
	canvas.addEventListener('pointermove', scratch);
	canvas.addEventListener('pointerup', () => { active = false; });
	document.addEventListener('keydown', (event) => { if (!dialog.hidden && event.key === 'Escape') { event.preventDefault(); close(); } });
	try { if (!sessionStorage.getItem(seenKey)) window.setTimeout(open, 25000); } catch (_error) { window.setTimeout(open, 25000); }
})();
