(() => {
	'use strict';
	const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
	const track = (event, context = {}) => document.dispatchEvent(new CustomEvent('glissimo:track', { detail: { event, event_id: `${event}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, ...context } }));
	const request = async (action, values) => {
		const data = new URLSearchParams({ action, nonce: GlissimoPhase2.nonce });
		Object.entries(values).forEach(([key, value]) => {
			if (value && typeof value === 'object') Object.entries(value).forEach(([child, item]) => data.append(`${key}[${child}]`, item));
			else data.append(key, value);
		});
		const response = await fetch(GlissimoPhase2.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data });
		return response.json();
	};
	const formatMoney = (value) => {
		const decimals = Math.max(0, Number(GlissimoPhase2.priceDecimals ?? 2));
		const fixed = Number(value || 0).toFixed(decimals).split('.');
		const whole = fixed[0].replace(/\B(?=(\d{3})+(?!\d))/g, GlissimoPhase2.thousandSeparator || ',');
		const number = decimals ? `${whole}${GlissimoPhase2.decimalSeparator || '.'}${fixed[1]}` : whole;
		return String(GlissimoPhase2.priceFormat || '%1$s%2$s')
			.replace('%1$s', GlissimoPhase2.currencySymbol || GlissimoPhase2.currency || '')
			.replace('%2$s', number);
	};
	const builder = document.querySelector('[data-gl-builder]');
	if (builder) {
		track('bundle_builder_start');
		const form = builder.querySelector('[data-gl-builder-form]'); const steps = [...form.querySelectorAll('[data-gl-builder-step]')]; let active = 0;
		const show = () => { steps.forEach((step, index) => step.classList.toggle('is-active', index === active)); builder.querySelector('[data-gl-builder-back]').disabled = active === 0; builder.querySelector('[data-gl-builder-next]').hidden = active === steps.length - 1; };
		const summary = () => {
			const selected = [...form.querySelectorAll('input:checked')].filter((input) => input.value);
			builder.querySelector('[data-gl-builder-summary]').innerHTML = selected.length ? selected.map((input) => `<li>${escapeHtml(input.closest('.gl-choice').querySelector('strong').textContent)}<span>${escapeHtml(formatMoney(Number(input.dataset.price || 0)))}</span></li>`).join('') : `<li>${escapeHtml(GlissimoPhase2.labels.chooseProducts)}</li>`;
			const regular = selected.reduce((sum, input) => sum + Number(input.dataset.price || 0), 0); const bundlePrice = regular * (1 - Number(GlissimoPhase2.builderDiscount || 0) / 100);
			builder.querySelector('[data-gl-builder-regular]').textContent = regular ? formatMoney(regular) : '—'; const price = builder.querySelector('[data-gl-builder-price]'); const saving = builder.querySelector('[data-gl-builder-saving]'); if (price) price.textContent = regular ? formatMoney(bundlePrice) : '—'; if (saving) saving.textContent = regular ? formatMoney(regular - bundlePrice) : '—';
		};
		form.addEventListener('change', summary);
		builder.querySelector('[data-gl-builder-next]').addEventListener('click', () => { const required = steps[active].querySelector('input[required]'); if (required && !steps[active].querySelector('input:checked')) { required.reportValidity(); return; } track('bundle_builder_step', { step: active + 1 }); active = Math.min(steps.length - 1, active + 1); show(); });
		builder.querySelector('[data-gl-builder-back]').addEventListener('click', () => { active = Math.max(0, active - 1); show(); });
		builder.querySelector('[data-gl-builder-add]').addEventListener('click', async (event) => { event.preventDefault(); const status = builder.querySelector('[data-gl-form-status]'); const button = builder.querySelector('[data-gl-builder-add]'); button.disabled = true; status.textContent = ''; const selections = {}; new FormData(form).forEach((value, key) => { const match = key.match(/^selections\[([^\]]+)\]$/); if (match) selections[match[1]] = value; }); const payload = await request('glissimo_builder_add', { selections }); button.disabled = false; if (!payload.success) { status.textContent = payload.data?.message || GlissimoPhase2.error; return; } track('bundle_builder_complete', { item_count: Number(payload.data.count || 0) }); window.location.assign(payload.data.cartUrl); });
		show(); summary();
	}
	const quiz = document.querySelector('[data-gl-quiz]');
	if (quiz) {
		track('quiz_start');
		const form = quiz.querySelector('[data-gl-quiz-form]');
		const steps = [...form.querySelectorAll('[data-gl-quiz-step]')];
		const target = quiz.querySelector('[data-gl-quiz-result]');
		const progress = quiz.querySelector('[data-gl-quiz-progress]');
		let active = 0;
		const scrollToSurface = (surface) => requestAnimationFrame(() => {
			const header = document.querySelector('[data-gl-header]');
			const adminBar = document.querySelector('#wpadminbar');
			const offset = (header?.getBoundingClientRect().height || 0) + (adminBar?.getBoundingClientRect().height || 0) + 24;
			window.scrollTo({ top: Math.max(0, surface.getBoundingClientRect().top + window.scrollY - offset), behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
		});
		const draw = () => {
			steps.forEach((step, index) => { step.hidden = index !== active; });
			quiz.querySelector('[data-gl-quiz-back]').disabled = active === 0;
			quiz.querySelector('[data-gl-quiz-next]').hidden = active === steps.length - 1;
			quiz.querySelector('[data-gl-quiz-submit]').hidden = active !== steps.length - 1;
			if (progress) progress.style.width = `${((active + 1) / Math.max(steps.length, 1)) * 100}%`;
		};
		const restart = () => {
			active = 0;
			form.reset();
			form.hidden = false;
			target.hidden = true;
			target.innerHTML = '';
			const email = quiz.querySelector('[data-gl-quiz-email]');
			if (email) email.hidden = true;
			draw();
			steps[0]?.querySelector('input')?.focus({ preventScroll: true });
			scrollToSurface(form);
		};
		quiz.querySelector('[data-gl-quiz-next]').addEventListener('click', () => {
			const input = steps[active].querySelector('input:checked');
			if (!input) { steps[active].querySelector('input').reportValidity(); return; }
			track('quiz_answer', { step: active + 1, answer: input.value });
			active++;
			draw();
			steps[active]?.querySelector('input')?.focus({ preventScroll: true });
		});
		quiz.querySelector('[data-gl-quiz-back]').addEventListener('click', () => { active = Math.max(0, active - 1); draw(); });
		form.addEventListener('submit', async (event) => {
			event.preventDefault();
			const submit = quiz.querySelector('[data-gl-quiz-submit]');
			submit.disabled = true;
			const payload = await request('glissimo_quiz_result', { answers: Object.fromEntries(new FormData(form)) });
			submit.disabled = false;
			target.hidden = false;
			form.hidden = true;
			if (!payload.success || !payload.data.result) {
				target.innerHTML = `<div class="gl-quiz-result__empty"><p class="gl-eyebrow">${escapeHtml(GlissimoPhase2.labels.matchEyebrow)}</p><h2>${escapeHtml(GlissimoPhase2.labels.noMatch)}</h2><p>${escapeHtml(payload.data?.message || GlissimoPhase2.labels.noMatchCopy)}</p><button class="gl-button gl-button--secondary" type="button" data-gl-quiz-restart>${escapeHtml(GlissimoPhase2.labels.retakeFinder)}</button></div>`;
				return;
			}
			const product = payload.data.result;
			track('quiz_complete', { product_id: Number(product.id) });
			target.innerHTML = `<div class="gl-quiz-result__intro"><p class="gl-eyebrow">${escapeHtml(GlissimoPhase2.labels.matchEyebrow)}</p><h2>${escapeHtml(GlissimoPhase2.labels.resultHeading)}</h2></div><div class="gl-quiz-result__card"><div class="gl-quiz-result__media">${product.image ? `<img src="${escapeHtml(product.image)}" alt="">` : ''}<span>${escapeHtml(GlissimoPhase2.labels.basedOnAnswers)}</span></div><div class="gl-quiz-result__content"><h3>${escapeHtml(product.name)}</h3>${product.resultCopy ? `<p class="gl-quiz-result__lead">${escapeHtml(product.resultCopy)}</p>` : ''}<p class="gl-quiz-result__price">${escapeHtml(product.price)}</p>${product.explanation ? `<div class="gl-quiz-result__reason"><strong>${escapeHtml(GlissimoPhase2.labels.whyItFits)}</strong><p>${escapeHtml(product.explanation)}</p></div>` : ''}<div class="gl-quiz-result__actions"><a class="gl-button" href="${escapeHtml(product.url)}">${escapeHtml(product.ctaLabel || GlissimoPhase2.labels.shopMatch)}</a><button class="gl-button gl-button--secondary" type="button" data-gl-quiz-restart>${escapeHtml(GlissimoPhase2.labels.retakeFinder)}</button></div></div></div>`;
			const email = quiz.querySelector('[data-gl-quiz-email]');
			if (email) email.hidden = false;
			scrollToSurface(target);
		});
		target.addEventListener('click', (event) => { if (event.target.closest('[data-gl-quiz-restart]')) restart(); });
		draw();
	}
	document.addEventListener('submit', async (event) => { const form = event.target.closest('[data-gl-stock-form]'); if (!form) return; event.preventDefault(); const status = form.querySelector('[data-gl-form-status]'); const payload = await request('glissimo_back_in_stock', Object.fromEntries(new FormData(form))); status.textContent = payload.data?.message || GlissimoPhase2.error; if (payload.success) { track('back_in_stock_signup', { product_id: Number(form.querySelector('[name="product_id"]')?.value || 0) }); form.reset(); } });
	if (window.jQuery) window.jQuery('.variations_form').on('found_variation', (_event, variation) => { const alert = document.querySelector('[data-gl-stock-alert]'); if (!alert) return; alert.hidden = Boolean(variation?.is_in_stock); const input = alert.querySelector('[name="variation_id"]'); if (input) input.value = variation?.variation_id || ''; }).on('reset_data hide_variation', () => { const alert = document.querySelector('[data-gl-stock-alert]'); if (alert) alert.hidden = true; });
	document.addEventListener('click', (event) => { const link = event.target.closest('[data-gl-landing-conversion]'); if (link) track('landing_page_conversion', { campaign: link.closest('[data-campaign-label]')?.dataset.campaignLabel || '' }); const recommendation = event.target.closest('[data-gl-recommendation-click]'); if (recommendation) track('recommendation_click', { product_id: Number(recommendation.dataset.productId || 0) }); const comparison = event.target.closest('[data-gl-comparison-product]'); if (comparison) track('comparison_product_select', { product_id: Number(comparison.dataset.productId || 0) }); });
	document.addEventListener('click', async (event) => { const button = event.target.closest('[data-gl-post-purchase-decision]'); if (!button) return; const surface = button.closest('[data-gl-post-purchase]'); const status = surface.querySelector('[data-gl-form-status]'); surface.querySelectorAll('button').forEach((item) => { item.disabled = true; }); const decision = button.dataset.glPostPurchaseDecision; const payload = await request('glissimo_post_purchase_offer', { decision, order_id: button.dataset.orderId, order_key: button.dataset.orderKey }); if (!payload.success) { status.textContent = payload.data?.message || GlissimoPhase2.error; surface.querySelectorAll('button').forEach((item) => { item.disabled = false; }); return; } track(`post_purchase_offer_${decision}`, { order_id: Number(button.dataset.orderId || 0) }); surface.remove(); });
})();
