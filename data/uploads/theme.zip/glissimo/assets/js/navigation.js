(() => {
	const mobile = document.querySelector('[data-gl-mobile-panel]');
	const open = document.querySelector('[data-gl-mobile-open]');
	const close = document.querySelector('[data-gl-close]');
	const search = document.querySelector('[data-gl-search-dialog]');
	const searchConfig = window.GlissimoSearch || {};
	const navigationConfig = window.GlissimoNavigation || {};
	const searchInput = search?.querySelector('[data-gl-search-input]');
	const searchClear = search?.querySelector('[data-gl-search-clear]');
	const searchSuggestions = search?.querySelector('[data-gl-search-suggestions]');
	const searchResults = search?.querySelector('[data-gl-search-results]');
	const searchResultList = search?.querySelector('[data-gl-search-result-list]');
	const searchStatus = search?.querySelector('[data-gl-search-status]');
	const searchViewAll = search?.querySelector('[data-gl-search-view-all]');
	let returnTo;
	let searchReturnTo;
	let searchTimer;
	let searchRequest;
	if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
		document.querySelectorAll('.gl-home-hero video').forEach(video => {
			video.pause();
			video.removeAttribute('autoplay');
		});
	}
	const focusable = root => [...root.querySelectorAll('a,button,input')].filter(node => !node.disabled && !node.closest('[hidden]'));
	const trapFocus = (event, root) => {
		if (event.key !== 'Tab') return;
		const nodes = focusable(root);
		if (!nodes.length) return;
		if (event.shiftKey && document.activeElement === nodes[0]) { event.preventDefault(); nodes.at(-1).focus(); }
		else if (!event.shiftKey && document.activeElement === nodes.at(-1)) { event.preventDefault(); nodes[0].focus(); }
	};
	const closeMobile = (restoreFocus = true) => {
		if (!mobile || mobile.hidden) return;
		mobile.hidden = true;
		document.body.classList.remove('gl-nav-open');
		open?.setAttribute('aria-expanded', 'false');
		if (restoreFocus) returnTo?.focus();
	};
	open?.addEventListener('click', () => { returnTo = document.activeElement; mobile.hidden = false; document.body.classList.add('gl-nav-open'); open.setAttribute('aria-expanded', 'true'); focusable(mobile)[0]?.focus(); });
	close?.addEventListener('click', closeMobile);
	document.querySelectorAll('[data-gl-mobile-drill]').forEach((button, index) => button.addEventListener('click', () => { const panel = button.nextElementSibling; if (!panel?.querySelector('a')) { const url = navigationConfig.topLevel?.[index]?.url; if (url) window.location.assign(url); return; } panel.hidden = false; button.closest('li').classList.add('is-drilled'); focusable(panel)[0]?.focus(); }));
	document.querySelectorAll('[data-gl-mobile-back]').forEach(button => button.addEventListener('click', () => { const item = button.closest('li'); item.querySelector('.gl-mobile-submenu').hidden = true; item.classList.remove('is-drilled'); item.querySelector('[data-gl-mobile-drill]').focus(); }));
	const closeMegas = except => document.querySelectorAll('[data-gl-mega-menu]').forEach(menu => { if (menu !== except) { menu.hidden = true; menu.previousElementSibling?.setAttribute('aria-expanded', 'false'); } });
	const primaryNav = document.querySelector('.gl-primary-nav');
	const openMega = trigger => {
		if (!window.matchMedia('(min-width: 64rem)').matches) return;
		const menu = document.getElementById(trigger.getAttribute('aria-controls'));
		if (!menu) return;
		closeMegas(menu);
		menu.hidden = false;
		trigger.setAttribute('aria-expanded', 'true');
	};
	document.querySelectorAll('[data-gl-mega-trigger]').forEach((trigger, index) => {
		trigger.addEventListener('pointerenter', () => openMega(trigger));
		trigger.addEventListener('focus', () => openMega(trigger));
		trigger.addEventListener('click', () => {
			const menu = document.getElementById(trigger.getAttribute('aria-controls'));
			if (!menu) { const url = navigationConfig.topLevel?.[index]?.url; if (url) window.location.assign(url); return; }
			if (!menu.hidden) return;
			closeMegas(menu);
			menu.hidden = false;
			trigger.setAttribute('aria-expanded', 'true');
		});
	});
	primaryNav?.addEventListener('pointerleave', () => closeMegas());
	primaryNav?.addEventListener('focusout', () => window.setTimeout(() => { if (!primaryNav.contains(document.activeElement)) closeMegas(); }, 0));
	document.addEventListener('click', event => { if (!event.target.closest('.gl-primary-nav')) closeMegas(); });
	const resetSearch = () => {
		clearTimeout(searchTimer);
		searchRequest?.abort();
		if (searchInput) searchInput.value = '';
		if (searchClear) searchClear.hidden = true;
		if (searchSuggestions) searchSuggestions.hidden = false;
		if (searchResults) searchResults.hidden = true;
		if (searchResultList) searchResultList.replaceChildren();
		if (searchStatus) searchStatus.textContent = '';
		if (searchViewAll) searchViewAll.hidden = true;
		search?.classList.remove('is-searching');
	};
	const closeSearch = () => {
		if (!search?.open) return;
		search.close();
	};
	const createSearchResult = product => {
		const link = document.createElement('a');
		link.className = 'gl-search-result';
		link.dataset.glSearchResult = '';
		link.href = product.url;
		const image = document.createElement('img');
		image.src = product.image;
		image.alt = '';
		image.width = 96;
		image.height = 96;
		image.loading = 'lazy';
		const copy = document.createElement('span');
		copy.className = 'gl-search-result__copy';
		const category = document.createElement('small');
		category.textContent = product.category || (product.inStock ? '' : (searchConfig.unavailable || 'Unavailable'));
		const name = document.createElement('strong');
		name.textContent = product.name;
		copy.append(category, name);
		const price = document.createElement('b');
		price.textContent = product.price;
		link.append(image, copy, price);
		return link;
	};
	const runSearch = async term => {
		searchRequest?.abort();
		searchRequest = new AbortController();
		search?.classList.add('is-searching');
		if (searchStatus) searchStatus.textContent = searchConfig.searching || 'Searching…';
		try {
			const url = new URL(searchConfig.ajaxUrl || '', window.location.origin);
			url.searchParams.set('action', searchConfig.action || 'glissimo_live_product_search');
			url.searchParams.set('nonce', searchConfig.nonce || '');
			url.searchParams.set('term', term);
			const response = await fetch(url, { credentials: 'same-origin', signal: searchRequest.signal });
			const payload = await response.json();
			if (!response.ok || !payload.success) throw new Error('Search failed');
			const products = Array.isArray(payload.data?.results) ? payload.data.results : [];
			searchResultList?.replaceChildren(...products.map(createSearchResult));
			if ((payload.data?.fallback || !products.length) && searchConfig.advanced) document.dispatchEvent(new CustomEvent('glissimo:track', { detail: { event: 'search_no_results', event_id: `search_no_results_${Date.now()}`, search_length: term.length } }));
			if (searchStatus) searchStatus.textContent = payload.data?.fallback ? (searchConfig.fallbackMessage || 'No exact match. These products may help.') : (products.length ? `${products.length} ${products.length === 1 ? (searchConfig.singular || 'product') : (searchConfig.plural || 'products')}` : (searchConfig.emptyMessage || 'No matching products were found.'));
			if (searchViewAll) {
				searchViewAll.href = payload.data?.viewAll || '#';
				searchViewAll.hidden = !products.length;
			}
		} catch (error) {
			if (error?.name === 'AbortError') return;
			searchResultList?.replaceChildren();
			if (searchStatus) searchStatus.textContent = searchConfig.errorMessage || 'Search is temporarily unavailable.';
			if (searchViewAll) searchViewAll.hidden = true;
		} finally {
			search?.classList.remove('is-searching');
		}
	};
	document.querySelectorAll('[data-gl-search-open]').forEach(button => button.addEventListener('click', () => {
		searchReturnTo = button.closest('[data-gl-mobile-panel]') ? (document.querySelector('.gl-header [data-gl-search-open]') || open) : button;
		closeMobile(false);
		search?.showModal();
		document.body.classList.add('gl-search-open');
		searchInput?.focus();
	}));
	document.querySelector('[data-gl-search-close]')?.addEventListener('click', closeSearch);
	search?.addEventListener('cancel', event => { event.preventDefault(); closeSearch(); });
	search?.addEventListener('close', () => { document.body.classList.remove('gl-search-open'); resetSearch(); searchReturnTo?.focus(); });
	searchClear?.addEventListener('click', () => { resetSearch(); searchInput?.focus(); });
	searchInput?.addEventListener('input', () => {
		const term = searchInput.value.trim();
		searchClear.hidden = !term;
		searchSuggestions.hidden = term.length >= 2;
		searchResults.hidden = term.length < 2;
		clearTimeout(searchTimer);
		if (term.length < 2) { searchRequest?.abort(); return; }
		searchTimer = window.setTimeout(() => runSearch(term), 220);
	});
	search?.addEventListener('keydown', event => {
		const results = [...search.querySelectorAll('[data-gl-search-result]')];
		if (!results.length || !['ArrowDown', 'ArrowUp'].includes(event.key)) return;
		const current = results.indexOf(document.activeElement);
		if (document.activeElement === searchInput || current >= 0) {
			event.preventDefault();
			const next = event.key === 'ArrowDown' ? (current + 1) % results.length : (current <= 0 ? results.length - 1 : current - 1);
			results[next].focus();
		}
	});
	document.querySelector('[data-gl-announcement-dismiss]')?.addEventListener('click', event => {
		const announcement = event.currentTarget.closest('[data-gl-announcement]');
		const key = announcement?.dataset.announcementKey;
		const restoreFocus = document.activeElement === event.currentTarget;
		if (key) document.cookie = `glissimo_announcement_dismissed=${encodeURIComponent(key)};path=/;max-age=2592000;SameSite=Lax${location.protocol === 'https:' ? ';Secure' : ''}`;
		announcement?.remove();
		if (restoreFocus) document.querySelector('.gl-header .gl-logo')?.focus();
	});
	window.addEventListener('resize', () => { closeMegas(); if (window.innerWidth >= 1024) closeMobile(); }, { passive: true });
	document.addEventListener('keydown', event => {
		if (event.key === 'Escape') { closeMobile(); closeMegas(); if (search?.open) closeSearch(); }
		if (!mobile?.hidden) trapFocus(event, mobile);
		if (search?.open) trapFocus(event, search);
	});
})();
