(() => {
	'use strict';
	const key = 'glissimo_wishlist_v1';
	const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
	const parse = () => { try { return JSON.parse(localStorage.getItem(key) || '[]').map(Number).filter(Boolean); } catch (_) { return []; } };
	let ids = Array.from(new Set([...parse(), ...(GlissimoPhase2.wishlistIds || []).map(Number)])).filter(Boolean);
	const emit = (event, productId) => document.dispatchEvent(new CustomEvent('glissimo:track', { detail: { event, event_id: `${event}_${Date.now()}_${productId}`, product_id: productId } }));
	const sync = () => { const data = new URLSearchParams({ action: 'glissimo_wishlist_sync', nonce: GlissimoPhase2.nonce }); ids.forEach((id) => data.append('product_ids[]', String(id))); return fetch(GlissimoPhase2.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data }); };
	const renderButtons = () => {
		document.querySelectorAll('[data-gl-wishlist-toggle]').forEach((button) => { const active = ids.includes(Number(button.dataset.productId)); button.setAttribute('aria-pressed', String(active)); button.setAttribute('aria-label', active ? GlissimoPhase2.labels.saved : GlissimoPhase2.labels.save); const label = button.querySelector('span'); if (label) label.textContent = active ? GlissimoPhase2.labels.saved : GlissimoPhase2.labels.save; button.classList.toggle('is-saved', active); });
		document.querySelectorAll('[data-gl-wishlist-count]').forEach((count) => { count.textContent = String(ids.length); count.hidden = ids.length === 0; });
		document.querySelectorAll('[data-gl-wishlist-link]').forEach((link) => {
			const label = ids.length === 0 ? GlissimoPhase2.labels.wishlistEmpty : (ids.length === 1 ? GlissimoPhase2.labels.wishlistCountSingle : GlissimoPhase2.labels.wishlistCount.replace('%d', String(ids.length)));
			if (!link.textContent.trim().startsWith('Wishlist')) link.setAttribute('aria-label', label);
		});
	};
	const save = async () => { localStorage.setItem(key, JSON.stringify(ids)); await sync(); renderButtons(); };
	const productCard = (product, removable = false) => `<article class="gl-product-card"><a class="gl-product-card__media" href="${escapeHtml(product.url)}"><img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}"></a><div class="gl-product-card__body"><h3><a href="${escapeHtml(product.url)}">${escapeHtml(product.name)}</a></h3><div class="gl-product-card__price">${product.priceHtml || ''}</div><div class="gl-wishlist__actions"><a class="gl-button gl-button--compact" href="${escapeHtml(product.cartUrl)}">${product.inStock ? escapeHtml(GlissimoPhase2.labels.addToCart) : escapeHtml(GlissimoPhase2.labels.viewProduct)}</a>${removable ? `<button class="gl-button gl-button--tertiary" type="button" data-gl-wishlist-toggle data-product-id="${Number(product.id)}">${escapeHtml(GlissimoPhase2.labels.remove)}</button>` : ''}</div></div></article>`;
	document.addEventListener('click', async (event) => { const button = event.target.closest('[data-gl-wishlist-toggle]'); if (!button) return; const id = Number(button.dataset.productId); if (!id) return; const active = ids.includes(id); ids = active ? ids.filter((value) => value !== id) : [...ids, id]; await save(); emit(active ? 'remove_from_wishlist' : 'add_to_wishlist', id); if (document.querySelector('[data-gl-wishlist-page]')) loadPage(false); });
	async function loadPage(mergeServer = false) {
		const page = document.querySelector('[data-gl-wishlist-page]'); if (!page) return;
		if (mergeServer) { const server = JSON.parse(page.dataset.serverIds || '[]'); ids = Array.from(new Set([...server.map(Number), ...ids])); }
		const url = new URL(GlissimoPhase2.ajaxUrl); url.searchParams.set('action', 'glissimo_wishlist_products'); url.searchParams.set('nonce', GlissimoPhase2.nonce); ids.forEach((id) => url.searchParams.append('product_ids[]', String(id)));
		const response = await fetch(url, { credentials: 'same-origin' }); const payload = await response.json(); const products = payload.success ? payload.data.products : []; const recommendations = payload.success ? payload.data.recommendations : [];
		page.querySelector('[data-gl-wishlist-empty]').hidden = products.length > 0; page.querySelector('[data-gl-wishlist-grid]').innerHTML = products.map((product) => productCard(product, true)).join('');
		const personalized = page.querySelector('[data-gl-personalized]'); personalized.hidden = recommendations.length === 0; personalized.querySelector('[data-gl-personalized-grid]').innerHTML = recommendations.map((product) => productCard(product)).join(''); renderButtons();
	}
	renderButtons(); loadPage(true);
})();
