<?php
/** Glissimo product review presentation. */
defined( 'ABSPATH' ) || exit;

if ( post_password_required() || ! function_exists( 'wc_get_rating_html' ) ) { return; }

$product = wc_get_product( get_the_ID() );
if ( ! $product ) { return; }
$reviews = get_comments( array( 'post_id' => get_the_ID(), 'status' => 'approve', 'type' => 'review', 'order' => 'DESC' ) );
$rating_enabled = 'yes' === get_option( 'woocommerce_enable_review_rating', 'yes' );
$rating_counts = array_fill( 1, 5, 0 );
foreach ( $reviews as $review_for_rating ) {
	$review_rating = (int) get_comment_meta( $review_for_rating->comment_ID, 'rating', true );
	if ( isset( $rating_counts[ $review_rating ] ) ) { $rating_counts[ $review_rating ]++; }
}
?>
<div class="gl-reviews" data-gl-review-provider="woocommerce">
	<?php if ( $reviews ) : ?>
		<div class="gl-reviews__summary">
			<div class="gl-reviews__score"><strong><?php echo esc_html( number_format_i18n( (float) $product->get_average_rating(), 1 ) ); ?><span>/5</span></strong><div><?php echo wp_kses_post( wc_get_rating_html( (float) $product->get_average_rating(), count( $reviews ) ) ); ?><p><?php echo esc_html( sprintf( _n( 'Based on %d review', 'Based on %d reviews', count( $reviews ), 'glissimo' ), count( $reviews ) ) ); ?></p></div></div>
			<div class="gl-reviews__distribution" aria-label="<?php esc_attr_e( 'Rating distribution', 'glissimo' ); ?>"><?php for ( $stars = 5; $stars >= 1; $stars-- ) : $percentage = count( $reviews ) ? ( $rating_counts[ $stars ] / count( $reviews ) ) * 100 : 0; ?><div><span><?php echo esc_html( (string) $stars ); ?> <span aria-hidden="true">★</span></span><i aria-hidden="true"><b style="width:<?php echo esc_attr( (string) $percentage ); ?>%"></b></i><span><?php echo esc_html( (string) $rating_counts[ $stars ] ); ?></span></div><?php endfor; ?></div>
		</div>
		<div class="gl-reviews__list">
			<?php foreach ( $reviews as $review ) : $rating = (int) get_comment_meta( $review->comment_ID, 'rating', true ); $verified = wc_customer_bought_product( $review->comment_author_email, $review->user_id, $product->get_id() ); ?>
				<article class="gl-review" id="comment-<?php echo esc_attr( $review->comment_ID ); ?>">
					<header><div><?php if ( $rating_enabled && $rating ) { echo wp_kses_post( wc_get_rating_html( $rating ) ); } ?><strong><?php echo esc_html( get_comment_author( $review ) ); ?></strong><?php if ( $verified ) : ?><span class="gl-review__verified"><?php echo glissimo_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Verified owner', 'glissimo' ); ?></span><?php endif; ?></div><time datetime="<?php echo esc_attr( get_comment_date( DATE_W3C, $review ) ); ?>"><?php echo esc_html( get_comment_date( get_option( 'date_format' ), $review ) ); ?></time></header>
					<div class="gl-prose"><?php echo wp_kses_post( wpautop( $review->comment_content ) ); ?></div>
				</article>
			<?php endforeach; ?>
		</div>
	<?php elseif ( empty( $GLOBALS['glissimo_has_marketplace_feedback'] ) ) : ?>
		<div class="gl-reviews__empty"><span class="gl-reviews__empty-icon" aria-hidden="true"><?php echo glissimo_icon( 'star' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><div><h3><?php esc_html_e( 'No reviews yet', 'glissimo' ); ?></h3><p><?php esc_html_e( 'Be the first to share your experience with this product.', 'glissimo' ); ?></p></div></div>
	<?php endif; ?>

	<?php if ( comments_open() ) : ?>
		<div class="gl-review-form" id="review-form">
			<?php
			$comment_field = '';
			if ( $rating_enabled ) {
				$comment_field .= '<p class="comment-form-rating"><label for="rating">' . esc_html__( 'Your rating', 'glissimo' ) . ' <span class="required" aria-hidden="true">*</span></label><select name="rating" id="rating" required><option value="">' . esc_html__( 'Choose a rating', 'glissimo' ) . '</option><option value="5">' . esc_html__( 'Excellent', 'glissimo' ) . '</option><option value="4">' . esc_html__( 'Very good', 'glissimo' ) . '</option><option value="3">' . esc_html__( 'Good', 'glissimo' ) . '</option><option value="2">' . esc_html__( 'Fair', 'glissimo' ) . '</option><option value="1">' . esc_html__( 'Poor', 'glissimo' ) . '</option></select></p>';
			}
			$comment_field .= '<p class="comment-form-comment"><label for="comment">' . esc_html__( 'Your review', 'glissimo' ) . ' <span class="required" aria-hidden="true">*</span></label><textarea id="comment" name="comment" cols="45" rows="6" required></textarea></p>';
			$current_user = wp_get_current_user();
			$account_note = is_user_logged_in() ? '<p class="gl-review-form__account">' . sprintf( esc_html__( 'Reviewing as %s', 'glissimo' ), '<strong>' . esc_html( $current_user->display_name ) . '</strong>' ) . '</p>' : '';
			comment_form(
				array(
					'title_reply'          => __( 'Write a review', 'glissimo' ),
					'title_reply_before'   => '<header class="gl-review-form__heading"><p>' . esc_html__( 'Your experience', 'glissimo' ) . '</p><h3 id="reply-title" class="comment-reply-title">',
					'title_reply_after'    => '</h3></header>',
					'label_submit'         => __( 'Submit review', 'glissimo' ),
					'comment_field'        => $comment_field,
					'comment_notes_before' => '<p class="gl-review-form__note">' . esc_html__( 'Required fields are marked with an asterisk.', 'glissimo' ) . '</p>',
					'comment_notes_after'  => '',
					'logged_in_as'         => $account_note,
					'class_form'           => 'comment-form gl-review-form__fields',
					'class_submit'         => 'gl-button',
					'format'               => 'html5',
				)
			);
			?>
		</div>
	<?php endif; ?>
</div>
