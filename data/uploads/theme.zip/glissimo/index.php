<?php
/**
 * Safe fallback template.
 *
 * @package Glissimo
 */

get_header();
?>
<main id="main-content" class="gl-main gl-container" tabindex="-1">
	<?php if ( have_posts() ) : ?>
		<?php while ( have_posts() ) : ?>
			<?php the_post(); ?>
			<article <?php post_class( 'gl-content-entry' ); ?>>
				<?php if ( ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) && ( ! function_exists( 'is_cart' ) || ! is_cart() ) ) : ?>
					<?php the_title( '<h1 class="gl-heading-display">', '</h1>' ); ?>
				<?php endif; ?>
				<div class="gl-prose">
					<?php the_content(); ?>
				</div>
			</article>
		<?php endwhile; ?>
	<?php else : ?>
		<p><?php esc_html_e( 'There is nothing to display yet.', 'glissimo' ); ?></p>
	<?php endif; ?>
</main>
<?php
get_footer();
