<?php
$config = glissimo_core_settings()['consent'] ?? array();
if ( empty( $config['enabled'] ) ) { return; }
?>
<section class="gl-consent" data-gl-consent-banner hidden role="dialog" aria-modal="true" aria-labelledby="gl-consent-title" aria-describedby="gl-consent-copy">
	<div class="gl-consent__summary">
		<div><p class="gl-eyebrow"><?php esc_html_e( 'Privacy', 'glissimo' ); ?></p><h2 id="gl-consent-title"><?php echo esc_html( $config['heading'] ?: __( 'Your privacy choices', 'glissimo' ) ); ?></h2><p id="gl-consent-copy"><?php echo esc_html( $config['copy'] ?: __( 'Necessary storage keeps the shop working. Optional analytics and marketing require your choice.', 'glissimo' ) ); ?></p><?php if ( ! empty( $config['policy_url'] ) ) : ?><a href="<?php echo esc_url( $config['policy_url'] ); ?>"><?php esc_html_e( 'Privacy policy', 'glissimo' ); ?></a><?php endif; ?></div>
		<div class="gl-consent__actions"><button class="gl-button gl-button--outline" type="button" data-gl-consent-reject><?php esc_html_e( 'Necessary only', 'glissimo' ); ?></button><button class="gl-button gl-button--outline" type="button" data-gl-consent-customize><?php esc_html_e( 'Choose', 'glissimo' ); ?></button><button class="gl-button" type="button" data-gl-consent-accept><?php esc_html_e( 'Accept optional', 'glissimo' ); ?></button></div>
	</div>
	<form class="gl-consent__preferences" data-gl-consent-preferences hidden>
		<p><?php echo esc_html( $config['preferences_copy'] ?: __( 'Choose which optional services may run. You can change this later.', 'glissimo' ) ); ?></p>
		<label><input type="checkbox" checked disabled> <?php esc_html_e( 'Necessary — always active', 'glissimo' ); ?></label>
		<label><input type="checkbox" name="analytics"> <?php esc_html_e( 'Analytics', 'glissimo' ); ?></label>
		<label><input type="checkbox" name="marketing"> <?php esc_html_e( 'Marketing', 'glissimo' ); ?></label>
		<label><input type="checkbox" name="preferences"> <?php esc_html_e( 'Preferences', 'glissimo' ); ?></label>
		<button class="gl-button" type="submit"><?php esc_html_e( 'Save choices', 'glissimo' ); ?></button>
	</form>
</section>
<button class="gl-privacy-trigger" type="button" data-gl-consent-reopen><?php esc_html_e( 'Privacy choices', 'glissimo' ); ?></button>
