<?php
defined( 'ABSPATH' ) || exit;
$settings = glissimo_core_settings();
$cart_config = $settings['cart'] ?? array();
$cart = function_exists( 'WC' ) ? WC()->cart : null;
$shipping = glissimo_shipping_progress_state();
if ( ! empty( $shipping['message'] ) && function_exists( 'glissimo_is_internal_content' ) && glissimo_is_internal_content( (string) $shipping['message'] ) ) {
	$shipping = array();
}
$gift_config = $settings['free_gift'] ?? array();
$gift_threshold = (float) ( $gift_config['threshold'] ?? 0 );
$gift_subtotal = $cart ? glissimo_merchandise_subtotal( $cart ) : 0;
$gift_remaining = max( 0, $gift_threshold - $gift_subtotal );
$gift_present = false;
if ( $cart ) {
	foreach ( $cart->get_cart() as $gift_candidate ) {
		$gift_present = $gift_present || ! empty( $gift_candidate['glissimo_free_gift'] );
	}
}
$recommendations = glissimo_cart_recommendations();
?>
<div class="gl-cart-drawer" data-gl-cart-drawer hidden>
	<button class="gl-cart-drawer__backdrop" type="button" data-gl-cart-close tabindex="-1" aria-label="<?php esc_attr_e( 'Close cart', 'glissimo' ); ?>"></button>
	<section class="gl-cart-drawer__panel" role="dialog" aria-modal="true" aria-labelledby="gl-cart-title" tabindex="-1">
		<header class="gl-cart-drawer__header">
			<div><p><?php esc_html_e( 'Your selection', 'glissimo' ); ?></p><h2 id="gl-cart-title"><?php esc_html_e( 'Shopping cart', 'glissimo' ); ?></h2></div>
			<button class="gl-cart-drawer__close" type="button" data-gl-cart-close aria-label="<?php esc_attr_e( 'Close cart', 'glissimo' ); ?>">&times;</button>
		</header>
		<div class="gl-cart-drawer__live screen-reader-text" data-gl-cart-live aria-live="polite" aria-atomic="true"></div>

		<?php if ( ! $cart || $cart->is_empty() ) : ?>
			<div class="gl-cart-drawer__empty">
				<h3><?php esc_html_e( 'Your cart is ready when you are.', 'glissimo' ); ?></h3>
				<p><?php esc_html_e( 'Explore cookware and kitchen essentials, then return here to check out.', 'glissimo' ); ?></p>
				<button class="gl-button" type="button" data-gl-cart-close><?php echo esc_html( $cart_config['continue_label'] ?? __( 'Continue shopping', 'glissimo' ) ); ?></button>
			</div>
		<?php else : ?>
			<div class="gl-cart-drawer__scroll">
				<?php if ( $shipping ) : ?>
					<section class="gl-cart-progress" aria-label="<?php esc_attr_e( 'Free shipping progress', 'glissimo' ); ?>">
						<p><?php echo esc_html( $shipping['message'] ); ?></p>
						<div class="gl-cart-progress__track" aria-hidden="true"><i style="width:<?php echo esc_attr( (string) $shipping['percent'] ); ?>%"></i></div>
					</section>
				<?php endif; ?>

				<?php if ( ! empty( $gift_config['enabled'] ) && $gift_threshold > 0 && ! empty( $gift_config['product_id'] ) ) : ?>
					<section class="gl-cart-gift">
						<p><?php echo esc_html( $gift_remaining > 0 ? glissimo_progress_message( (string) $gift_config['progress_message'], wp_strip_all_tags( wc_price( $gift_remaining ) ) ) : ( $gift_present ? (string) $gift_config['unlocked_message'] : __( 'Gift qualification reached. The selected gift is not currently in your cart.', 'glissimo' ) ) ); ?></p>
					</section>
				<?php endif; ?>

				<ul class="gl-cart-lines">
					<?php foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) :
						$product = $cart_item['data'];
						if ( ! $product instanceof WC_Product ) { continue; }
						$is_fixed = ! empty( $cart_item['glissimo_free_gift'] ) || ! empty( $cart_item['glissimo_bundle_group'] ) || ! empty( $cart_item['glissimo_order_bump'] );
						?>
						<li class="gl-cart-line<?php echo ! empty( $cart_item['glissimo_free_gift'] ) ? ' is-gift' : ''; ?>" data-gl-cart-line>
							<a class="gl-cart-line__image" href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ) ); ?></a>
							<div class="gl-cart-line__main">
								<?php if ( ! empty( $cart_item['glissimo_bundle_title'] ) ) : ?><span class="gl-cart-line__label"><?php echo esc_html( $cart_item['glissimo_bundle_title'] ); ?></span><?php endif; ?>
								<?php if ( ! empty( $cart_item['glissimo_free_gift'] ) ) : ?><span class="gl-cart-line__label"><?php esc_html_e( 'Complimentary gift', 'glissimo' ); ?></span><?php endif; ?>
								<a href="<?php echo esc_url( $product->get_permalink() ); ?>"><strong><?php echo esc_html( $product->get_name() ); ?></strong></a>
								<?php echo wp_kses_post( wc_get_formatted_cart_item_data( $cart_item ) ); ?>
								<div class="gl-cart-line__controls">
									<?php if ( $is_fixed ) : ?>
										<span><?php echo esc_html( sprintf( __( 'Quantity %d', 'glissimo' ), (int) $cart_item['quantity'] ) ); ?></span>
									<?php else : ?>
										<div class="gl-cart-quantity" aria-label="<?php esc_attr_e( 'Quantity', 'glissimo' ); ?>">
											<button type="button" data-gl-cart-quantity data-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>" data-quantity="<?php echo esc_attr( max( 0, (int) $cart_item['quantity'] - 1 ) ); ?>" aria-label="<?php esc_attr_e( 'Decrease quantity', 'glissimo' ); ?>">&minus;</button>
											<span><?php echo esc_html( (int) $cart_item['quantity'] ); ?></span>
											<button type="button" data-gl-cart-quantity data-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>" data-quantity="<?php echo esc_attr( (int) $cart_item['quantity'] + 1 ); ?>" aria-label="<?php esc_attr_e( 'Increase quantity', 'glissimo' ); ?>">+</button>
										</div>
									<?php endif; ?>
									<button class="gl-cart-line__remove" type="button" data-gl-cart-remove data-cart-item-key="<?php echo esc_attr( $cart_item_key ); ?>"><?php echo esc_html( ! empty( $cart_item['glissimo_bundle_group'] ) ? __( 'Remove bundle', 'glissimo' ) : __( 'Remove', 'glissimo' ) ); ?></button>
								</div>
							</div>
							<strong class="gl-cart-line__price"><?php echo wp_kses_post( ! empty( $cart_item['glissimo_free_gift'] ) ? __( 'Gift', 'glissimo' ) : $cart->get_product_subtotal( $product, (int) $cart_item['quantity'] ) ); ?></strong>
						</li>
					<?php endforeach; ?>
				</ul>

				<?php if ( $recommendations ) : ?>
					<section class="gl-cart-recommendations" aria-labelledby="gl-cart-recommendations-title">
						<h3 id="gl-cart-recommendations-title"><?php esc_html_e( 'Pairs well with your cart', 'glissimo' ); ?></h3>
						<div>
							<?php foreach ( $recommendations as $recommendation ) : ?>
								<article>
									<?php echo wp_kses_post( $recommendation->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ) ); ?>
									<span><strong><?php echo esc_html( $recommendation->get_name() ); ?></strong><?php echo wp_kses_post( $recommendation->get_price_html() ); ?></span>
									<button type="button" data-gl-cart-add data-product-id="<?php echo esc_attr( $recommendation->get_id() ); ?>"><?php esc_html_e( 'Add', 'glissimo' ); ?></button>
								</article>
							<?php endforeach; ?>
						</div>
					</section>
				<?php endif; ?>
			</div>

			<footer class="gl-cart-drawer__footer">
				<p><span><?php esc_html_e( 'Subtotal', 'glissimo' ); ?></span><strong><?php echo wp_kses_post( $cart->get_cart_subtotal() ); ?></strong></p>
				<small><?php esc_html_e( 'Shipping, tax and available payment methods are confirmed at checkout.', 'glissimo' ); ?></small>
				<a class="gl-button" href="<?php echo esc_url( wc_get_checkout_url() ); ?>"><?php echo esc_html( $cart_config['checkout_label'] ?? __( 'Secure checkout', 'glissimo' ) ); ?></a>
				<button type="button" data-gl-cart-close><?php echo esc_html( $cart_config['continue_label'] ?? __( 'Continue shopping', 'glissimo' ) ); ?></button>
			</footer>
		<?php endif; ?>
	</section>
</div>
