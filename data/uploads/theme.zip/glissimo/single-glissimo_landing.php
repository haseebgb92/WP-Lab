<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
	$campaign = wp_parse_args( (array) get_post_meta( get_the_ID(), '_glissimo_landing', true ), array( 'sections' => array( 'content', 'trust', 'products', 'comparison', 'faq', 'newsletter' ) ) );
	$campaign_tracking_label = sanitize_key( $campaign['tracking_label'] ?? '' );
	$products = array_values( array_filter( array_map( 'wc_get_product', (array) ( $campaign['product_ids'] ?? array() ) ), static fn( $product ) => $product instanceof WC_Product && $product->is_visible() ) );
	$trust_items = array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) ( $campaign['trust_items'] ?? '' ) ) ?: array() ) ) );
	$faq = array(); foreach ( preg_split( '/\R/', (string) ( $campaign['faq_lines'] ?? '' ) ) ?: array() as $line ) { $parts = array_map( 'trim', explode( '|', $line, 2 ) ); if ( count( $parts ) === 2 && $parts[0] && $parts[1] ) { $faq[] = $parts; } }
	?>
	<main id="main-content" class="gl-phase2 gl-campaign" data-campaign-label="<?php echo esc_attr( $campaign_tracking_label ); ?>">
		<header class="gl-campaign__hero"><?php if ( has_post_thumbnail() ) : ?><div class="gl-campaign__media"><?php the_post_thumbnail( 'full', array( 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?></div><?php endif; ?><div class="gl-container gl-campaign__hero-copy"><p class="gl-eyebrow"><?php esc_html_e( 'Glissimo collection', 'glissimo' ); ?></p><h1 class="gl-heading-display"><?php the_title(); ?></h1><?php if ( has_excerpt() ) : ?><p class="gl-prose"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?><?php if ( ! empty( $campaign['cta_label'] ) && ! empty( $campaign['cta_url'] ) ) : ?><a class="gl-button" href="<?php echo esc_url( $campaign['cta_url'] ); ?>" data-gl-landing-conversion><?php echo esc_html( $campaign['cta_label'] ); ?></a><?php endif; ?></div></header>
		<?php foreach ( (array) $campaign['sections'] as $section ) : ?>
			<?php if ( 'content' === $section && trim( get_the_content() ) ) : ?><section class="gl-container gl-campaign__content gl-prose"><?php the_content(); ?></section>
			<?php elseif ( 'trust' === $section && $trust_items ) : ?><section class="gl-campaign__trust"><div class="gl-container"><h2 class="screen-reader-text"><?php esc_html_e( 'Why choose Glissimo', 'glissimo' ); ?></h2><?php foreach ( $trust_items as $item ) : ?><p><?php echo esc_html( $item ); ?></p><?php endforeach; ?></div></section>
			<?php elseif ( 'products' === $section && $products ) : ?><section class="gl-container gl-campaign__products"><p class="gl-eyebrow"><?php esc_html_e( 'Selected for this collection', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Shop the collection', 'glissimo' ); ?></h2><div class="gl-product-grid"><?php foreach ( $products as $product ) { glissimo_render_product_card( $product ); } ?></div></section>
			<?php elseif ( 'comparison' === $section && count( $products ) > 1 && glissimo_phase2_enabled( 'comparison' ) ) : ?><section class="gl-container gl-campaign__comparison"><p class="gl-eyebrow"><?php esc_html_e( 'Choose with confidence', 'glissimo' ); ?></p><h2><?php esc_html_e( 'See the differences at a glance', 'glissimo' ); ?></h2><a class="gl-button gl-button--secondary" href="<?php echo esc_url( home_url( '/compare-products/' ) ); ?>"><?php esc_html_e( 'Compare products', 'glissimo' ); ?></a></section>
			<?php elseif ( 'faq' === $section && $faq ) : ?><section class="gl-container gl-campaign__faq"><p class="gl-eyebrow"><?php esc_html_e( 'Questions, answered', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Before you choose', 'glissimo' ); ?></h2><?php foreach ( $faq as $row ) : ?><details><summary><?php echo esc_html( $row[0] ); ?></summary><div class="gl-prose"><p><?php echo esc_html( $row[1] ); ?></p></div></details><?php endforeach; ?></section>
			<?php elseif ( 'newsletter' === $section && ! empty( $campaign['newsletter_enabled'] ) ) : ?><section class="gl-newsletter gl-campaign__newsletter"><div class="gl-container"><p class="gl-eyebrow"><?php esc_html_e( 'Stay close to Glissimo', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Save this collection for later inspiration.', 'glissimo' ); ?></h2><?php glissimo_newsletter_form( 'campaign_' . $campaign_tracking_label ); ?></div></section>
			<?php endif; ?>
		<?php endforeach; ?>
	</main>
	<?php
endwhile;
get_footer();
