<?php
defined( 'ABSPATH' ) || exit;

get_header();

$settings            = class_exists( '\\Advertpreneur\\Core\\Sites\\Glissimo\\Settings' ) ? \Advertpreneur\Core\Sites\Glissimo\Settings::all() : array();
$collection_settings = $settings['collection'] ?? array();
$is_product_category = is_product_category();
$query_obj          = get_queried_object();
$ordering           = sanitize_key( $_GET['orderby'] ?? 'menu_order' );
$stock_filter       = isset( $_GET['filter_stock'] ) ? sanitize_key( (string) $_GET['filter_stock'] ) : '';
$sale_filter        = isset( $_GET['filter_sale'] ) ? sanitize_key( (string) $_GET['filter_sale'] ) : '';
$minimum_price      = isset( $_GET['min_price'] ) ? wc_format_decimal( wp_unslash( (string) $_GET['min_price'] ) ) : '';
$maximum_price      = isset( $_GET['max_price'] ) ? wc_format_decimal( wp_unslash( (string) $_GET['max_price'] ) ) : '';
$permalink          = $is_product_category ? get_term_link( $query_obj ) : wc_get_page_permalink( 'shop' );
$attribute_filters  = glissimo_collection_attribute_filters();
$commerce_facets    = glissimo_collection_commerce_facets();
$comparison_settings = function_exists( 'glissimo_phase2_settings' ) ? ( glissimo_phase2_settings()['comparison'] ?? array() ) : array();
$discover_view      = isset( $_GET['gl_view'] ) ? sanitize_key( wp_unslash( (string) $_GET['gl_view'] ) ) : '';
$discover_titles    = array(
	'bestsellers' => array( __( 'Bestsellers', 'glissimo' ), __( 'Products customers return to first, ordered by real WooCommerce sales.', 'glissimo' ) ),
	'new'         => array( __( 'New arrivals', 'glissimo' ), __( 'The latest additions to the Glissimo collection.', 'glissimo' ) ),
	'deals'       => array( __( 'Current deals', 'glissimo' ), __( 'Products with a genuine active WooCommerce sale price.', 'glissimo' ) ),
);

$current_category = $is_product_category && $query_obj instanceof WP_Term ? $query_obj : null;
$category_intro   = $current_category instanceof WP_Term ? glissimo_collection_customer_copy( (string) $current_category->description ) : '';
$editorial        = glissimo_customer_content_tree( $collection_settings );
$filter_parent   = $is_product_category && $current_category instanceof WP_Term ? $current_category->term_id : 0;
$sub_categories = get_terms(
	array(
		'taxonomy'   => 'product_cat',
		'parent'     => $filter_parent,
		'hide_empty' => true,
	)
);
if ( empty( $sub_categories ) ) {
	$sub_categories = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'parent'     => 0,
			'hide_empty' => true,
		)
	);
}

$sort_options = array(
	'menu_order' => __( 'Default', 'glissimo' ),
	'popularity' => __( 'Popularity', 'glissimo' ),
	'rating'     => __( 'Customer rating', 'glissimo' ),
	'date'       => __( 'Newest', 'glissimo' ),
	'price'      => __( 'Price: low to high', 'glissimo' ),
	'price-desc' => __( 'Price: high to low', 'glissimo' ),
);

$render_query_state = static function ( array $exclude = array() ): void {
	foreach ( wp_unslash( (array) $_GET ) as $key => $value ) {
		$key = sanitize_key( (string) $key );
		if ( in_array( $key, $exclude, true ) || ! is_scalar( $value ) || ! preg_match( '/^(?:orderby|gl_view|filter_stock|filter_sale|min_price|max_price|per_page|filter_pa_[a-z0-9_-]+)$/', $key ) ) {
			continue;
		}
		printf( '<input type="hidden" name="%1$s" value="%2$s">', esc_attr( $key ), esc_attr( sanitize_text_field( (string) $value ) ) );
	}
};

?>
<main id="main-content" class="gl-collection" tabindex="-1">
	<header class="gl-page-hero gl-collection__header">
		<div class="gl-container gl-page-hero__inner">
		<p class="gl-eyebrow"><?php esc_html_e( 'Glissimo collection', 'glissimo' ); ?></p>
		<h1 class="gl-heading-display"><?php echo esc_html( isset( $discover_titles[ $discover_view ] ) ? $discover_titles[ $discover_view ][0] : ( $current_category instanceof WP_Term ? $current_category->name : ( $collection_settings['intro_heading'] ?? '' ) ) ); ?></h1>
		<?php if ( isset( $discover_titles[ $discover_view ] ) ) : ?><p><?php echo esc_html( $discover_titles[ $discover_view ][1] ); ?></p>
		<?php elseif ( ! empty( $collection_settings['intro_copy'] ) ) : ?>
			<p><?php echo esc_html( $collection_settings['intro_copy'] ); ?></p>
		<?php elseif ( '' !== $category_intro ) : ?>
			<?php echo wp_kses_post( wpautop( $category_intro ) ); ?>
		<?php endif; ?>
		<?php if ( ! empty( $collection_settings['cta_url'] ) ) : ?>
			<p><a class="gl-button gl-button--outline" href="<?php echo esc_url( $collection_settings['cta_url'] ); ?>"><?php echo esc_html( $collection_settings['cta_label'] ); ?></a></p>
		<?php endif; ?>
		<?php if ( function_exists( 'woocommerce_breadcrumb' ) ) : ?>
			<div class="gl-page-hero__breadcrumbs"><?php woocommerce_breadcrumb( array( 'delimiter' => '<span aria-hidden="true">/</span>' ) ); ?></div>
		<?php endif; ?>
		</div>
	</header>
	<div class="gl-container gl-collection__body">
	<div class="gl-collection__toolbar">
		<div class="gl-collection__toolbar-group">
			<button type="button" class="gl-button gl-collection__filter-open" data-gl-filter-open aria-expanded="false">
				<?php esc_html_e( 'Filters', 'glissimo' ); ?>
			</button>
			<p class="gl-collection__count" aria-label="<?php echo esc_attr( sprintf( __( 'Showing products %s', 'glissimo' ), glissimo_collection_result_summary() ) ); ?>"><?php echo esc_html( glissimo_collection_result_summary() ); ?></p>
		</div>
		<form class="gl-collection__sort" method="get" action="<?php echo esc_url( $permalink ); ?>">
			<label for="gl-sort-select"><?php esc_html_e( 'Sort by', 'glissimo' ); ?></label>
			<select id="gl-sort-select" name="orderby" onchange="this.form.submit()">
				<?php foreach ( $sort_options as $value => $label ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $ordering, $value ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<?php $render_query_state( array( 'orderby' ) ); ?>
		</form>
	</div>

	<div class="gl-collection__layout">
		<aside class="gl-collection__sidebar" aria-label="<?php esc_attr_e( 'Collection filters', 'glissimo' ); ?>">
			<div class="gl-collection__filter-section">
				<h2><?php esc_html_e( 'Categories', 'glissimo' ); ?></h2>
				<ul>
					<li>
						<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"<?php if ( ! $current_category ) : ?> aria-current="page"<?php endif; ?>>
							<?php esc_html_e( 'Shop all', 'glissimo' ); ?>
						</a>
					</li>
					<?php foreach ( $sub_categories as $cat ) : ?>
						<?php if ( ! is_object( $cat ) || ! isset( $cat->term_id ) ) { continue; } ?>
						<li>
							<a href="<?php echo esc_url( get_term_link( $cat ) ); ?>" <?php echo ( $current_category && $current_category->term_id === $cat->term_id ) ? 'aria-current="page"' : ''; ?>>
								<?php echo esc_html( $cat->name ); ?>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>

			<?php foreach ( $attribute_filters as $attribute_filter ) : ?>
				<?php
				$filter_key = 'filter_' . $attribute_filter['taxonomy'];
				$selected   = isset( $_GET[ $filter_key ] ) ? sanitize_title( wp_unslash( (string) $_GET[ $filter_key ] ) ) : '';
				?>
				<div class="gl-collection__filter-section">
					<h2><?php echo esc_html( $attribute_filter['label'] ); ?></h2>
					<ul>
						<?php foreach ( $attribute_filter['terms'] as $term ) : ?>
							<li><a href="<?php echo esc_url( glissimo_collection_filters_url( array( $filter_key => $selected === $term->slug ? '' : $term->slug ) ) ); ?>" <?php echo $selected === $term->slug ? 'aria-current="true" class="is-active"' : ''; ?>><?php echo esc_html( $term->name ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>

			<?php if ( null !== $commerce_facets['min_price'] && $commerce_facets['max_price'] > $commerce_facets['min_price'] ) : ?>
				<div class="gl-collection__filter-section">
					<h2><?php esc_html_e( 'Price', 'glissimo' ); ?></h2>
					<form class="gl-collection__price-form" method="get" action="<?php echo esc_url( $permalink ); ?>">
						<label><span><?php esc_html_e( 'Minimum', 'glissimo' ); ?></span><input type="number" min="0" step="0.01" name="min_price" value="<?php echo esc_attr( $minimum_price ); ?>" placeholder="<?php echo esc_attr( wc_format_localized_price( $commerce_facets['min_price'] ) ); ?>"></label>
						<label><span><?php esc_html_e( 'Maximum', 'glissimo' ); ?></span><input type="number" min="0" step="0.01" name="max_price" value="<?php echo esc_attr( $maximum_price ); ?>" placeholder="<?php echo esc_attr( wc_format_localized_price( $commerce_facets['max_price'] ) ); ?>"></label>
						<?php $render_query_state( array( 'min_price', 'max_price' ) ); ?>
						<button type="submit" class="gl-button gl-button--secondary gl-button--compact"><?php esc_html_e( 'Apply price', 'glissimo' ); ?></button>
					</form>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $commerce_facets['has_sale'] ) ) : ?>
				<div class="gl-collection__filter-section">
					<h2><?php esc_html_e( 'Offers', 'glissimo' ); ?></h2>
					<ul><li><a href="<?php echo esc_url( glissimo_collection_filters_url( array( 'filter_sale' => 'onsale' === $sale_filter ? '' : 'onsale' ) ) ); ?>" <?php echo 'onsale' === $sale_filter ? 'aria-current="true" class="is-active"' : ''; ?>><?php esc_html_e( 'On sale', 'glissimo' ); ?></a></li></ul>
				</div>
			<?php endif; ?>

			<div class="gl-collection__filter-section">
				<h2><?php esc_html_e( 'Availability', 'glissimo' ); ?></h2>
				<ul>
					<li>
						<a href="<?php echo esc_url( glissimo_collection_filters_url( array( 'filter_stock' => 'instock' ) ) ); ?>" class="<?php echo 'instock' === $stock_filter ? 'is-active' : ''; ?>">
							<?php esc_html_e( 'In stock', 'glissimo' ); ?>
						</a>
					</li>
					<li>
						<a href="<?php echo esc_url( glissimo_collection_filters_url( array( 'filter_stock' => 'outofstock' ) ) ); ?>" class="<?php echo 'outofstock' === $stock_filter ? 'is-active' : ''; ?>">
							<?php esc_html_e( 'Out of stock', 'glissimo' ); ?>
						</a>
					</li>
					<?php if ( $stock_filter ) : ?>
						<li>
							<a href="<?php echo esc_url( glissimo_collection_filters_url( array( 'filter_stock' => '' ) ) ); ?>">
								<?php esc_html_e( 'Clear stock filter', 'glissimo' ); ?>
							</a>
						</li>
					<?php endif; ?>
				</ul>
			</div>
		</aside>

		<section class="gl-collection__products" aria-label="<?php esc_attr_e( 'Product results', 'glissimo' ); ?>">
			<?php if ( woocommerce_product_loop() ) : ?>
				<div class="gl-product-grid gl-product-grid--collection" style="--gl-product-columns: <?php echo esc_attr( (int) ( $collection_settings['desktop_columns'] ?? 3 ) ); ?>">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php global $product; ?>
						<?php if ( $product instanceof WC_Product ) : ?>
							<?php glissimo_product_card( $product ); ?>
						<?php endif; ?>
					<?php endwhile; ?>
				</div>

				<?php
				global $wp_query;
				$total_pages = (int) $wp_query->max_num_pages;
				$current     = max( 1, get_query_var( 'paged' ) );
				if ( $total_pages > 1 ) :
					?>
					<nav class="gl-collection__pagination" aria-label="<?php esc_attr_e( 'Collection pagination', 'glissimo' ); ?>">
						<?php
						echo wp_kses_post(
							paginate_links(
								array(
									'current'   => $current,
									'total'     => $total_pages,
									'prev_text' => __( 'Previous', 'glissimo' ),
									'next_text' => __( 'Next', 'glissimo' ),
								)
							)
						);
						?>
					</nav>
				<?php endif; ?>
			<?php else : ?>
				<section class="gl-collection__empty" role="status">
					<h2><?php esc_html_e( 'No products match this category yet', 'glissimo' ); ?></h2>
					<p><?php esc_html_e( 'Try removing one or more filters to explore the full collection.', 'glissimo' ); ?></p>
					<a class="gl-button" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Browse all products', 'glissimo' ); ?></a>
				</section>
			<?php endif; ?>
		</section>
	</div>

	<?php if ( function_exists( 'glissimo_phase2_enabled' ) && glissimo_phase2_enabled( 'comparison' ) ) : ?>
		<section class="gl-collection__compare-panel" aria-labelledby="gl-collection-compare-heading">
			<div class="gl-collection__compare-copy">
				<p class="gl-eyebrow"><?php esc_html_e( 'Choose with confidence', 'glissimo' ); ?></p>
				<h2 id="gl-collection-compare-heading"><?php echo esc_html( $comparison_settings['title'] ?? __( 'Compare cookware side by side', 'glissimo' ) ); ?></h2>
				<p><?php esc_html_e( 'Review real product details in one clear view and find the right fit for your kitchen.', 'glissimo' ); ?></p>
			</div>
			<a class="gl-button gl-button--secondary" href="<?php echo esc_url( home_url( '/compare-products/' ) ); ?>"><?php esc_html_e( 'Compare cookware', 'glissimo' ); ?></a>
		</section>
	<?php endif; ?>

	<?php
	$editorial_media_id     = (int) ( $editorial['editorial_media_id'] ?? 0 );
	$editorial_media_markup = '';
	if ( $editorial_media_id ) {
		$editorial_media_type = (string) get_post_mime_type( $editorial_media_id );
		if ( str_starts_with( $editorial_media_type, 'video/' ) ) {
			$editorial_media_url = wp_get_attachment_url( $editorial_media_id );
			if ( $editorial_media_url ) { $editorial_media_markup = sprintf( '<video controls preload="metadata" playsinline src="%s"></video>', esc_url( $editorial_media_url ) ); }
		} else {
			$editorial_media_markup = wp_get_attachment_image( $editorial_media_id, 'large', false, array( 'loading' => 'lazy', 'sizes' => '(max-width: 768px) 100vw, 48vw' ) );
		}
	}
	$editorial_has_content = ! empty( $editorial['editorial_heading'] ) && ( ! empty( $editorial['editorial_intro'] ) || ! empty( $editorial['editorial_copy'] ) || '' !== $editorial_media_markup );
	$editorial_links = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $editorial['editorial_links'] ?? '' ) ) as $link_line ) {
		$parts = array_map( 'trim', explode( '|', $link_line, 2 ) );
		if ( 2 === count( $parts ) && '' !== $parts[0] && '' !== esc_url_raw( $parts[1] ) ) { $editorial_links[] = array( 'label' => $parts[0], 'url' => $parts[1] ); }
	}
	?>
	<?php if ( ! empty( $editorial['editorial_enabled'] ) && $editorial_has_content ) : ?>
		<section class="gl-collection-editorial gl-collection-editorial--<?php echo esc_attr( $editorial['editorial_layout'] ?? 'split' ); ?>" aria-labelledby="gl-collection-editorial-heading">
			<?php if ( '' !== $editorial_media_markup ) : ?><figure class="gl-collection-editorial__media"><?php echo wp_kses_post( $editorial_media_markup ); ?></figure><?php endif; ?>
			<div class="gl-collection-editorial__content">
				<?php if ( ! empty( $editorial['editorial_eyebrow'] ) ) : ?><p class="gl-eyebrow"><?php echo esc_html( $editorial['editorial_eyebrow'] ); ?></p><?php endif; ?>
				<h2 id="gl-collection-editorial-heading"><?php echo esc_html( $editorial['editorial_heading'] ); ?></h2>
				<?php if ( ! empty( $editorial['editorial_intro'] ) ) : ?><p class="gl-collection-editorial__intro"><?php echo esc_html( $editorial['editorial_intro'] ); ?></p><?php endif; ?>
				<?php if ( ! empty( $editorial['editorial_copy'] ) ) : ?><div class="gl-prose"><?php echo wp_kses_post( wpautop( $editorial['editorial_copy'] ) ); ?></div><?php endif; ?>
				<?php if ( $editorial_links ) : ?><nav class="gl-collection-editorial__links" aria-label="<?php esc_attr_e( 'Explore related collections', 'glissimo' ); ?>"><?php foreach ( $editorial_links as $editorial_link ) : ?><a class="gl-button gl-button--tertiary" href="<?php echo esc_url( $editorial_link['url'] ); ?>"><?php echo esc_html( $editorial_link['label'] ); ?></a><?php endforeach; ?></nav><?php endif; ?>
			</div>
		</section>
	<?php endif; ?>
	</div>

	<aside class="gl-collection__drawer" data-gl-filter-drawer hidden>
		<div class="gl-collection__drawer-panel" role="dialog" aria-modal="true" aria-labelledby="gl-filter-title">
		<div class="gl-collection__drawer-header">
			<h2 id="gl-filter-title"><?php esc_html_e( 'Filter products', 'glissimo' ); ?></h2>
			<button type="button" class="gl-icon-button" data-gl-filter-close aria-label="<?php esc_attr_e( 'Close filters', 'glissimo' ); ?>">
				<?php echo glissimo_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</button>
		</div>
		<div class="gl-collection__drawer-body">
			<div class="gl-collection__filter-section">
				<h3><?php esc_html_e( 'Categories', 'glissimo' ); ?></h3>
				<ul>
					<li><a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"<?php if ( ! $current_category ) : ?> aria-current="page" class="is-active"<?php endif; ?>><?php esc_html_e( 'Shop all', 'glissimo' ); ?></a></li>
					<?php foreach ( $sub_categories as $cat ) : ?>
						<?php if ( ! is_object( $cat ) || ! isset( $cat->term_id ) ) { continue; } ?>
						<li><a href="<?php echo esc_url( get_term_link( $cat ) ); ?>" <?php echo ( $current_category && $current_category->term_id === $cat->term_id ) ? 'aria-current="page" class="is-active"' : ''; ?>><?php echo esc_html( $cat->name ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>

			<div class="gl-collection__filter-section">
				<h3><?php esc_html_e( 'Sort by', 'glissimo' ); ?></h3>
				<form method="get" action="<?php echo esc_url( $permalink ); ?>" class="gl-filter-drawer__form">
					<label for="gl-mobile-sort"><?php esc_html_e( 'Sort by', 'glissimo' ); ?></label>
					<select id="gl-mobile-sort" name="orderby">
						<?php foreach ( $sort_options as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $ordering, $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php $render_query_state( array( 'orderby' ) ); ?>
					<button type="submit" class="gl-button"><?php esc_html_e( 'Apply', 'glissimo' ); ?></button>
				</form>
			</div>

			<?php if ( null !== $commerce_facets['min_price'] && $commerce_facets['max_price'] > $commerce_facets['min_price'] ) : ?>
				<div class="gl-collection__filter-section">
					<h3><?php esc_html_e( 'Price', 'glissimo' ); ?></h3>
					<form class="gl-filter-drawer__form gl-collection__price-form" method="get" action="<?php echo esc_url( $permalink ); ?>">
						<label><span><?php esc_html_e( 'Minimum', 'glissimo' ); ?></span><input type="number" min="0" step="0.01" name="min_price" value="<?php echo esc_attr( $minimum_price ); ?>" placeholder="<?php echo esc_attr( wc_format_localized_price( $commerce_facets['min_price'] ) ); ?>"></label>
						<label><span><?php esc_html_e( 'Maximum', 'glissimo' ); ?></span><input type="number" min="0" step="0.01" name="max_price" value="<?php echo esc_attr( $maximum_price ); ?>" placeholder="<?php echo esc_attr( wc_format_localized_price( $commerce_facets['max_price'] ) ); ?>"></label>
						<?php $render_query_state( array( 'min_price', 'max_price' ) ); ?>
						<button type="submit" class="gl-button"><?php esc_html_e( 'Apply price', 'glissimo' ); ?></button>
					</form>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $commerce_facets['has_sale'] ) ) : ?>
				<div class="gl-collection__filter-section">
					<h3><?php esc_html_e( 'Offers', 'glissimo' ); ?></h3>
					<ul><li><a href="<?php echo esc_url( glissimo_collection_filters_url( array( 'filter_sale' => 'onsale' === $sale_filter ? '' : 'onsale' ) ) ); ?>" <?php echo 'onsale' === $sale_filter ? 'aria-current="true" class="is-active"' : ''; ?>><?php esc_html_e( 'On sale', 'glissimo' ); ?></a></li></ul>
				</div>
			<?php endif; ?>

			<div class="gl-collection__filter-section">
				<h3><?php esc_html_e( 'Availability', 'glissimo' ); ?></h3>
				<form method="get" action="<?php echo esc_url( $permalink ); ?>" class="gl-filter-drawer__form">
					<label><input type="radio" name="filter_stock" value="" <?php checked( '', $stock_filter ); ?>> <?php esc_html_e( 'All stock', 'glissimo' ); ?></label>
					<label><input type="radio" name="filter_stock" value="instock" <?php checked( 'instock', $stock_filter ); ?>> <?php esc_html_e( 'In stock', 'glissimo' ); ?></label>
					<label><input type="radio" name="filter_stock" value="outofstock" <?php checked( 'outofstock', $stock_filter ); ?>> <?php esc_html_e( 'Out of stock', 'glissimo' ); ?></label>
					<?php $render_query_state( array( 'filter_stock' ) ); ?>
					<button type="submit" class="gl-button"><?php esc_html_e( 'Apply', 'glissimo' ); ?></button>
				</form>
			</div>

			<?php foreach ( $attribute_filters as $attribute_filter ) : ?>
				<?php
				$filter_key = 'filter_' . $attribute_filter['taxonomy'];
				$selected   = isset( $_GET[ $filter_key ] ) ? sanitize_title( wp_unslash( (string) $_GET[ $filter_key ] ) ) : '';
				?>
				<div class="gl-collection__filter-section">
					<h3><?php echo esc_html( $attribute_filter['label'] ); ?></h3>
					<ul>
						<?php foreach ( $attribute_filter['terms'] as $term ) : ?>
							<li><a href="<?php echo esc_url( glissimo_collection_filters_url( array( $filter_key => $selected === $term->slug ? '' : $term->slug ) ) ); ?>" <?php echo $selected === $term->slug ? 'aria-current="true" class="is-active"' : ''; ?>><?php echo esc_html( $term->name ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>
		</div>
		</div>
	</aside>
</main>

<?php get_footer(); ?>
