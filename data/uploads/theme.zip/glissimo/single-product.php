<?php
defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();
	global $product;
	if ( ! $product instanceof WC_Product ) {
		continue;
	}

	$story = glissimo_customer_content_tree( glissimo_product_story_meta( $product->get_id() ) );

	$gallery_ids = array_values(
		array_filter(
			array_unique(
				array_merge(
					array( (int) $product->get_image_id() ),
					$product->get_gallery_image_ids()
				)
			)
		)
	);

	$story_slots   = array( 'media_lifestyle', 'media_benefit', 'media_included', 'media_dimensions', 'media_feature', 'media_demo', 'media_closeup', 'media_storage', 'media_ugc' );
	$media_items   = array();
	$media_indexes = array();

	$add_media_item = static function ( int $media_id, string $type = 'image', string $slot = '' ) use ( &$media_items, &$media_indexes ) {
		if ( ! $media_id ) {
			return;
		}

		$image_size = 'woocommerce_single';
		$url       = 'video' === $type ? wp_get_attachment_url( $media_id ) : wp_get_attachment_image_url( $media_id, $image_size );
		if ( ! $url ) {
			return;
		}

		$key = $media_id . '_' . $type;
		if ( in_array( $key, $media_indexes, true ) ) {
			return;
		}

		$media_indexes[] = $key;
		$media_items[]   = array(
			'id'    => $media_id,
			'type'  => $type,
			'url'   => $url,
			'slot'  => $slot,
		);
	};

	foreach ( $gallery_ids as $media_id ) {
		$add_media_item( (int) $media_id, 'image' );
	}
	if ( ! empty( $story['story_image_id'] ) ) {
		$add_media_item( (int) $story['story_image_id'], 'image', 'story_image' );
	}
	if ( is_array( $story['media_slots'] ?? null ) ) {
		foreach ( $story_slots as $slot ) {
			$media_id = (int) ( $story['media_slots'][ $slot ] ?? 0 );
			if ( ! $media_id ) {
				continue;
			}
			$type = in_array( $slot, array( 'media_demo', 'media_ugc' ), true ) ? 'video' : 'image';
			$add_media_item( $media_id, $type, $slot );
		}
	}

	$benefits       = array_values( array_filter( is_array( $story['benefits'] ?? null ) ? $story['benefits'] : array(), static fn( $item ) => is_string( $item ) && '' !== trim( $item ) ) );
	$includes       = array_values( array_filter( is_array( $story['included_items'] ?? null ) ? $story['included_items'] : array(), static fn( $item ) => is_array( $item ) && '' !== trim( (string) ( $item['name'] ?? '' ) ) ) );
	$modules        = array_values( array_filter( is_array( $story['modules'] ?? null ) ? $story['modules'] : array(), static fn( $item ) => is_array( $item ) && ! empty( $item['active'] ) ) );
	$spec_sections  = is_array( $story['spec_sections'] ?? null ) ? $story['spec_sections'] : array();
	$faq_rows       = array_values( array_filter( is_array( $story['faq'] ?? null ) ? $story['faq'] : array(), static fn( $item ) => is_array( $item ) && '' !== trim( (string) ( $item['q'] ?? '' ) ) && '' !== trim( (string) ( $item['a'] ?? '' ) ) ) );
	$fbt_ids        = is_array( $story['fbt_product_ids'] ?? null ) ? $story['fbt_product_ids'] : array();
	$fbts           = $fbt_ids ? wc_get_products( array( 'include' => $fbt_ids, 'status' => 'publish', 'limit' => 8 ) ) : array();
	$related_ids    = glissimo_phase2_enabled( 'recommendations' ) ? glissimo_recommendation_product_ids( $product->get_id(), 2 ) : glissimo_catalog_recommendation_fallback_ids( $product->get_id(), 2 );
	$related_posts  = $related_ids ? wc_get_products( array( 'include' => $related_ids, 'status' => 'publish', 'limit' => 2 ) ) : array();
	$average_rating = (float) $product->get_average_rating();
	$review_count   = (int) $product->get_rating_count();
	$weight         = $product->get_weight() ? wc_format_weight( (float) $product->get_weight() ) : '';
	$dimensions     = wc_format_dimensions( $product->get_dimensions( false ) );
	$bundle_definition = glissimo_bundle_definition( $product->get_id() );
	$quantity_rules = is_array( $story['quantity_breaks'] ?? null ) ? $story['quantity_breaks'] : array();
	$safe_spec_lines = array_values( array_filter( (array) ( $story['spec_lines'] ?? array() ), 'glissimo_is_customer_spec_line' ) );
	$product_terms   = get_the_terms( $product->get_id(), 'product_cat' );
	$product_context = is_array( $product_terms ) && $product_terms ? (string) $product_terms[0]->name : __( 'Glissimo product', 'glissimo' );
	$value_prop      = trim( (string) ( $story['value_prop'] ?? '' ) );
	if ( '' === $value_prop ) {
		$short_description = trim( wp_strip_all_tags( $product->get_short_description() ) );
		$value_prop        = glissimo_is_internal_content( $short_description ) ? '' : $short_description;
	}
	$stock_status    = $product->is_type( 'variable' )
		? __( 'Choose an option to check availability', 'glissimo' )
		: ( $product->is_in_stock() ? __( 'Available', 'glissimo' ) : __( 'Currently unavailable', 'glissimo' ) );
	$stock_class     = $product->is_type( 'variable' ) ? '' : ( $product->is_in_stock() ? ' is-available' : ' is-unavailable' );
	?>
<main id="main-content" class="gl-pdp gl-container" tabindex="-1">
	<nav class="gl-breadcrumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'glissimo' ); ?>">
		<?php woocommerce_breadcrumb(); ?>
	</nav>

	<div class="gl-pdp__top">
		<section class="gl-pdp__gallery" aria-label="<?php esc_attr_e( 'Product gallery', 'glissimo' ); ?>">
			<div class="gl-pdp__media-main" data-gl-pdp-media-main>
				<?php if ( $media_items ) : ?>
					<?php
					$first = $media_items[0];
					if ( 'video' === $first['type'] ) :
						?>
						<video class="gl-pdp__media-video" controls preload="metadata" playsinline data-media-type="video">
							<source src="<?php echo esc_url( $first['url'] ); ?>" type="video/mp4">
						</video>
					<?php else : ?>
						<?php echo wp_get_attachment_image( $first['id'], 'woocommerce_single', false, array( 'alt' => $product->get_name(), 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?>
					<?php endif; ?>
					<button class="gl-pdp__zoom" type="button" data-gl-pdp-zoom aria-pressed="false" aria-label="<?php esc_attr_e( 'Toggle product image zoom', 'glissimo' ); ?>">+</button>
				<?php else : ?>
					<div class="gl-pdp__media--missing"><?php esc_html_e( 'Product image pending', 'glissimo' ); ?></div>
				<?php endif; ?>
			</div>

			<?php if ( count( $media_items ) > 1 ) : ?>
				<div class="gl-pdp__media-track" data-gl-pdp-media-track data-gl-rail data-gl-rail-item=".gl-pdp__thumb" aria-label="<?php esc_attr_e( 'Product media', 'glissimo' ); ?>">
					<?php foreach ( $media_items as $index => $media ) : ?>
						<button
							type="button"
							class="gl-pdp__thumb<?php echo 0 === $index ? ' is-active' : ''; ?>"
							data-gl-pdp-thumb
							data-media-type="<?php echo esc_attr( $media['type'] ); ?>"
							data-media-id="<?php echo esc_attr( $media['id'] ); ?>"
							data-media-url="<?php echo esc_url( $media['url'] ); ?>"
							data-media-index="<?php echo esc_attr( $index ); ?>"
							aria-label="<?php echo esc_attr( sprintf( __( 'Open media %1$d', 'glissimo' ), $index + 1 ) ); ?>"
						>
							<?php if ( 'video' === $media['type'] ) : ?>
								<span><?php esc_html_e( 'Video', 'glissimo' ); ?></span>
							<?php else : ?>
								<?php echo wp_get_attachment_image( (int) $media['id'], 'thumbnail', false, array( 'alt' => $product->get_name() ) ); ?>
							<?php endif; ?>
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</section>

		<section class="gl-pdp__purchase" data-gl-pdp-purchase data-product-type="<?php echo esc_attr( $product->get_type() ); ?>">
			<div class="gl-pdp__identity">
				<p class="gl-eyebrow"><?php echo esc_html( $product_context ); ?></p>
				<h1 class="gl-heading-display"><?php the_title(); ?></h1>

				<?php if ( $average_rating > 0 ) : ?>
					<a class="gl-pdp__rating" href="#reviews" aria-label="<?php echo esc_attr( sprintf( __( 'Rated %1$s out of 5', 'glissimo' ), number_format( $average_rating, 1 ) ) ); ?>">
						<?php echo wp_kses_post( wc_get_rating_html( $average_rating, $review_count ) ); ?>
						<span><?php echo esc_html( sprintf( _n( '1 review', '%d reviews', $review_count, 'glissimo' ), $review_count ) ); ?></span>
					</a>
				<?php endif; ?>

				<?php if ( '' !== $value_prop ) : ?>
					<p class="gl-pdp__short-copy"><?php echo esc_html( $value_prop ); ?></p>
				<?php endif; ?>
			</div>

			<div class="gl-pdp__purchase-card">
			<div class="gl-pdp__price-row">
				<p class="gl-pdp__price" data-gl-pdp-price><?php echo wp_kses_post( $product->get_price_html() ); ?></p>
			<?php if ( glissimo_product_savings( $product ) ) : ?>
				<p class="gl-pdp__saving"><?php echo esc_html( glissimo_product_savings( $product ) ); ?><?php if ( glissimo_product_savings_value( $product ) ) : ?> · <?php echo wp_kses_post( glissimo_product_savings_value( $product ) ); ?><?php endif; ?></p>
			<?php endif; ?>
			</div>
			<p class="gl-pdp__stock-status<?php echo esc_attr( $stock_class ); ?>" data-gl-pdp-stock-status aria-live="polite"><?php echo esc_html( $stock_status ); ?></p>

			<?php if ( $benefits ) : ?>
				<div class="gl-pdp__benefits">
					<h2><?php esc_html_e( 'Why it belongs in your kitchen', 'glissimo' ); ?></h2>
					<ul>
						<?php foreach ( array_slice( $benefits, 0, 5 ) as $benefit ) : ?>
							<li><?php echo glissimo_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( $benefit ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<div class="gl-pdp__purchase-actions">
			<?php if ( $bundle_definition ) :
				$bundle_components = array();
				$bundle_combined = 0.0;
				$bundle_combined_display = 0.0;
				$bundle_component_prices = array();
				foreach ( $bundle_definition['components'] as $bundle_component_id ) {
					$bundle_component = wc_get_product( $bundle_component_id );
					if ( $bundle_component ) { $bundle_components[] = $bundle_component; $bundle_component_prices[] = (float) $bundle_component->get_price(); $bundle_combined += (float) $bundle_component->get_price(); $bundle_combined_display += (float) wc_get_price_to_display( $bundle_component ); }
				}
				$bundle_offer_display = 0.0;
				$bundle_allocations = glissimo_allocate_bundle_minor_units( $bundle_component_prices, (float) $product->get_price() );
				foreach ( $bundle_components as $bundle_index => $bundle_component ) {
					$display_component = clone $bundle_component;
					$display_component->set_price( $bundle_allocations[ $bundle_index ] );
					$bundle_offer_display += (float) wc_get_price_to_display( $display_component );
				}
				?>
				<section class="gl-bundle-offer" data-gl-bundle-offer>
					<?php if ( ! empty( $story['bundle']['image_id'] ) ) : ?><figure class="gl-bundle-offer__media"><?php echo wp_get_attachment_image( (int) $story['bundle']['image_id'], 'large', false, array( 'loading' => 'lazy' ) ); ?></figure><?php endif; ?>
					<?php if ( ! empty( $story['bundle']['badge'] ) ) : ?><span class="gl-badge"><?php echo esc_html( $story['bundle']['badge'] ); ?></span><?php endif; ?>
					<?php if ( ! empty( $story['bundle']['copy'] ) ) : ?><p><?php echo esc_html( $story['bundle']['copy'] ); ?></p><?php endif; ?>
					<ul><?php foreach ( $bundle_components as $bundle_component ) : ?><li><span><?php echo esc_html( $bundle_component->get_name() ); ?></span><strong><?php echo wp_kses_post( wc_price( wc_get_price_to_display( $bundle_component ) ) ); ?></strong></li><?php endforeach; ?></ul>
					<div class="gl-bundle-offer__total"><span><?php esc_html_e( 'Combined value', 'glissimo' ); ?> <del><?php echo wp_kses_post( wc_price( $bundle_combined_display ) ); ?></del></span><strong><?php echo wp_kses_post( wc_price( $bundle_offer_display ) ); ?></strong></div>
					<?php if ( $bundle_combined_display > $bundle_offer_display ) : ?><p class="gl-pdp__saving"><?php echo esc_html( sprintf( __( 'Bundle saving: %s', 'glissimo' ), wp_strip_all_tags( wc_price( $bundle_combined_display - $bundle_offer_display ) ) ) ); ?></p><?php endif; ?>
					<form method="post" class="gl-bundle-fallback"><input type="hidden" name="glissimo_bundle_offer" value="<?php echo esc_attr( $product->get_id() ); ?>"><input type="hidden" name="glissimo_bundle_nonce" value="<?php echo esc_attr( wp_create_nonce( 'glissimo_bundle_' . $product->get_id() ) ); ?>"><button class="gl-button gl-bundle-offer__add" type="submit" data-gl-bundle-add data-offer-id="<?php echo esc_attr( $product->get_id() ); ?>" <?php disabled( ! $product->is_in_stock() ); ?>><?php echo esc_html( $product->is_in_stock() ? __( 'Add bundle to cart', 'glissimo' ) : __( 'Bundle unavailable', 'glissimo' ) ); ?></button></form>
				</section>
			<?php else : ?>
				<?php if ( ! empty( $quantity_rules['enabled'] ) && ! $product->is_on_sale() ) : ?>
					<div class="gl-quantity-breaks" aria-label="<?php esc_attr_e( 'Available quantity savings', 'glissimo' ); ?>">
						<strong><?php esc_html_e( 'Buy more, save more', 'glissimo' ); ?></strong>
						<?php if ( ! empty( $quantity_rules['qty_2'] ) ) : ?><span><?php echo esc_html( sprintf( __( 'Buy 2: save %s%%', 'glissimo' ), wc_format_decimal( $quantity_rules['qty_2'] ) ) ); ?></span><?php endif; ?>
						<?php if ( ! empty( $quantity_rules['qty_3'] ) ) : ?><span><?php echo esc_html( sprintf( __( 'Buy 3 or more: save %s%%', 'glissimo' ), wc_format_decimal( $quantity_rules['qty_3'] ) ) ); ?></span><?php endif; ?>
					</div>
				<?php endif; ?>
				<div class="gl-pdp__variants">
					<?php if ( $product->is_type( 'variable' ) ) : ?>
						<div class="gl-variation-options" data-gl-variation-options aria-label="<?php esc_attr_e( 'Choose product options', 'glissimo' ); ?>"></div>
						<p class="gl-variation-status" data-gl-variation-status aria-live="polite"><?php esc_html_e( 'Choose the options that suit your kitchen.', 'glissimo' ); ?></p>
					<?php endif; ?>
					<?php woocommerce_template_single_add_to_cart(); ?>
				</div>
			<?php endif; ?>

			<?php
			if ( ( ! $product->is_in_stock() || $product->is_type( 'variable' ) ) && glissimo_phase2_enabled( 'back_in_stock' ) ) {
				glissimo_back_in_stock_form();
			}
			if ( function_exists( 'glissimo_wishlist_button' ) ) {
				glissimo_wishlist_button();
			}
			?>
			</div>

			<ul class="gl-pdp__trust gl-pdp__assurances">
				<li><?php echo glissimo_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><strong><?php esc_html_e( 'Secure checkout', 'glissimo' ); ?></strong><small><?php esc_html_e( 'Payment details stay protected', 'glissimo' ); ?></small></span></li>
				<li><?php echo glissimo_icon( 'cart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><strong><?php esc_html_e( 'Clear delivery costs', 'glissimo' ); ?></strong><small><?php esc_html_e( 'Shipping options shown before payment', 'glissimo' ); ?></small></span></li>
			</ul>
			</div>
			<?php $phase2_settings = glissimo_phase2_settings(); $comparison_ids = array_map( 'absint', (array) ( $phase2_settings['comparison']['product_ids'] ?? array() ) ); if ( glissimo_phase2_enabled( 'bundle_builder' ) || ( glissimo_phase2_enabled( 'comparison' ) && in_array( $product->get_id(), $comparison_ids, true ) ) ) : ?><nav class="gl-pdp__phase2-links" aria-label="<?php esc_attr_e( 'Product choice tools', 'glissimo' ); ?>"><?php if ( glissimo_phase2_enabled( 'bundle_builder' ) ) : ?><a href="<?php echo esc_url( home_url( '/build-your-kitchen/' ) ); ?>"><?php esc_html_e( 'Build your kitchen', 'glissimo' ); ?></a><?php endif; ?><?php if ( glissimo_phase2_enabled( 'comparison' ) && in_array( $product->get_id(), $comparison_ids, true ) ) : ?><a href="<?php echo esc_url( home_url( '/compare-products/' ) ); ?>"><?php esc_html_e( 'Compare this product', 'glissimo' ); ?></a><?php endif; ?></nav><?php endif; ?>

		</section>
	</div>

	<?php if ( $includes ) : ?>
		<section class="gl-pdp__included" aria-labelledby="gl-included-heading">
			<p class="gl-eyebrow"><?php esc_html_e( 'Inside the set', 'glissimo' ); ?></p>
			<h2 id="gl-included-heading"><?php echo esc_html__( "What's included", 'glissimo' ); ?></h2>
			<div class="gl-pdp__included-grid">
				<?php foreach ( $includes as $item ) : ?>
					<article class="gl-pdp__included-item">
						<?php if ( ! empty( $item['image_id'] ) ) : ?>
							<?php echo wp_get_attachment_image( (int) $item['image_id'], 'medium', false, array( 'loading' => 'lazy', 'alt' => (string) ( $item['name'] ?? '' ) ) ); ?>
						<?php endif; ?>
						<div><h3><?php echo esc_html( (string) ( $item['name'] ?? '' ) ); ?></h3>
						<?php if ( ! empty( $item['quantity'] ) ) : ?><p><?php echo esc_html( sprintf( __( 'Quantity: %s', 'glissimo' ), $item['quantity'] ) ); ?></p><?php endif; ?>
						<?php if ( ! empty( $item['dimensions'] ) ) : ?><p><?php echo esc_html( (string) $item['dimensions'] ); ?></p><?php endif; ?></div>
					</article>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( ! empty( $story['story_heading'] ) || ! empty( $story['story_copy'] ) ) : ?>
		<section class="gl-pdp__story">
			<p class="gl-eyebrow"><?php echo esc_html( ! empty( $story['story_heading'] ) ? (string) $story['story_heading'] : __( 'Product story', 'glissimo' ) ); ?></p>
			<p class="gl-prose"><?php echo esc_html( (string) ( $story['story_copy'] ?? '' ) ); ?></p>
		</section>
	<?php endif; ?>

	<?php glissimo_render_pdp_editorial_modules( $modules ); ?>

	<section class="gl-pdp__accordions" aria-labelledby="gl-product-information-heading">
		<header class="gl-pdp__information-heading">
			<p><?php esc_html_e( 'Product information', 'glissimo' ); ?></p>
			<h2 id="gl-product-information-heading"><?php esc_html_e( 'Everything you need to know', 'glissimo' ); ?></h2>
		</header>
		<details class="gl-accordion">
			<summary><span><?php esc_html_e( 'Product specifications', 'glissimo' ); ?></span><span class="gl-accordion__icon" aria-hidden="true"><?php echo glissimo_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></summary>
			<div class="gl-accordion__content">
				<ul class="gl-pdp__specs">
					<?php if ( $dimensions ) : ?>
						<li><strong><?php esc_html_e( 'Dimensions', 'glissimo' ); ?>:</strong> <?php echo esc_html( $dimensions ); ?></li>
					<?php endif; ?>

					<?php if ( $weight ) : ?>
						<li><strong><?php esc_html_e( 'Weight', 'glissimo' ); ?>:</strong> <?php echo esc_html( $weight ); ?></li>
					<?php endif; ?>

					<?php foreach ( $safe_spec_lines as $spec_line ) : ?>
						<?php
						if ( ! is_string( $spec_line ) || '' === trim( $spec_line ) ) {
							continue;
						}
						if ( str_contains( $spec_line, ':' ) ) {
							[ $spec_key, $spec_value ] = array_map( 'trim', explode( ':', $spec_line, 2 ) );
							echo '<li><strong>' . esc_html( $spec_key ) . ':</strong> ' . esc_html( $spec_value ) . '</li>';
							continue;
						}
						echo '<li>' . esc_html( $spec_line ) . '</li>';
						?>
					<?php endforeach; ?>
				</ul>
			</div>
		</details>

		<?php
		$spec_labels = array(
			'product_details'  => __( 'Product Details', 'glissimo' ),
			'materials'        => __( 'Materials', 'glissimo' ),
			'compatibility'    => __( 'Compatibility', 'glissimo' ),
			'care'             => __( 'Care Instructions', 'glissimo' ),
			'shipping_returns' => __( 'Shipping & Returns', 'glissimo' ),
			'warranty'         => __( 'Warranty', 'glissimo' ),
		);
		foreach ( $spec_labels as $spec_key => $spec_label ) :
			if ( empty( $spec_sections[ $spec_key ] ) ) { continue; }
			?>
			<details class="gl-accordion"><summary><span><?php echo esc_html( $spec_label ); ?></span><span class="gl-accordion__icon" aria-hidden="true"><?php echo glissimo_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></summary><div class="gl-accordion__content gl-prose"><?php echo wp_kses_post( wpautop( $spec_sections[ $spec_key ] ) ); ?></div></details>
		<?php endforeach; ?>

		<details class="gl-accordion">
			<summary><span><?php esc_html_e( 'FAQ', 'glissimo' ); ?></span><span class="gl-accordion__icon" aria-hidden="true"><?php echo glissimo_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></summary>
			<div class="gl-accordion__content">
				<?php if ( $faq_rows ) : ?>
					<div class="gl-pdp__faq">
						<?php foreach ( $faq_rows as $entry ) : ?>
							<article class="gl-pdp__faq-item">
								<h3><?php echo esc_html( $entry['q'] ?? '' ); ?></h3>
								<p><?php echo esc_html( $entry['a'] ?? '' ); ?></p>
							</article>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</details>

	</section>

	<?php if ( $fbts ) : ?>
		<section class="gl-pdp__fbt" data-gl-fbt data-anchor-product-id="<?php echo esc_attr( $product->get_id() ); ?>">
			<header class="gl-section-heading"><p><?php esc_html_e( 'Complete the setup', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Frequently bought together', 'glissimo' ); ?></h2><span><?php esc_html_e( 'Choose the pieces that belong in your kitchen.', 'glissimo' ); ?></span></header>
			<div class="gl-pdp__fbt-grid" data-gl-rail data-gl-rail-item=".gl-fbt-product" aria-label="<?php esc_attr_e( 'Frequently bought together products', 'glissimo' ); ?>">
				<?php foreach ( $fbts as $fbt_product ) : ?>
					<?php
					$fbt_permalink = get_permalink( $fbt_product->get_id() );
					$price         = (float) $fbt_product->get_price();
					$regular_price = max( $price, (float) $fbt_product->get_regular_price() );
					$fbt_terms     = get_the_terms( $fbt_product->get_id(), 'product_cat' );
					$fbt_descriptor = is_array( $fbt_terms ) && $fbt_terms ? $fbt_terms[0]->name : '';
					?>
					<label class="gl-fbt-product">
						<input class="gl-fbt-product__input" type="checkbox" data-gl-fbt-item data-fbt-product-id="<?php echo esc_attr( $fbt_product->get_id() ); ?>" data-fbt-price="<?php echo esc_attr( $price ); ?>" data-fbt-regular-price="<?php echo esc_attr( $regular_price ); ?>" checked>
						<span class="gl-fbt-product__media"><?php echo wp_kses_post( $fbt_product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'alt' => $fbt_product->get_name() ) ) ); ?></span>
						<span class="gl-fbt-product__body"><?php if ( $fbt_descriptor ) : ?><small><?php echo esc_html( $fbt_descriptor ); ?></small><?php endif; ?><a href="<?php echo esc_url( $fbt_permalink ); ?>"><?php echo esc_html( $fbt_product->get_name() ); ?></a><strong><?php echo wp_kses_post( $fbt_product->get_price_html() ); ?></strong></span>
						<span class="gl-fbt-product__selection"><?php echo glissimo_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php esc_html_e( 'Selected', 'glissimo' ); ?></span></span>
					</label>
				<?php endforeach; ?>
			</div>

			<div class="gl-pdp__fbt-summary">
				<div class="gl-pdp__fbt-totals"><p><span><?php esc_html_e( 'Selected', 'glissimo' ); ?></span><strong data-gl-fbt-selected></strong></p><p data-gl-fbt-regular-row><span><?php esc_html_e( 'Regular total', 'glissimo' ); ?></span><strong data-gl-fbt-regular></strong></p><p><span data-gl-fbt-total-label><?php esc_html_e( 'Selected total', 'glissimo' ); ?></span><strong data-gl-fbt-offer></strong></p><p class="gl-pdp__fbt-saving" data-gl-fbt-savings-row><span><?php esc_html_e( 'You save', 'glissimo' ); ?></span><strong data-gl-fbt-savings></strong></p></div>
				<button type="button" class="gl-button" data-gl-fbt-add data-label="<?php esc_attr_e( 'Add selected to cart', 'glissimo' ); ?>">
					<?php esc_html_e( 'Add selected to cart', 'glissimo' ); ?>
				</button>
			</div>
		</section>
	<?php endif; ?>

	<?php $marketplace_feedback = is_array( $story['marketplace_feedback'] ?? null ) ? $story['marketplace_feedback'] : array(); ?>
	<?php if ( ! empty( $marketplace_feedback['source_label'] ) && ! empty( $marketplace_feedback['rating_count'] ) ) : ?>
		<section class="gl-marketplace-feedback" aria-labelledby="gl-marketplace-feedback-title">
			<header class="gl-marketplace-feedback__heading"><div><p><?php echo esc_html( $marketplace_feedback['source_label'] ); ?></p><h2 id="gl-marketplace-feedback-title"><?php esc_html_e( 'What marketplace customers highlighted', 'glissimo' ); ?></h2></div><div class="gl-marketplace-feedback__rating" aria-label="<?php echo esc_attr( sprintf( __( '%1$s out of 5 from %2$d Amazon ratings', 'glissimo' ), $marketplace_feedback['rating'], (int) $marketplace_feedback['rating_count'] ) ); ?>"><strong><?php echo esc_html( $marketplace_feedback['rating'] ); ?><span>/5</span></strong><span><?php echo esc_html( sprintf( _n( '%s Amazon rating', '%s Amazon ratings', (int) $marketplace_feedback['rating_count'], 'glissimo' ), number_format_i18n( (int) $marketplace_feedback['rating_count'] ) ) ); ?></span></div></header>
			<p class="gl-marketplace-feedback__note"><?php esc_html_e( 'Marketplace feedback shown separately from Glissimo customer reviews.', 'glissimo' ); ?><?php if ( ! empty( $marketplace_feedback['captured_at'] ) ) : ?> <?php echo esc_html( sprintf( __( 'Captured %s.', 'glissimo' ), $marketplace_feedback['captured_at'] ) ); ?><?php endif; ?></p>
			<div class="gl-marketplace-feedback__list">
				<?php foreach ( (array) ( $marketplace_feedback['reviews'] ?? array() ) as $review ) : ?>
					<?php if ( ! is_array( $review ) || ( empty( $review['title'] ) && empty( $review['summary'] ) ) ) { continue; } ?>
					<article class="gl-marketplace-feedback__review"><div class="gl-marketplace-feedback__review-meta"><strong><?php echo esc_html( (string) ( $review['rating'] ?? '' ) ); ?><span>/5</span></strong><?php if ( ! empty( $review['verified'] ) ) : ?><span class="gl-marketplace-feedback__verified"><?php esc_html_e( 'Verified Amazon purchase', 'glissimo' ); ?></span><?php endif; ?></div><h3><?php echo esc_html( (string) ( $review['title'] ?? '' ) ); ?></h3><p><?php echo esc_html( (string) ( $review['summary'] ?? '' ) ); ?></p><?php if ( ! empty( $review['name'] ) ) : ?><small><?php echo esc_html( sprintf( __( '%s on Amazon', 'glissimo' ), $review['name'] ) ); ?></small><?php endif; ?></article>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="gl-pdp__reviews" id="reviews">
		<header class="gl-section-heading"><p><?php esc_html_e( 'Customer reviews', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Shared by Glissimo customers', 'glissimo' ); ?></h2></header>
		<?php do_action( 'glissimo_reviews_summary', $product ); ?>
		<?php $GLOBALS['glissimo_has_marketplace_feedback'] = ! empty( $marketplace_feedback['source_label'] ) && ! empty( $marketplace_feedback['rating_count'] ); ?>
		<?php load_template( get_theme_file_path( '/comments.php' ), false ); ?>
		<?php unset( $GLOBALS['glissimo_has_marketplace_feedback'] ); ?>
		<?php do_action( 'glissimo_reviews_content', $product ); ?>
	</section>

	<?php glissimo_render_product_editorial( $product ); ?>

	<?php if ( $related_posts ) : ?>
		<section class="gl-related-products">
			<header class="gl-section-heading"><p><?php esc_html_e( 'You may also like', 'glissimo' ); ?></p><h2><?php esc_html_e( 'Complete your kitchen', 'glissimo' ); ?></h2></header>
			<div class="gl-product-rail" data-gl-rail data-gl-rail-item=".gl-product-card" aria-label="<?php esc_attr_e( 'Related products', 'glissimo' ); ?>">
				<?php foreach ( $related_posts as $related_product ) : ?>
					<div data-gl-recommendation-click data-product-id="<?php echo esc_attr( $related_product->get_id() ); ?>"><?php glissimo_product_card( $related_product ); ?></div>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $product->is_purchasable() && $product->is_in_stock() ) : ?>
		<aside class="gl-pdp__sticky-atc" data-gl-sticky-atc hidden aria-label="<?php esc_attr_e( 'Quick purchase', 'glissimo' ); ?>">
			<span><strong><?php echo esc_html( $product->get_name() ); ?></strong><span data-gl-sticky-selection></span><span data-gl-sticky-price><?php echo wp_kses_post( $product->get_price_html() ); ?></span></span>
			<button type="button" class="gl-button" data-gl-sticky-atc-button <?php disabled( $product->is_type( 'variable' ) ); ?>><?php echo esc_html( $product->is_type( 'variable' ) ? __( 'Choose options', 'glissimo' ) : __( 'Add to cart', 'glissimo' ) ); ?></button>
		</aside>
	<?php endif; ?>
</main>
<?php endwhile; ?>
<?php get_footer(); ?>
