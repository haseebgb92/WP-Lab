<?php
defined( 'ABSPATH' ) || exit;
$order = isset( $order ) && $order instanceof WC_Order ? $order : ( ! empty( $order_id ) ? wc_get_order( $order_id ) : false );
$settings = glissimo_core_settings();
$config = glissimo_customer_content_tree( $settings['thank_you'] ?? array() );
?>
<div class="gl-thank-you">
	<?php if ( $order && $order->has_status( 'failed' ) ) : ?>
		<section class="gl-thank-you__hero is-failed">
			<p><?php esc_html_e( 'Payment was not completed', 'glissimo' ); ?></p>
			<h1><?php esc_html_e( 'Your order needs attention', 'glissimo' ); ?></h1>
			<p><?php esc_html_e( 'No successful payment was recorded. You can try again or contact support.', 'glissimo' ); ?></p>
			<a class="gl-button" href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>"><?php esc_html_e( 'Try payment again', 'glissimo' ); ?></a>
		</section>
	<?php elseif ( $order ) : ?>
		<section class="gl-thank-you__hero">
			<div class="gl-thank-you__mark"><?php echo glissimo_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><p><?php esc_html_e( 'Order confirmed', 'glissimo' ); ?></p>
			<h1><?php echo esc_html( ! empty( $config['heading'] ) ? $config['heading'] : __( 'Thank you for your order', 'glissimo' ) ); ?></h1>
			<?php if ( ! empty( $config['body'] ) ) : ?><p><?php echo esc_html( $config['body'] ); ?></p><?php endif; ?>
			<div class="gl-thank-you__number"><span><?php esc_html_e( 'Order number', 'glissimo' ); ?></span><strong><?php echo esc_html( $order->get_order_number() ); ?></strong></div>
		</section>
		<?php do_action( 'glissimo_post_purchase_offer_surface', $order ); ?>

		<div class="gl-thank-you__grid">
			<section>
				<h2><?php esc_html_e( 'What happens next', 'glissimo' ); ?></h2>
				<p><?php esc_html_e( 'Order and delivery updates will be sent using the contact details supplied at checkout.', 'glissimo' ); ?></p>
				<?php if ( $order->get_shipping_method() ) : ?><p><strong><?php esc_html_e( 'Selected delivery method:', 'glissimo' ); ?></strong> <?php echo esc_html( $order->get_shipping_method() ); ?></p><?php endif; ?>
			</section>
			<section>
				<h2><?php esc_html_e( 'Tracking', 'glissimo' ); ?></h2>
				<p><?php esc_html_e( 'Tracking information will appear with your delivery update when the selected carrier provides it.', 'glissimo' ); ?></p>
			</section>
		</div>

		<section class="gl-thank-you__order" aria-label="<?php esc_attr_e( 'Order details', 'glissimo' ); ?>">
			<?php do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id() ); ?>
			<?php do_action( 'woocommerce_thankyou', $order->get_id() ); ?>
		</section>

		<?php $care_links = glissimo_order_care_links( $order ); if ( $care_links ) : ?>
			<section class="gl-thank-you__care">
				<h2><?php echo esc_html( $config['care_heading'] ?? __( 'Product care', 'glissimo' ) ); ?></h2>
				<div><?php foreach ( $care_links as $care ) : ?><a href="<?php echo esc_url( $care['url'] ); ?>"><?php echo esc_html( $care['title'] ); ?> <span aria-hidden="true">&rarr;</span></a><?php endforeach; ?></div>
			</section>
		<?php endif; ?>

		<?php
		$purchased_ids = array();
		foreach ( $order->get_items() as $order_item ) { $purchased_ids[] = $order_item->get_product_id(); }
		$cross_sell_ids = array_values( array_diff( array_map( 'absint', (array) ( $config['cross_sell_ids'] ?? array() ) ), $purchased_ids ) );
		$cross_sells = $cross_sell_ids ? wc_get_products( array( 'include' => $cross_sell_ids, 'status' => 'publish', 'limit' => 4 ) ) : array();
		if ( $cross_sells ) : ?>
			<section class="gl-thank-you__recommendations">
				<h2><?php esc_html_e( 'Continue your kitchen', 'glissimo' ); ?></h2>
				<div class="gl-product-grid"><?php foreach ( $cross_sells as $cross_sell ) { if ( $cross_sell->is_visible() && $cross_sell->is_in_stock() ) { glissimo_product_card( $cross_sell ); } } ?></div>
			</section>
		<?php endif; ?>

		<section class="gl-thank-you__support">
			<h2><?php esc_html_e( 'Need help with your order?', 'glissimo' ); ?></h2>
			<?php if ( ! empty( $settings['support']['contact_url'] ) ) : ?><a class="gl-button gl-button--outline" href="<?php echo esc_url( $settings['support']['contact_url'] ); ?>"><?php esc_html_e( 'Contact Glissimo support', 'glissimo' ); ?></a><?php endif; ?>
			<?php if ( ! is_user_logged_in() && ! empty( $config['account_prompt'] ) && 'yes' === get_option( 'woocommerce_enable_myaccount_registration' ) ) : ?><a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"><?php esc_html_e( 'Create an optional account', 'glissimo' ); ?></a><?php endif; ?>
			<?php if ( ! empty( $config['referral_enabled'] ) ) { do_action( 'glissimo_thank_you_referral', $order ); } ?>
		</section>
	<?php else : ?>
		<section class="gl-thank-you__hero"><h1><?php esc_html_e( 'Thank you', 'glissimo' ); ?></h1></section>
	<?php endif; ?>
</div>
