<?php
/**
 * Glissimo account navigation.
 *
 * @package Glissimo
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

$icon_map = array(
	'dashboard'      => 'dashboard',
	'orders'         => 'orders',
	'edit-address'   => 'pin',
	'wishlist'       => 'heart',
	'payment-methods'=> 'payment',
	'back-in-stock'  => 'bell',
	'kitchen-club'   => 'star',
	'referrals'      => 'referral',
	'edit-account'   => 'account',
	'customer-logout'=> 'logout',
);
?>
<nav class="woocommerce-MyAccount-navigation gl-account-nav" aria-label="<?php esc_attr_e( 'Account navigation', 'glissimo' ); ?>">
	<ul>
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<?php $current = wc_is_current_account_menu_item( $endpoint ); ?>
			<li class="<?php echo esc_attr( wc_get_account_menu_item_classes( $endpoint ) ); ?>">
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>"<?php echo $current ? ' aria-current="page"' : ''; ?>>
					<span class="gl-account-nav__icon"><?php echo glissimo_icon( $icon_map[ $endpoint ] ?? 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span><?php echo esc_html( $label ); ?></span>
					<?php echo glissimo_icon( 'chevron', 'gl-account-nav__chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
