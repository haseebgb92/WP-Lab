<?php
/**
 * Glissimo account dashboard.
 *
 * @package Glissimo
 * @version 4.4.0
 */

defined( 'ABSPATH' ) || exit;

$customer_id   = get_current_user_id();
$customer      = wp_get_current_user();
$display_name  = $customer->display_name ?: $customer->user_login;
$order_count   = wc_get_customer_order_count( $customer_id );
$wishlist_ids  = function_exists( 'glissimo_wishlist_ids' ) ? glissimo_wishlist_ids() : array();
$wishlist_count= count( $wishlist_ids );
$address       = wc_get_account_endpoint_url( 'edit-address' );
$cards         = array(
	array( 'icon' => 'orders', 'title' => __( 'Orders', 'glissimo' ), 'copy' => sprintf( _n( '%s order in your history', '%s orders in your history', $order_count, 'glissimo' ), number_format_i18n( $order_count ) ), 'url' => wc_get_account_endpoint_url( 'orders' ), 'action' => __( 'View orders', 'glissimo' ) ),
	array( 'icon' => 'pin', 'title' => __( 'Addresses', 'glissimo' ), 'copy' => __( 'Keep delivery and billing details ready for checkout.', 'glissimo' ), 'url' => $address, 'action' => __( 'Manage addresses', 'glissimo' ) ),
	array( 'icon' => 'heart', 'title' => __( 'Wishlist', 'glissimo' ), 'copy' => sprintf( _n( '%s product saved for later', '%s products saved for later', $wishlist_count, 'glissimo' ), number_format_i18n( $wishlist_count ) ), 'url' => wc_get_account_endpoint_url( 'wishlist' ), 'action' => __( 'Open wishlist', 'glissimo' ) ),
	array( 'icon' => 'account', 'title' => __( 'Account details', 'glissimo' ), 'copy' => __( 'Update your name, email address or password.', 'glissimo' ), 'url' => wc_get_account_endpoint_url( 'edit-account' ), 'action' => __( 'Edit details', 'glissimo' ) ),
);
?>
<div class="gl-account-dashboard">
	<header class="gl-account-dashboard__welcome">
		<p><?php esc_html_e( 'Welcome back', 'glissimo' ); ?></p>
		<h2><?php echo esc_html( $display_name ); ?></h2>
		<span><?php esc_html_e( 'Everything for your orders and saved products is collected here.', 'glissimo' ); ?></span>
	</header>

	<div class="gl-account-dashboard__grid">
		<?php foreach ( $cards as $card ) : ?>
			<a class="gl-account-dashboard__card" href="<?php echo esc_url( $card['url'] ); ?>">
				<span class="gl-account-dashboard__card-icon"><?php echo glissimo_icon( $card['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span class="gl-account-dashboard__card-copy"><strong><?php echo esc_html( $card['title'] ); ?></strong><small><?php echo esc_html( $card['copy'] ); ?></small></span>
				<span class="gl-account-dashboard__card-action"><?php echo esc_html( $card['action'] ); ?><?php echo glissimo_icon( 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			</a>
		<?php endforeach; ?>
	</div>

	<aside class="gl-account-support" aria-labelledby="gl-account-support-title">
		<div>
			<h2 id="gl-account-support-title"><?php esc_html_e( 'Need help with an order?', 'glissimo' ); ?></h2>
			<p><?php esc_html_e( 'Find answers about delivery, returns and product care, or contact the Glissimo support team.', 'glissimo' ); ?></p>
		</div>
		<div class="gl-account-support__actions">
			<nav class="gl-account-support__links" aria-label="<?php esc_attr_e( 'Order support', 'glissimo' ); ?>">
				<a href="<?php echo esc_url( home_url( '/shipping-returns/' ) ); ?>"><?php esc_html_e( 'Shipping & returns', 'glissimo' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/warranty/' ) ); ?>"><?php esc_html_e( 'Warranty', 'glissimo' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/product-care/' ) ); ?>"><?php esc_html_e( 'Product care', 'glissimo' ); ?></a>
			</nav>
			<a class="gl-button gl-button--primary gl-button--compact" href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact support', 'glissimo' ); ?></a>
		</div>
	</aside>

	<?php do_action( 'woocommerce_account_dashboard' ); ?>
</div>
