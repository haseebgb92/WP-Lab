<?php
/**
 * Glissimo customer account shell.
 *
 * @package Glissimo
 * @version 3.5.0
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="gl-account-shell">
	<header class="gl-account-hero">
		<div class="gl-container">
			<p class="gl-account-hero__label"><?php esc_html_e( 'Your kitchen, in one place', 'glissimo' ); ?></p>
			<h1><?php esc_html_e( 'Your Glissimo account', 'glissimo' ); ?></h1>
			<p><?php esc_html_e( 'Manage orders, delivery details and the products you have saved.', 'glissimo' ); ?></p>
		</div>
	</header>

	<div class="gl-container gl-account-layout">
		<?php do_action( 'woocommerce_account_navigation' ); ?>
		<section class="woocommerce-MyAccount-content gl-account-content" aria-label="<?php esc_attr_e( 'Account content', 'glissimo' ); ?>">
			<?php do_action( 'woocommerce_account_content' ); ?>
		</section>
	</div>
</section>
