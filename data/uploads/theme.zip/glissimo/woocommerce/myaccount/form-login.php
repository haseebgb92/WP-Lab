<?php
/**
 * Glissimo account sign-in and registration.
 *
 * @package Glissimo
 * @version 9.9.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_customer_login_form' );
$registration_enabled = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );
?>
<section class="gl-account-shell gl-account-shell--guest">
	<header class="gl-account-hero">
		<div class="gl-container">
			<p class="gl-account-hero__label"><?php esc_html_e( 'Your kitchen, in one place', 'glissimo' ); ?></p>
			<h1><?php esc_html_e( 'Your Glissimo account', 'glissimo' ); ?></h1>
			<p><?php esc_html_e( 'View orders, manage delivery details and return to products you have saved.', 'glissimo' ); ?></p>
		</div>
	</header>

	<div class="gl-container gl-account-auth<?php echo $registration_enabled ? ' gl-account-auth--split' : ''; ?>" id="customer_login">
		<section class="gl-account-auth__panel" aria-labelledby="gl-account-login-title">
			<h2 id="gl-account-login-title"><?php esc_html_e( 'Sign in', 'glissimo' ); ?></h2>
			<p><?php esc_html_e( 'Continue to your orders, addresses and wishlist.', 'glissimo' ); ?></p>
			<form class="woocommerce-form woocommerce-form-login login" method="post">
				<?php do_action( 'woocommerce_login_form_start' ); ?>
				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="username"><?php esc_html_e( 'Email address or username', 'glissimo' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label>
					<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" value="<?php echo ! empty( $_POST['username'] ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true">
				</p>
				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="password"><?php esc_html_e( 'Password', 'glissimo' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label>
					<input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" required aria-required="true">
				</p>
				<?php do_action( 'woocommerce_login_form' ); ?>
				<p class="form-row gl-account-auth__actions">
					<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
						<input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever"> <span><?php esc_html_e( 'Remember me', 'glissimo' ); ?></span>
					</label>
					<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
					<button type="submit" class="woocommerce-button button gl-button gl-button--primary woocommerce-form-login__submit" name="login" value="<?php esc_attr_e( 'Sign in', 'glissimo' ); ?>"><?php esc_html_e( 'Sign in', 'glissimo' ); ?></button>
				</p>
				<p class="woocommerce-LostPassword lost_password"><a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Forgotten your password?', 'glissimo' ); ?></a></p>
				<?php do_action( 'woocommerce_login_form_end' ); ?>
			</form>
		</section>

		<?php if ( $registration_enabled ) : ?>
			<section class="gl-account-auth__panel" aria-labelledby="gl-account-register-title">
				<h2 id="gl-account-register-title"><?php esc_html_e( 'Create an account', 'glissimo' ); ?></h2>
				<p><?php esc_html_e( 'Keep checkout details and order history together. Guest checkout remains available.', 'glissimo' ); ?></p>
				<form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?>>
					<?php do_action( 'woocommerce_register_form_start' ); ?>
					<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide"><label for="reg_username"><?php esc_html_e( 'Username', 'glissimo' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label><input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ! empty( $_POST['username'] ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" required aria-required="true"></p>
					<?php endif; ?>
					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide"><label for="reg_email"><?php esc_html_e( 'Email address', 'glissimo' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label><input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ! empty( $_POST['email'] ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" required aria-required="true"></p>
					<?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide"><label for="reg_password"><?php esc_html_e( 'Password', 'glissimo' ); ?>&nbsp;<span class="required" aria-hidden="true">*</span></label><input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="password" id="reg_password" autocomplete="new-password" required aria-required="true"></p>
					<?php else : ?>
						<p><?php esc_html_e( 'A link to set your password will be sent to your email address.', 'glissimo' ); ?></p>
					<?php endif; ?>
					<?php do_action( 'woocommerce_register_form' ); ?>
					<p class="woocommerce-form-row form-row"><?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?><button type="submit" class="woocommerce-Button woocommerce-button button gl-button gl-button--primary woocommerce-form-register__submit" name="register" value="<?php esc_attr_e( 'Create account', 'glissimo' ); ?>"><?php esc_html_e( 'Create account', 'glissimo' ); ?></button></p>
					<?php do_action( 'woocommerce_register_form_end' ); ?>
				</form>
			</section>
		<?php endif; ?>
	</div>
</section>
<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
